import { Analysis } from "../3rd/Analysis";
import { BusinessManager } from "../3rd/BusinessManager";
import { dadian } from "../3rd/dadian";
import Md5Helper from "../3rd/Md5Helper";
import DataFunc from "../common/DataFunc";
import UserData from "../userdata/UserData";

type Vec = cc.Vec2 | cc.Vec3
export const Util = new class {
    addCheckEvent(target, node, jsName, cbName, edata) {
        var checkEventHandler = new cc.Component.EventHandler();
        checkEventHandler.target = node; //这个 node 节点是你的事件处理代码组件所属的节点
        checkEventHandler.component = jsName;
        checkEventHandler.handler = cbName;
        if (edata)
            checkEventHandler.customEventData = edata;
        target.checkEvents.push(checkEventHandler);
    }
    addClickEvent(target, node, jsName, cbName, edata = null) {
        var checkEventHandler = new cc.Component.EventHandler();
        checkEventHandler.target = node; //这个 node 节点是你的事件处理代码组件所属的节点
        checkEventHandler.component = jsName;
        checkEventHandler.handler = cbName;
        if (edata)
            checkEventHandler.customEventData = edata;
        target.clickEvents.push(checkEventHandler);
    }
    // getRandom(begin, end) {
    //     //[begin,end]
    //     return Math.floor(Math.random() * (end - begin + 1)) + begin;
    // }
    getRandom(min: number, max: number): number {
        //[min,max)
        return Math.floor(Math.random() * (max - min) + min);
    }

    getRandomSign(): number {
        return Math.sign(this.getRandom(-100, 100));
    }

    getRandomClose(min: number, max: number): number {
        //[min,max]
        return Math.floor(Math.random() * (max - min + 1) + min);
    }
    seededRandom(min: number, max: number, seed: number) {
        const rnd = (seed * 9301 + 49297) % 233280 / 233280;
        return Math.floor(min + rnd * (max - min));
    }
    getRandomValueInArray<T>(arr: T[]): T {
        const max = arr.length;
        const min = 0;
        return arr[this.getRandom(min, max)];
    }
    getRandomValuesInArray<T>(arr: T[], count: number): T[] {
        const arrTemp = arr.slice();
        const result: T[] = [];
        for (; count > 0; count--) {
            if (arrTemp.length == 0) break;
            const max = arrTemp.length;
            const min = 0;
            const i = this.getRandom(min, max);
            result.push(arrTemp[i]);
            arrTemp.splice(i, 1);
        }
        return result;
    }
    //在指定长度数组中获取随机n个序号
    getRandomIndexes(len: number, cnt: number): number[] {
        return this.getRandomValuesInArray(new Array(len).fill(0).map((n, i) => i), cnt);
    }
    sortArrayInRandom<T>(arr: T[]): T[] {
        let i = arr.length;
        while (i) {
            let j = Math.floor(Math.random() * i--);
            [arr[j], arr[i]] = [arr[i], arr[j]];
        }
        return arr;
    }

    judgePercent(target, percent = 100) {
        if (target == 0) return false;
        if (target == percent) return true;
        let rand = this.getRandom(0, percent);
        if (rand < target) return true
        return false;
    }
    isInArry(val, arr) {
        if (typeof arr != 'object') return false;
        if (arr.indexOf(val) > -1) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 通过值来获取对应的key，要获取的key必须是可枚举属性
     * @param obj 对象
     * @param value 值
     */
    getKeyByValue(obj, value) {
        if (obj instanceof Object) {
            return Object.keys(obj)[Object.values(obj).indexOf(value)];
        }
    }

    //数组去重
    distinct(a) {
        return Array.from(new Set(a));
    }
    makeDateStr(time = null) {
        var d = null;
        if (time) d = new Date(time);
        else d = new Date();
        var gd = d.getDate();
        var day = gd < 10 ? '0' + gd : gd;
        var gm = d.getMonth() + 1;
        var month = gm < 10 ? '0' + gm : gm;
        return '' + d.getFullYear() + month + day;
    }
    dateIsSame(timestamp) {
        return this.makeDateStr() == this.makeDateStr(timestamp);
    }
    copyObj(obj) {
        return JSON.parse(JSON.stringify(obj));
    }
    randObjKey(obj) {
        let keys = Object.keys(obj);
        let rand = this.getRandom(0, keys.length);
        return keys[rand];
    }
    //整数分成整数份
    spiltIntNumber(all, parts) {
        let ret = [];
        let sum = 0;
        if (parts == 0 || Math.floor(all / parts) == 0) return [all];
        for (let i = 0; i < parts; i++) {
            if (i != parts - 1) {
                let one = Math.floor(all / parts);
                sum += one;
                ret.push(one);
            } else {
                ret.push(all - sum);
            }
        }
        return ret;
    }
    /**
     * 判断点是否在多边形内(射线法)。
     * @param {[cc.Vec2]} polygonPoints 
     * @param {cc.Vec2} p 
     * @returns {Boolean} 
     */
    checkPointInPolygon(polygonPoints: Vec[], p: Vec): boolean {
        let interectionPoint = 0;
        let a = polygonPoints[0];
        for (let i = polygonPoints.length - 1; i >= 0; i--) {
            const b = polygonPoints[i];
            if (a.x == b.x) {
                if (a.x == p.x) return true;
            } else if (p.x >= Math.min(a.x, b.x) && p.x <= Math.max(a.x, b.x)) {
                const x = (b.y - a.y) / (b.x - a.x) * (p.x - a.x) + a.y;
                if (x == p.x) {
                    return true;
                } else if (p.x > x) {
                    interectionPoint++;
                }
            }
            a = b;
        }
        return interectionPoint % 2 != 0;
    }
    isPointOnPolygon(p: Vec, points: Vec[]): boolean {
        let a = points[0];
        for (let i = points.length - 1; i >= 0; i--) {
            const b = points[i];
            if (this.isPointInLine(p, a, b)) return true;
        }
    }
    isPointInLine(p: Vec, p1: Vec, p2: Vec): boolean {
        return (p.y - p1.y) * (p2.x - p1.x) == (p2.y - p1.y) * (p.x - p1.x);
    }

    getDistance<T extends Vec>(p1: T, p2: T) {
        return p1.sub(p2 as any).mag();
    }

    /**
     * 生成一个坐标转换函数，以传入的两个向量分别作为新坐标系的x轴和y轴
     * @param {cc.Vec2} xVec 
     * @param {cc.Vec2} yVec 
     * @returns {Function} 将任意坐标转换到目标坐标系的函数
     */
    createConvertToVectorSpaceFunction(xVec: cc.Vec3, yVec: cc.Vec3) {
        if (!(xVec instanceof cc.Vec3) || !(yVec instanceof cc.Vec3)) return null;
        if (xVec.x * yVec.y == xVec.y * yVec.x) return null; //两条轴平行

        xVec.normalizeSelf();
        yVec.normalizeSelf();

        const x1 = xVec.x,
            x2 = yVec.x,
            y1 = xVec.y,
            y2 = yVec.y,
            e = x1 * y2 - x2 * y1,
            a = y2 / e,
            b = -y1 / e,
            c = -x2 / e,
            d = x1 / e;

        return function (vec: cc.Vec3) {
            return cc.v2(a * vec.x + c * vec.y, b * vec.x + d * vec.y);
        }
    }

    /**
     * 生成一个坐标恢复函数，以传入的两个向量分别作为旧坐标系的x轴和y轴（一般与createConvertToVectorSpaceFunction同时使用）
     * @param {cc.Vec2} xVec 
     * @param {cc.Vec2} yVec 
     * @returns {Function} 将任意坐标从目标坐标系转回标准坐标系的函数
     */
    createConvertFromVectorSpaceFunction(xVec: cc.Vec3, yVec: cc.Vec3) {
        if (!(xVec instanceof cc.Vec3) || !(yVec instanceof cc.Vec3)) return null;
        if (xVec.x * yVec.y == xVec.y * yVec.x) return null; //两条轴平行

        xVec.normalizeSelf();
        yVec.normalizeSelf();

        const a = xVec.x,
            c = yVec.x,
            b = xVec.y,
            d = yVec.y;

        return function (vec: cc.Vec3) {
            return cc.v2(a * vec.x + c * vec.y, b * vec.x + d * vec.y);
        }
    }

    /**
     * 把一个坐标从节点坐标系转换成世界坐标
     * @param {cc.Node} node 
     */
    nodeConvertToWorld(node: cc.Node, position?: cc.Vec3): cc.Vec3 {
        if (!position) position = node.position;
        return node.parent.convertToWorldSpaceAR(position);
    }

    /**
     * 把一个世界坐标转换为与目标节点所使用的坐标系下的坐标值（以参数节点的父节点为参照）
     * @param {cc.Node} node 
     * @param {cc.Vec2} worldPosition 
     */
    worldConvertToNode(node: cc.Node, worldPosition: cc.Vec3): cc.Vec3 {
        return node.parent.convertToNodeSpaceAR(worldPosition);
    }

    /**
     * 把一个外地节点的坐标值，转换为与本地节点所使用的坐标系下的坐标值（以本地节点的父节点为参照）
     * @param {cc.Node} localNode 本地节点
     * @param {cc.Node} nonlocalNode 非本地节点
     * @param {cc.Vec2} targetPos 需要转换的坐标(默认使用第二个参数节点的坐标)
     */
    fromNodeToNode(localNode: cc.Node, nonlocalNode: cc.Node, targetPos?: cc.Vec3): cc.Vec3 {
        return this.worldConvertToNode(localNode, this.nodeConvertToWorld(nonlocalNode, targetPos));
    }

    rectWorldToNode(node: cc.Node, rect: cc.Rect): cc.Rect {
        let mat = cc.mat4();
        node.getWorldMatrix(mat);
        let result = cc.rect();
        rect.transformMat4(result, mat.invert());
        return result;
    }

    boundingBoxToOtherNode(boundingNode: cc.Node, otherNode: cc.Node): cc.Rect {
        const rect = boundingNode.getBoundingBoxToWorld();
        return this.rectWorldToNode(otherNode, rect);
    }

    /**
     * 强制保留2位小数
     * @param x 
     */
    changeTwoDecimalF(x) {
        var f_x = parseFloat(x);
        if (isNaN(f_x)) {
            return 0;
        }
        var f_x = Math.floor(x * 100) / 100;
        var s_x = f_x.toString();
        var pos_decimal = s_x.indexOf('.');
        if (pos_decimal < 0) {
            pos_decimal = s_x.length;
            s_x += '.';
        }
        while (s_x.length <= pos_decimal + 2) {
            s_x += '0';
        }
        return s_x;
    }

    objSignMd5(obj, salt = null) {
        let keys = Object.keys(obj);
        keys.sort()
        let signStr = '';
        let cnt = 0;
        keys.forEach(k => {
            if (cnt > 0) signStr += '&';
            signStr += k + '=' + obj[k];
            cnt++;
        })
        if (salt) signStr += salt;
        // cc.log('objSign:',signStr);
        return Md5Helper.do(signStr);
    }
    /**
     * 延迟指定时间
     * @param timeInSec 延迟秒数
     */
    delay(timeInSec: number): Promise<void> {
        return new Promise((resolve, reject) => {
            setTimeout(resolve, timeInSec * 1000);
        });
    }

    waitOneUpdate(script) {
        return new Promise((resolve, reject) => {
            script.scheduleOnce(() => {
                resolve(null);
            }, 0)
        });
    }

    createLoopLoader<T, P extends { [key: string]: T } | T[]>(obj: P, handler: (value: P[keyof P], key: keyof P, obj: P) => void, target?: any): Generator<any> {
        const fn = function* () {
            for (let i in obj) {
                yield handler.call(target, obj[i], i, obj);
            }
        };
        return fn();
    }

    getFirstValueInObj<T>(obj: T): T[keyof T] {
        return Object.values(obj)[0];
    }

    getRectPoints(rect: cc.Rect): [cc.Vec2, cc.Vec2, cc.Vec2, cc.Vec2] {
        return [cc.v2(rect.xMin, rect.yMin), cc.v2(rect.xMin, rect.yMax), cc.v2(rect.xMax, rect.yMax), cc.v2(rect.xMax, rect.yMin)];
    }

    private calPointRectVars(p: Vec, rect: cc.Rect): [number, number] {
        //a=0代表点在左右边的直线上，a<0代表点在左右边之间
        //b=0代表点在上下边的直线上，b<0代表点在上下边之间
        const a = (p.x - rect.xMin) * (p.x - rect.xMax);
        const b = (p.y - rect.yMax) * (p.y - rect.yMin);
        return [a, b];
    }
    isPointOnRect(p: Vec, rect: cc.Rect): boolean {
        const [a, b] = this.calPointRectVars(p, rect);
        return (a == 0 && b <= 0) || (b == 0 && a <= 0);
    }
    //不包括边界
    isPointInRectOpen(p: Vec, rect: cc.Rect): boolean {
        const [a, b] = this.calPointRectVars(p, rect);
        return a < 0 && b < 0;
    }
    isPointInRect(p: Vec, rect: cc.Rect): boolean {
        const [a, b] = this.calPointRectVars(p, rect);
        return a <= 0 && b <= 0;
    }
    isLineOnRect(p1: Vec, p2: Vec, rect: cc.Rect): boolean {
        return (p1.x == p2.x && (p1.x == rect.xMin || p1.x == rect.xMax)) || (p1.y == p2.y && (p1.y == rect.yMin || p1.y == rect.yMax));
    }
    //复制的，未测试
    isLineInterRect(p1: Vec, p2: Vec, rect: cc.Rect): boolean {
        const lineHeight = p1.y - p2.y;
        const lineWidth = p1.x - p2.x;
        // 计算叉乘 
        const c = p1.x * p2.y - p2.x * p1.y;
        if ((lineHeight * rect.xMin + lineWidth * rect.yMax + c >= 0 && lineHeight * rect.xMax + lineWidth * rect.yMin + c <= 0)
            || (lineHeight * rect.xMin + lineWidth * rect.yMax + c <= 0 && lineHeight * rect.xMax + lineWidth * rect.yMin + c >= 0)
            || (lineHeight * rect.xMin + lineWidth * rect.yMin + c >= 0 && lineHeight * rect.xMax + lineWidth * rect.yMax + c <= 0)
            || (lineHeight * rect.xMin + lineWidth * rect.yMin + c <= 0 && lineHeight * rect.xMax + lineWidth * rect.yMax + c >= 0)) {
            let xMin = rect.xMin, xMax = rect.xMax, yMin = rect.yMin, yMax = rect.yMax;
            if (xMin > xMax) {
                const temp = xMin;
                xMin = xMax;
                xMax = temp;
            }
            if (yMax < yMin) {
                const temp1 = yMax;
                yMax = yMin;
                yMin = temp1;
            }
            if ((p1.x < xMin && p2.x < xMin)
                || (p1.x > xMax && p2.x > xMax)
                || (p1.y > yMax && p2.y > yMax)
                || (p1.y < yMin && p2.y < yMin)) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    _timeoutRecord = {}
    timeoutTask(key, callback, time) {
        if (this._timeoutRecord[key]) return;
        this._timeoutRecord[key] = setTimeout(() => {
            this._timeoutRecord[key] = null;
            callback && callback();
        }, time)
    }

    randomKey(keys, probabilitys: number[]) {
        if (keys && probabilitys) {
            if (keys.length == probabilitys.length) {
                let allSum = 0;
                for (let i = 0; i < probabilitys.length; i++) {
                    allSum += probabilitys[i];
                }
                let random = this.getRandomClose(0, allSum);
                let sum = 0;
                for (let i = 0; i < keys.length; i++) {
                    if (random >= sum && random <= (sum + probabilitys[i])) {
                        return keys[i];
                    } else {
                        sum += probabilitys[i];
                    }
                }
                cc.error("randomKey error:", keys, probabilitys, sum, allSum);
                return null;
            } else {
                cc.error("keys length != probabilitys.length");
                return null;
            }
        } else {
            cc.error("keys&&probabilitys is false");
            return null;
        }
    }

    showNode(node: cc.Node) {
        node.active = true;
    }
    hideNode(node: cc.Node) {
        node.active = false;
    }
    switchNodes(showNodes: cc.Node[], hideNodes: cc.Node[]) {
        showNodes.forEach(this.showNode);
        hideNodes.forEach(this.hideNode);
    }

    getColorText(text: string | number, color: cc.Color | string): string {
        const clr = color instanceof cc.Color ? color.toHEX('#rrggbb') : color;
        return `<color=${clr}>${text}</c>`;
    }

    lerp(from: number, to: number, ratio: number): number {
        ratio = Math.round(ratio * 100) / 100;
        return Math.floor(from + (to - from) * ratio);
    }

    getNumberString(int: number, digit: number): string {
        const str = int.toFixed(0);
        digit = Math.max(str.length, digit);
        return '0'.repeat(digit).concat(str).slice(-digit);
    }

    private calPercentByPosition(position: cc.Vec3, contentNode: cc.Node, viewNode?: cc.Node): cc.Vec2 {
        const viewWidth = viewNode ? viewNode.width : 0, viewHeight = viewNode ? viewNode.height : 0;
        const scrollingWidth = contentNode.width - viewWidth || 1;
        const scrollingHeight = contentNode.height - viewHeight || 1;
        const percent = cc.v2(
            (position.x + contentNode.width * contentNode.anchorX - viewWidth / 2) / scrollingWidth,
            (position.y + contentNode.height * contentNode.anchorY - viewHeight / 2) / scrollingHeight
        );
        return percent;
    }
    //计算要把目标节点滚到视图中间需要传的百分比，如果位置不对，检查你的layout尺寸有没更新，计算绝对没问题
    calPercentInScrollView(scrollView: cc.ScrollView, targetNode: cc.Node): cc.Vec2 {
        const contentNode = scrollView.content;
        const pos = scrollView.content.convertToNodeSpaceAR(Util.nodeConvertToWorld(targetNode));

        const viewCpn = scrollView.node.getComponent(cc.Mask) || scrollView.content.parent.getComponent(cc.Mask);
        let viewNode = scrollView.node;
        if (viewCpn) {
            viewNode = viewCpn.node;
        }

        return this.calPercentByPosition(pos, contentNode, viewNode);
    }
    loadRemotePic(url: string, type = 'png'): Promise<cc.SpriteFrame> {
        if (!url) {
            return Promise.resolve(null);
        }
        return new Promise(res => {
            cc.loader.load({ url: url, type: type }, function (err, texture) {
                if (err) {
                    console.error(err);
                }
                let spriteFrame = new cc.SpriteFrame(texture);
                res(spriteFrame);
            });
        });
    }
    limit(num: number, min: number, max: number): number {
        return Math.max(min, Math.min(max, num));
    }

    getTextConfig(key: string, replace?: string): string {
        let text = DataFunc.query('text', key).text;
        if (replace) text = text.replace('$', replace);
        return text;
    }
    isWechat(): boolean {
        return cc.sys.platform == cc.sys.WECHAT_GAME;
    }
    private canVideo = true
    btnVideo(key: string | number): Promise<void> {
        if (!this.canVideo) return new Promise(res => null);
        this.canVideo = false;
        return new Promise(resl => {
            BusinessManager.do(() => {
                this.canVideo = true;
                Util.delay(0.2).then(resl);
            }, () => { this.canVideo = true; }, key);
        });
    }

}