type PromiseCreator = (...params: any) => Promise<any>
export const PromiseUtil = new class {
    delay(t: number): Promise<void> {
        return new Promise((resolve, reject) => {
            setTimeout(resolve, t * 1000);
        });
    }
    reject<T>(t?: T): Promise<T> {
        return new Promise(async (resolve, reject) => {
            await this.delay(0);
            reject(t);
        });
    }
    tween(tw: cc.Tween): Promise<any> {
        return new Promise(res => {
            tw.call(res).start();
        });
    }
    all(...funcs: PromiseCreator[]) {
        return Promise.all(funcs.map(f => { return f(); }));
    }
}
