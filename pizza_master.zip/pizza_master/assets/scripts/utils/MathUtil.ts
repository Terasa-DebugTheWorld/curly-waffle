export type MathFunc = (x: number) => number
export const MathUtil = new class {
    rotatePoint(pos: cc.Vec3, radian: number): cc.Vec3 {
        const orgRadian = cc.v2(1).signAngle(cc.v2(pos));
        const r = Math.sqrt(pos.x * pos.x + pos.y * pos.y)
        return cc.v3(r * Math.cos(orgRadian + radian), r * Math.sin(orgRadian + radian));
    }
}