export default new class {
    MMSS(sec, separator = ":") {
        let minute = Math.floor(sec / 60);
        let second = sec % 60;
        return `${minute < 10 ? '0' + minute : minute}${separator}${second < 10 ? '0' + second : second}`
    }
}