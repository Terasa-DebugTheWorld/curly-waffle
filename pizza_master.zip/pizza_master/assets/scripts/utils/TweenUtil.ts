import { Util } from "./Util";


export const TweenUtil = new class {
    jelly(node: cc.Node, times: number = 5, percent = 0.1): Promise<any> {
        times = Math.max(2, Math.min(19, times));
        const tw = cc.tween(node);
        let m = times / percent;
        for (let i = times; i > 0; i--) {
            const s = i / m;
            m = -m
            tw.to(0.1, { scaleX: 1 - s, scaleY: 1 + s });
        }
        return new Promise((resolve, reject) => {
            tw.to(0.1, { scale: 1 }).call(resolve).start();
        });
    }
    vibrate(node: cc.Node, cycle: number = 0.08, times: number = 3, min: number = 10, max: number = 30): Promise<any> {
        const sourcePos = node.position;
        const tw = cc.tween(node);
        for (let i = 0; i < times; i++) {
            const randomOffset = cc.v2(Util.getRandomClose(min, max)).rotate(Math.random() * Math.PI);
            tw.by(cycle / 2, { position: cc.v3(randomOffset) }).to(cycle / 2, { position: sourcePos });
        }
        return new Promise(res => {
            tw.call(res).start();
        });
    }

    play(tw: cc.Tween) {
        return new Promise<void>((resolve, reject) => {
            tw.call(() => {
                resolve();
            }).start();
        });
    }
}