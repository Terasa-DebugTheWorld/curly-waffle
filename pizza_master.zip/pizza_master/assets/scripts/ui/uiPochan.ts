import uiPanel from "../common/uiPanel";
import { CashDesk } from "../game/core/CashDesk";
import { PizzaLogic } from "../gameLogic/logics/PizzaLogic";
import { Util } from "../utils/Util";
import uiTopMain from "./uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiPochan extends uiPanel {

    onBtnQuit() {
        this.quit();
        PizzaLogic.reset();
        uiTopMain.ins.onUpdateGold();
        CashDesk.ins.newDay();
    }
    async onBtnVideo() {
        await Util.btnVideo('pc');
        this.quit();
        uiTopMain.ins.addGold(20);
        CashDesk.ins.newDay();
    }
}