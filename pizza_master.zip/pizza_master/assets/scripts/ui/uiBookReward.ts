import { Analysis } from "../3rd/Analysis";
import { BusinessManager } from "../3rd/BusinessManager";
import { getDadian } from "../3rd/dadian";
import DataFunc from "../common/DataFunc";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";
import { DtoRecipe, RecipeLogic } from "../gameLogic/logics/RecipeLogic";
import PizzaItem from "./items/pizzaItem";
import uiTopMain from "./uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiBookReward extends uiPanel {
    @property(PizzaItem)
    item: PizzaItem = null
    @property(cc.Label)
    label_diamond: cc.Label = null
    @property(cc.Label)
    label_bonus: cc.Label = null

    // LIFE-CYCLE CALLBACKS:
    onDisable() {
        uiBookReward.resl = null;
    }

    private static resl: Function
    public static open(data: DtoRecipe): Promise<boolean> {
        return new Promise(resl => {
            this.resl = resl;
            uiFunc.open(uiBookReward, data, { force: true });
        });
    }

    private recipeId: number
    setData(data: DtoRecipe): void {
        this.recipeId = data.id;
        this.item.setData(data);
        this.label_diamond.string = DataFunc.getBaseConfig('BOOK_DIAMOND');
        this.label_bonus.string = DataFunc.getBaseConfig('BOOK_VIDEO_DIAMOND');
        this.canTouch = true;
    }

    private canTouch = false
    onBtnGet() {
        if (!this.canTouch) return;
        this.canTouch = false;
        this.quit();
        RecipeLogic.gotReward(this.recipeId);
        uiTopMain.ins.addDiamond(DataFunc.getBaseConfig('BOOK_DIAMOND'));
        if (uiBookReward.resl) uiBookReward.resl(true);
        Analysis.event(getDadian('each_bookzs'));
    }
    onBtnVideo() {
        if (!this.canTouch) return;
        this.canTouch = false;
        const cnt = DataFunc.getBaseConfig('BOOK_VIDEO_DIAMOND');
        BusinessManager.do(() => {
            this.quit();
            RecipeLogic.gotReward(this.recipeId);
            uiTopMain.ins.addDiamond(cnt);
            if (uiBookReward.resl) uiBookReward.resl(true);
        }, () => this.canTouch = true, 'bookzs');
    }
    onBtnQuit() {
        this.quit();
        if (uiBookReward.resl) uiBookReward.resl(false);
    }
}