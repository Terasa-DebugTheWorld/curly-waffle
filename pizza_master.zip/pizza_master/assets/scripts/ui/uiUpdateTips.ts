import { Http } from "../3rd/Http";
import { NativeCall } from "../3rd/NativeCall";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";

const { ccclass, property } = cc._decorator;
const _APPID = 1471946954;
@ccclass
export class uiUpdateTips extends uiPanel {
    public static open() {
        if (cc.sys.platform == cc.sys.IPHONE || cc.sys.platform == cc.sys.IPAD) {
            let url = 'https://itunes.apple.com/cn/lookup?id=';
            // if (AppConfig.platform == PlatformCode.OVERSEAS) {
            //     url = 'https://itunes.apple.com/lookup?id=';
            // }
            url += _APPID;
            Http.post(url, null, null, (resp) => {
                console.log(JSON.stringify(resp));
                let json = JSON.parse(resp);
                let data = json.results[0];
                let version = data.version;
                console.log('Appstore version:', version);
                const remoteVersion = version;
                if (this.check(remoteVersion)) {
                    uiFunc.open(uiUpdateTips);
                }
            });
        }
    }

    private static check(remoteVer: string) {
        if (cc.sys.platform == cc.sys.IPHONE || cc.sys.platform == cc.sys.IPAD) {
            console.log('对比结果:', this.cmpVersion(remoteVer, NativeCall.getNativeVersion()))
            if (remoteVer && this.cmpVersion(remoteVer, NativeCall.getNativeVersion()) > 0) {
                return true
            }
        }
        return false;
    }
    //0:a=b,1:a>b,-1:a<b
    //先不考虑不等长的版本号
    private static cmpVersion(a, b) {
        if (a == b) return 0
        a = a.split('.');
        b = b.split('.');
        let maxLength = Math.max(a.length, b.length);
        for (let i = 0; i < maxLength; i++) {
            if (Number(a[i]) > Number(b[i])) {
                return 1;
            } else if (Number(a[i]) < Number(b[i])) {
                return -1;
            }
        }
    }

    private onBtnGoto() {
        // this.quit();
        NativeCall.openUrl('https://itunes.apple.com/cn/app/id' + _APPID);//https://apps.apple.com/cn/app/id
    }
    private static appsotreRate() {
        if (cc.sys.platform == cc.sys.IPHONE || cc.sys.platform == cc.sys.IPAD) {
            NativeCall.openUrl(`https://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=${_APPID}&pageNumber=0&sortOrdering=2&type=Purple+Software&mt=8`);
        } else if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "toRate", "()V");
        }
    }
}