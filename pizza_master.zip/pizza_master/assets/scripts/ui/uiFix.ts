import uiPanel from "../common/uiPanel";
import { CashDesk } from "../game/core/CashDesk";
import { Util } from "../utils/Util";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiFix extends uiPanel {

    private onBtnNo() {
        this.quit();
        CashDesk.ins.leftCnt = 2;
    }
    private async onBtnFix() {
        await Util.btnVideo('wx');
        this.quit();
        CashDesk.ins.leftCnt = 4;
    }
}
