import { BusinessManager } from "../3rd/BusinessManager";
import { WxSubpackageLoader } from "../3rd/WxSubpackageLoader";
import DataFunc from "../common/DataFunc";
import uiPanel from "../common/uiPanel";
import { PizzaLogic } from "../gameLogic/logics/PizzaLogic";
import { CurrencyType } from "../static/GameEnum";
import uiTopMain from "./uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiWelfare extends uiPanel {

    @property(cc.Label)
    t_talk1: cc.Label = null;
    @property(cc.Sprite)
    sp_icon: cc.Sprite = null;
    @property(cc.Label)
    t_talk2: cc.Label = null;

    private _data: { type: CurrencyType, num: number } = null;

    setData(data: { type: CurrencyType }): void {
        let ts = this;
        let currency: string = '';
        let icon: string = '';
        switch (data.type) {
            case CurrencyType.GOLD:
                currency = '钱币';
                icon = 'hexin_chaopiao'
                break;
            case CurrencyType.DIAMOND:
                currency = '钻石'
                icon = 'hexin_zuanshi'
                break;
        }
        const key = data.type == CurrencyType.GOLD ? 'VIDEO_ADD_GOLD' : 'VIDEO_ADD_DIAMOND';
        const num = DataFunc.getBaseConfig(key);
        ts.t_talk1.string = `观看广告可获得${currency}`;
        WxSubpackageLoader.loadSpriteFrame('resources', `textures/common/${icon}`).then((sf) => {
            ts.sp_icon.spriteFrame = sf;
        });
        ts._data = { type: data.type, num };
        ts.t_talk2.string = num + '';
    }

    onBtnClose(): void {
        let ts = this;
        ts.quit();
    }

    onBtnGet(): void {
        let ts = this;
        BusinessManager.do(async () => {
            switch (ts._data.type) {
                case CurrencyType.GOLD:
                    uiTopMain.ins.addGold(ts._data.num);
                    break;
                case CurrencyType.DIAMOND:
                    uiTopMain.ins.addDiamond(ts._data.num);
                    break;
            }
            ts.quit();
        }, null, ts._data.type == CurrencyType.GOLD ? 'jb' : 'zs');
    }
}