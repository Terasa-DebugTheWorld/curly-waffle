import uiPanel from "../common/uiPanel";
import { DecorateLogic } from "../gameLogic/logics/DecorateLogic";
import { decorationItem } from "./items/decorationItem";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiDecoration extends uiPanel {
    @property(cc.Node)
    nodes_tag: cc.Node[] = []
    @property(cc.Node)
    node_select: cc.Node = null
    @property(cc.ScrollView)
    sv: cc.ScrollView = null
    @property(cc.Prefab)
    prefab_item: cc.Prefab = null

    // LIFE-CYCLE CALLBACKS:
    private items: decorationItem[] = []
    protected onEnable(): void {
        this.setTag(null, '0');
    }

    private curTag = 0
    private setTag(e, tag: string) {
        const n = Number(tag);
        this.curTag = n;
        this.node_select.x = this.nodes_tag[n].x;
        this.refresh();
    }
    private refresh() {
        const cfgs = Object.values(DecorateLogic.getConfigs());
        let n = 0;
        for (let k in cfgs) {
            const cfg = cfgs[k];
            if (cfgs[k].tag == this.curTag) {
                if (n >= this.items.length) {
                    const node = cc.instantiate(this.prefab_item);
                    node.parent = this.sv.content;
                    this.items.push(node.getComponent(decorationItem));
                }
                this.items[n++].setData(cfg);
            }
        }
        for (; n < this.items.length; n++) {
            this.items[n].node.active = false;
        }
        this.sv.stopAutoScroll();
        this.sv.scrollToLeft();
    }
}