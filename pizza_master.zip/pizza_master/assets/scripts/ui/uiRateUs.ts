import { NativeCall } from "../3rd/NativeCall";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";
import GameUI from "../game/managers/GameUI";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiRateUs extends uiPanel {
    @property(cc.Node)
    node_layout: cc.Node = null
    @property(cc.Prefab)
    prefab_star: cc.Prefab = null

    public static open() {
        return;
        if (cc.sys.localStorage.getItem('rate') == 1) return;
        cc.sys.localStorage.setItem('rate', 1);
        uiFunc.open(uiRateUs);
    }

    // LIFE-CYCLE CALLBACKS:
    onLoad() {
        for (let i = 0; i < 5; i++) {
            const star = cc.instantiate(this.prefab_star);
            star.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
            this.node_layout.addChild(star);
        }
    }

    private cnt = 0
    private onTouch(event: cc.Event.EventTouch) {
        const target = event.target;
        const index = target.getSiblingIndex();
        this.cnt = index + 1;
        this.node_layout.children.forEach(node => node.children[0].active = node.getSiblingIndex() <= index);
    }
    private onCommit() {
        if (this.cnt == 0) {
            GameUI.inst.showToast('点击星星评分哦！');
            return;
        }
        this.quit();
        if (this.cnt < 5) return;
        NativeCall.iosStoreReview();
        console.log('user gave us 5 stars!');
    }
}