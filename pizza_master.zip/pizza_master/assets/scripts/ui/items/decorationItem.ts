import { Analysis } from "../../3rd/Analysis";
import { BusinessManager } from "../../3rd/BusinessManager";
import { getDadian } from "../../3rd/dadian";
import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { DecConfig, DecorateLogic } from "../../gameLogic/logics/DecorateLogic";
import { Util } from "../../utils/Util";
import uiTopMain from "../uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export class decorationItem extends cc.Component {
    @property(cc.Node)
    node_use: cc.Node = null
    @property(cc.Node)
    node_gold: cc.Node = null
    @property(cc.Node)
    node_diamond: cc.Node = null
    @property(cc.Node)
    node_using: cc.Node = null
    @property(cc.Node)
    node_video: cc.Node = null
    @property(cc.Label)
    label_currency: cc.Label = null
    @property(cc.Sprite)
    spr_icon: cc.Sprite = null
    @property(cc.Label)
    label_name: cc.Label = null

    private cfg: DecConfig
    public setData(cfg: DecConfig) {
        this.cfg = cfg;
        WxSubpackageLoader.loadSpriteFrame('more', 'uiDecorationIcons/' + cfg.icon)
            .then(sf => this.spr_icon.spriteFrame = sf);
        this.label_name.string = cfg.name;
        this.node.active = true;

        [this.node_gold.parent.parent, this.node_use, this.node_video].forEach(Util.hideNode);
        const isUnlock = DecorateLogic.isUnlock(cfg.id);
        if (isUnlock) {
            const using = DecorateLogic.getUsing(cfg.type);
            if (using == cfg.id) {
                this.node_using.active = true;
                decorationItem.usings[cfg.type] = this;
            } else {
                this.node_use.active = true;
            }
        } else {
            const cnt = cfg.gold || cfg.diamond;
            if (cnt) {
                this.label_currency.string = cnt + '';
                this.label_currency.node.parent.parent.active = true;
            } else {
                this.node_video.active = true;
            }
            this.node_gold.active = !cfg.diamond;
            this.node_diamond.active = !cfg.gold;
        }
    }

    public static usings: decorationItem[] = []
    public use() {
        DecorateLogic.use(this.cfg.type, this.cfg.id);
        const using = decorationItem.usings[this.cfg.type];
        if (using) using.unuse();
        this.node_use.active = false;
        this.node_using.active = true;
        decorationItem.usings[this.cfg.type] = this;
    }
    public unuse() {
        this.node_use.active = true;
        this.node_using.active = false;
    }
    public unlock() {
        DecorateLogic.unlock(this.cfg.id);
        this.use();
        this.node_video.active = this.node_gold.parent.parent.active = false;
        Analysis.event(getDadian("unlock_decorate_" + this.cfg.id as any));
    }

    public onBtnUse() {
        this.use();
    }
    public onBtnVideo() {
        BusinessManager.do(() => this.unlock(), () => { }, 'decorate_' + this.cfg.id);

    }
    public onBtnBuy(e: cc.Event.EventTouch) {
        const gold = this.cfg.gold;
        let succ = false;
        if (gold) {
            succ = uiTopMain.ins.useGold(gold, false, e.currentTarget, true);
        } else {
            succ = uiTopMain.ins.useDiamond(this.cfg.diamond, e.currentTarget, true);
        }
        if (succ) {
            this.unlock();
        }
    }
}