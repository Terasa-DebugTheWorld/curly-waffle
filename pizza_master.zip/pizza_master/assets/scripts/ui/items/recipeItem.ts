import { ClientEvent } from "../../common/ClientEvent";
import { DtoRecipe, RecipeLogic } from "../../gameLogic/logics/RecipeLogic";
import { EventType } from "../../static/EventType";
import PizzaItem from "./pizzaItem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class RecipeItem extends cc.Component {

    @property({ type: PizzaItem })
    pizzaItem: PizzaItem = null;

    @property(cc.Node)
    select: cc.Node = null;
    @property(cc.Node)
    new: cc.Node = null;


    private _data: DtoRecipe = null;

    private _isShowable: boolean = false;
    private _isUnlocked: boolean = false;

    protected onEnable(): void {
        let ts = this;
        ClientEvent.on(EventType.SELECT_RECIPE, ts.onSelectRecipe, ts);
    }

    protected onDisable(): void {
        let ts = this;
        ClientEvent.off(EventType.SELECT_RECIPE, ts.onSelectRecipe, ts);
        ts.node.off(cc.Node.EventType.TOUCH_END, ts.onClick, ts);
    }

    setData(data: DtoRecipe): void {
        let ts = this;
        if (data && data.id == 57) console.log('ok');
        if (ts._data && ts._data.id == 57 && !data) console.log('shit');
        if (ts._data && ts._data.id == 57 && data && data.id != 57) console.log('what');
        ts._data = data;
        ts._isShowable = true;
        // ts._isShowable = ts._data && RecipeLogic.isRecipeShowable(ts._data.id);
        ts._isUnlocked = ts._data && RecipeLogic.isUnlockedRecipe(ts._data.id);
        // ts.recipeName.string = ts._isUnlocked && ts._isShowable ? ts._data.name : '???';
        // ts.unkown.active = !ts._isUnlocked && ts._isShowable;
        // ts.pizzaItem.node.active = !ts.unkown.active;
        ts.pizzaItem.node.active && ts.pizzaItem.setData(data);
        ts.new.active = ts._data && RecipeLogic.isNewRecipe(ts._data.id);
        ts.select.active = false;
        if (ts._isUnlocked && ts._isShowable) {
            ts.node.on(cc.Node.EventType.TOUCH_END, ts.onClick, ts);
            if (ts._data && ts._data.id == 57) window.cn = ts.node
            if (ts._data) console.log('on:', ts._data.id)
        } else {
            ts.node.off(cc.Node.EventType.TOUCH_END, ts.onClick, ts);
            if (ts._data) console.log('off:', ts._data.id)
        }
    }

    onClick(e): void {
        let ts = this;
        if (!ts._isUnlocked || !ts._isShowable) return;
        ts.new.active = false;
        RecipeLogic.unNewRecipe(ts._data.id);
        ClientEvent.dispatch(EventType.SELECT_RECIPE, ts._data);
    }

    onSelectRecipe(data: DtoRecipe): void {
        let ts = this;
        ts.select.active = ts._data === data;
    }

}
