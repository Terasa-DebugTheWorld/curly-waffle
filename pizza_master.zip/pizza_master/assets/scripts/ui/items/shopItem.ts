import { Analysis } from "../../3rd/Analysis";
import { getDadian } from "../../3rd/dadian";
import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { CailiaoMgr } from "../../game/managers/CailiaoMgr";
import { DtoSliver, SliverLogic } from "../../gameLogic/logics/SliverLogic";
import uiShop from "../uiShop";
import uiTopMain from "../uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export default class ShopItem extends cc.Component {

    @property(cc.Sprite)
    sp_icon: cc.Sprite = null;
    @property(cc.Node)
    sp_gou: cc.Node = null;
    @property(cc.Node)
    btnBuy: cc.Node = null;
    @property(cc.Sprite)
    sp_buy: cc.Sprite = null;
    @property(cc.Label)
    t_buy: cc.Label = null;
    @property(cc.Label)
    t_name: cc.Label = null;
    @property(cc.Label)
    t_desc: cc.Label = null;

    _data: DtoSliver = null;

    setData(data: DtoSliver): void {
        let ts = this;
        ts._data = data;
        WxSubpackageLoader.loadSpriteFrame('more', `sliver/${data.shopShow}`).then((sf) => {
            ts.sp_icon.spriteFrame = sf;
        });
        ts.t_name.string = data.name;
        let isUnlocked: boolean = SliverLogic.isSliverUnlocked(data.id);
        ts.btnBuy.active = !isUnlocked;
        ts.sp_gou.active = isUnlocked;
        let unlockByGold: boolean = data.hasOwnProperty("unlockGold");
        let unlockByDimond: boolean = data.hasOwnProperty("unlockDiamond");
        if (unlockByGold) {
            WxSubpackageLoader.loadSpriteFrame('resources', `textures/common/hexin_chaopiao`).then((sf) => {
                ts.sp_buy.spriteFrame = sf;
            });
            ts.t_buy.string = data.unlockGold + '';
        } else if (unlockByDimond) {
            WxSubpackageLoader.loadSpriteFrame('resources', `textures/common/hexin_zuanshi`).then((sf) => {
                ts.sp_buy.spriteFrame = sf;
            });
            ts.t_buy.string = data.unlockDiamond + '';
        }
        let tipPER: number = data.tipPER;
        let hasTip: boolean = tipPER > 0;
        ts.t_desc.node.active = hasTip;
        if (hasTip) ts.t_desc.string = `小费:+${tipPER * 100}%`;
    }

    onBtnBuy(e: cc.Event.EventTouch): void {
        let ts = this;
        if (!ts._data) return;
        if (ts._data.hasOwnProperty("unlockGold")) {
            // let res: boolean = PizzaLogic.useGold(ts._data.unlockGold);
            const res = uiTopMain.ins.useGold(ts._data.unlockGold, false, e.currentTarget, true);
            if (res) {
                ts.buySucc();
            }
        }
        if (ts._data.hasOwnProperty("unlockDiamond")) {
            const res = uiTopMain.ins.useDiamond(ts._data.unlockDiamond, e.currentTarget, true);
            if (res) {
                ts.buySucc();
            }
        }
    }

    private buySucc() {
        const ts = this;
        SliverLogic.unlockSliver(ts._data.id);
        CailiaoMgr.ins.onBuySliver(ts._data.id);
        ts.btnBuy.active = false;
        ts.sp_gou.active = true;
        Analysis.event(getDadian("unlock_cailiao_" + ts._data.id as any));
        uiShop.unlockCnt++;
    }
}