import { DtoOrderRecord } from "../../gameLogic/logics/OrderLogic";
import { OrderRecordType } from "../../static/GameEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class OrderRecordItem extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    setData(data: DtoOrderRecord) {
        let ts = this;
        let align: cc.Label.HorizontalAlign = null;
        let color:cc.Color = new cc.Color();
        switch (data.target) {
            case OrderRecordType.GUEST:
                align = cc.Label.HorizontalAlign.LEFT;
                color.fromHEX('5f2c27');
                break;
            case OrderRecordType.YOU:
                align = cc.Label.HorizontalAlign.RIGHT;
                color.fromHEX('bb654b');
                break;
        }
        ts.label.node.color = color;
        ts.label.horizontalAlign = align;
        ts.label.string = data.content;
    }

}
