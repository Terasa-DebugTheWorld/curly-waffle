const { ccclass, property } = cc._decorator;

@ccclass
export default class SumItem extends cc.Component {

    @property(cc.Label)
    t_title: cc.Label = null;
    @property(cc.Label)
    t_gold: cc.Label = null;

    setData(data: { name: string, gold: number }): void {
        let ts = this;
        if(!data) return;
        ts.t_title.string = data.name;
        ts.t_gold.string = ts.formatGold(data.gold);
    }

    setTitle(title:string):void{
        let ts = this;
        ts.t_title.string = title;
    }

    setGold(gold:number):void{
        let ts = this;
        if(typeof gold !== "number") return;
        ts.t_gold.string = ts.formatGold(gold);
    }

    formatGold(gold: number): string {
        let ts = this;
        let color: cc.Color = new cc.Color();
        let operation: string = '';
        if (gold < 0) {
            color.fromHEX('#45942d');
            // operation = '-';
        } else {
            color.fromHEX('#d43749');
            operation = '+';
        }
        ts.t_gold.node.color = color;
        return `${operation}${gold}`;
    }

}
