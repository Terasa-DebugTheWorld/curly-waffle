import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { DtoSliver, SliverLogic } from "../../gameLogic/logics/SliverLogic";

const { ccclass, property } = cc._decorator;

@ccclass
export default class SliverItem extends cc.Component {

    @property(cc.Node)
    bg1: cc.Node = null;
    @property(cc.Node)
    bg2: cc.Node = null;

    @property(cc.Sprite)
    sliverIcon: cc.Sprite = null;
    @property(cc.Label)
    sliverName: cc.Label = null;

    @property(cc.Material)
    normalMat: cc.Material = null;
    @property(cc.Material)
    graymat: cc.Material = null;

    @property
    showName:boolean = true

    private _data: DtoSliver = null;

    setData(data: DtoSliver): void {
        let ts = this;
        ts._data = data;
        if (ts._data) {
            let id: number = ts._data.id;
            let isUnlocked: boolean = SliverLogic.isSliverUnlocked(id);
            ts.bg1.active = isUnlocked;
            ts.bg2.active = !isUnlocked;
            ts.sliverIcon.setMaterial(0, isUnlocked ? ts.normalMat : ts.graymat);
            ts.sliverIcon.node.active = true;
            ts.sliverName.node.active = ts.showName;
            ts.sliverName.string = isUnlocked ? ts._data.name : '???';
            let sliverSf: cc.SpriteFrame = SliverLogic.SliverSf[id];
            if (sliverSf) {
                ts.sliverIcon.spriteFrame = sliverSf;
            } else {
                ts.sliverIcon.spriteFrame = null;
                WxSubpackageLoader.loadSpriteFrame('more', `uiFoodAtlas/${ts._data.bookShow}`).then((sf) => {
                    if (sf) ts.sliverIcon.spriteFrame = sf;
                });
            }
        } else {
            ts.bg1.active = false;
            ts.bg2.active = true;
            ts.sliverIcon.node.active = false;
            ts.sliverName.node.active = false;
        }
    }

}
