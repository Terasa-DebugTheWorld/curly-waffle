import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { DtoRecipe, RecipeLogic } from "../../gameLogic/logics/RecipeLogic";
import { DtoSliver, SliverLogic } from "../../gameLogic/logics/SliverLogic";
import { PutType, SliverType } from "../../static/GameEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class PizzaItem extends cc.Component {

    @property(cc.Node)
    unkown: cc.Node = null;

    @property(cc.Label)
    pizzaName: cc.Label = null;

    @property(cc.Node)
    slivers: cc.Node = null;

    private _data: DtoRecipe = null;

    setData(data: DtoRecipe): void {
        let ts = this;
        ts._data = data;
        let isShowable:boolean = true;
        let isUnlocked:boolean = ts._data && RecipeLogic.isUnlockedRecipe(ts._data.id);

        ts.unkown.active = !isUnlocked && isShowable;
        ts.pizzaName.string = isUnlocked && isShowable ? ts._data.name : '???';

        if(ts._data){
            ts.slivers.destroyAllChildren();
            let sliverIds: number[] = data.sliverId;
            for (let i = 0; i < sliverIds.length; i++) {
                const sliverId = sliverIds[i];
                const dtoSliver: DtoSliver = SliverLogic.getSliverById(sliverId);
                ts.createSliver(dtoSliver);
            }
        }
    }

    createSliver(dto: DtoSliver): void {
        let ts = this;
        if(dto.class === SliverType.SAUCE) return;
        let node: cc.Node = new cc.Node();
        node.name = dto.name;
        node.group = 'ui';
        switch (dto.put) {
            case PutType.DRAG:
                node.width = node.height = 110;
                break;
            case PutType.PARTICLE:
                node.width = node.height = 100;
                break;
            case PutType.STRIP:
                node.width = node.height = 90;
                break;
        }
        ts.slivers.addChild(node);
        let sprite: cc.Sprite = node.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        WxSubpackageLoader.loadSpriteFrame('more', `sliver/${dto.pizzaShow}`).then((sf) => {
            sprite.spriteFrame = sf;
        });
    }

}
