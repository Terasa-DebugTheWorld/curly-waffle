import uiPanel from "../common/uiPanel";
import SliverItem from "./items/sliverItem";
import RecipeItem from "./items/recipeItem";
import { ClientEvent } from "../common/ClientEvent";
import { EventType } from "../static/EventType";
import { SliverType } from "../static/GameEnum";
import { DtoRecipe, RecipeLogic } from "../gameLogic/logics/RecipeLogic";
import { DtoSliver, SliverLogic } from "../gameLogic/logics/SliverLogic";
import { WxSubpackageLoader } from "../3rd/WxSubpackageLoader";
import PizzaItem from "./items/pizzaItem";
import uiFunc from "../common/uiFunc";
import { uiBookReward } from "./uiBookReward";

const { ccclass, property } = cc._decorator;

enum TabType {
    RECIPE,
    SLIVER
}

enum FlipDir {
    LEFT = -1,
    RIGHT = 1
}

@ccclass
export default class uiFoodAtlas extends uiPanel {

    @property(cc.Node)
    pageLeftStatic: cc.Node = null;
    @property(cc.Node)
    pageLeftFlip: cc.Node = null;
    @property(cc.Node)
    pageRightStatic: cc.Node = null;
    @property(cc.Node)
    pageRightFlip: cc.Node = null;

    @property(cc.RichText)
    pageNumStatic: cc.RichText = null;
    @property(cc.RichText)
    pageNumFlip: cc.RichText = null;

    @property(cc.Node)
    btnRecipe: cc.Node = null;
    @property(cc.Node)
    btnSliver: cc.Node = null;
    @property(cc.Node)
    fakeBtnRecipe: cc.Node = null;
    @property(cc.Node)
    fakeBtnSliver: cc.Node = null;

    @property(cc.Prefab)
    recipeItemPre: cc.Prefab = null;

    @property(cc.Prefab)
    sliverItemPre: cc.Prefab = null;

    @property(cc.Node)
    node_diamond: cc.Node = null

    private _curTab: TabType = null;
    public get CurTab(): TabType {
        return this._curTab;
    }
    public set CurTab(v: TabType) {
        let ts = this;
        ts._curTab = v;
        let recipeSibIdx: number = ts.btnRecipe.getSiblingIndex();
        let sliverSibIdx: number = ts.btnSliver.getSiblingIndex();
        ts.btnRecipe.setSiblingIndex(sliverSibIdx);
        ts.btnSliver.setSiblingIndex(recipeSibIdx);
        ts.fakeBtnRecipe.active = ts._curTab === TabType.RECIPE;
        ts.fakeBtnSliver.active = ts._curTab === TabType.SLIVER;
    }

    private _curPage: number = 1;
    public get CurPage(): number {
        return this._curPage;
    }
    public set CurPage(v: number) {
        let ts = this;
        if (ts._curPage === v) return;
        ts._curPage = v;
        if (ts._curPage < 1) ts._curPage = ts._maxPage;
        if (ts._curPage > ts._maxPage) ts._curPage = 1;
    }
    private _maxPage: number = 5;

    private _curSliverType: SliverType = SliverType.SAUCE;
    public get CurSliverType(): SliverType {
        return this._curSliverType;
    }
    public set CurSliverType(v: SliverType) {
        let ts = this;
        if (ts._curSliverType === v) return;
        ts._curSliverType = v;
        if (ts._curSliverType < 1) ts._curSliverType += ts._maxSliverType;
        if (ts._curSliverType > ts._maxSliverType) ts._curSliverType -= ts._maxSliverType;
    }
    private _maxSliverType: number = 5;

    private _curSelRecipe: DtoRecipe = null;

    private _isFlipping: boolean = false;

    private _flipDuration: number = 0.5;

    private _recipes: DtoRecipe[] = [];

    protected onEnable(): void {
        let ts = this;
        SliverLogic.loadSliverSf();
        SliverLogic.loadSliverTypeSf();
        ts._recipes = RecipeLogic.ShowableRecipes;
        ts._maxPage = Math.ceil(ts._recipes.length / 6);
        ts._maxSliverType = Object.keys(SliverType).length / 2;
        if (ts._maxSliverType % 2 == 1) ts._maxSliverType++;
        ts.reset();
        if (this._recipes.length > 0 && !this._curSelRecipe) {
            this.onSelectRecipe(this._recipes[0]);
        }
        ClientEvent.on(EventType.SELECT_RECIPE, ts.onSelectRecipe, ts);
    }

    protected onDisable(): void {
        let ts = this;
        ts.pageLeftFlip.cleanup();
        ts.pageRightFlip.cleanup();
        ClientEvent.off(EventType.SELECT_RECIPE, ts.onSelectRecipe, ts);
    }

    reset(): void {
        let ts = this;
        ts._isFlipping = false;
        ts._curSelRecipe = null;

        ts.CurTab = TabType.RECIPE;
        ts.CurPage = 1;
        ts.CurSliverType = SliverType.SAUCE;

        ts.updateLeftPageRecipeData(ts.pageLeftStatic, ts._curPage);
        ts.updateRecipePageNum(ts.pageLeftStatic, ts._curPage);
        ts.updateRightPageRecipeData(ts.pageRightStatic, ts._curSelRecipe);

        // ts.pageNumStatic.string = `页数 ${ts._curPage}/${ts._maxPage}`;
        // ts.pageNumStatic.string = `<b><color=#db452e>${ts._curPage}</color>/${ts._maxPage}</b>`;

        ts.pageLeftStatic.active = true;
        ts.pageLeftFlip.active = false;
        ts.pageLeftFlip.eulerAngles = cc.Vec3.ZERO;
        ts.pageLeftFlip.skewY = 0;

        ts.pageRightStatic.active = true;
        ts.pageRightFlip.active = false;
        ts.pageRightFlip.eulerAngles = cc.v3(0, 90, 0);
        ts.pageRightFlip.skewY = 8;
    }

    onBtnRecipe(): void {
        let ts = this;
        if (ts._isFlipping) return;
        if (ts._curTab === TabType.RECIPE) return;
        ts._isFlipping = true;
        ts.CurPage = 1;
        ts.CurTab = TabType.RECIPE;
        ts._curSelRecipe = null;

        let twLeft: cc.Tween<cc.Node> = null;
        let twRight: cc.Tween<cc.Node> = null;

        ts.updateRightPageRecipeData(ts.pageRightStatic, null);
        ts.updatePageSliverData(ts.pageRightFlip, ts._curSliverType + 1, TabType.SLIVER);

        twRight = cc.tween(ts.pageRightFlip);
        twRight.set({ active: true, eulerAngles: cc.Vec3.ZERO, skewY: 0 });
        twRight.to(ts._flipDuration, { eulerAngles: cc.v3(0, 90, 0), skewY: 8 });
        twRight.call(() => {
            ts.pageRightFlip.active = false;
        }, ts);
        twRight.start();

        ts.updatePageSliverData(ts.pageLeftStatic, ts._curSliverType, TabType.SLIVER);
        ts.updateLeftPageRecipeData(ts.pageLeftFlip, ts._curPage);
        ts.updateRecipePageNum(ts.pageLeftFlip, ts._curPage);

        twLeft = cc.tween(ts.pageLeftFlip);
        twLeft.set({ active: true, eulerAngles: cc.v3(0, 90, 0), skewY: -8 });
        twLeft.delay(ts._flipDuration);
        twLeft.to(ts._flipDuration, { eulerAngles: cc.Vec3.ZERO, skewY: 0 });
        twLeft.call(() => {
            ts.pageLeftFlip.active = false;
            ts.updateLeftPageRecipeData(ts.pageLeftStatic, ts._curPage);
            ts.updateRecipePageNum(ts.pageLeftStatic, ts._curPage);
            ts._isFlipping = false;
        }, ts);
        twLeft.start();

    }

    onBtnSliver(): void {
        let ts = this;
        if (ts._isFlipping) return;
        if (ts._curTab === TabType.SLIVER) return;
        ts._isFlipping = true;
        ts.CurSliverType = SliverType.SAUCE;
        ts.CurTab = TabType.SLIVER;
        ts._curSelRecipe = null;

        let twLeft: cc.Tween<cc.Node> = null;
        let twRight: cc.Tween<cc.Node> = null;

        ts.updatePageSliverData(ts.pageRightStatic, ts._curSliverType + 1);
        ts.updateRightPageRecipeData(ts.pageRightFlip, ts._curSelRecipe, TabType.RECIPE);
        twRight = cc.tween(ts.pageRightFlip);
        twRight.set({ active: true, eulerAngles: cc.Vec3.ZERO, skewY: 0 });
        twRight.to(ts._flipDuration, { eulerAngles: cc.v3(0, 90, 0), skewY: 8 });
        twRight.call(() => {
            ts.pageRightFlip.active = false;
        }, ts);
        twRight.start();

        ts.updatePageSliverData(ts.pageLeftFlip, ts._curSliverType);
        ts.updateSliverPageNum(ts.pageLeftFlip, ts._curSliverType);

        twLeft = cc.tween(ts.pageLeftFlip);
        twLeft.set({ active: true, eulerAngles: cc.v3(0, 90, 0), skewY: -8 });
        twLeft.delay(ts._flipDuration);
        twLeft.to(ts._flipDuration, { eulerAngles: cc.Vec3.ZERO, skewY: 0 });
        twLeft.call(() => {
            ts.pageLeftFlip.active = false;
            ts.updatePageSliverData(ts.pageLeftStatic, ts._curSliverType);
            ts.updateSliverPageNum(ts.pageLeftStatic, ts._curSliverType);
            ts._isFlipping = false;
        }, ts);
        twLeft.start();

    }

    onBtnLeft(): void {
        let ts = this;
        if (ts._isFlipping) return;
        //左翻页
        ts.flip(FlipDir.LEFT);
    }

    onBtnRight(): void {
        let ts = this;
        if (ts._isFlipping) return;
        //右翻页
        ts.flip(FlipDir.RIGHT);
    }

    onBtnClose(): void {
        let ts = this;
        ts.quit();
    }

    flip(dir: FlipDir): void {
        let ts = this;
        let twLeft: cc.Tween<cc.Node> = null;
        let twRight: cc.Tween<cc.Node> = null;
        ts._isFlipping = true;
        switch (dir) {
            case FlipDir.RIGHT:
                ts.onPageLeftFlipRightStart();
                twLeft = cc.tween(ts.pageLeftFlip);
                twLeft.set({ active: true, eulerAngles: cc.Vec3.ZERO, skewY: 0 });
                twLeft.to(ts._flipDuration, { eulerAngles: cc.v3(0, 90, 0), skewY: -8 });
                twLeft.call(ts.onPageLeftFlipRightEnd, ts);
                twLeft.start();

                ts.onPageRightFlipRightStart();
                twRight = cc.tween(ts.pageRightFlip);
                twRight.set({ active: true, eulerAngles: cc.v3(0, 90, 0), skewY: 8 });
                twRight.delay(ts._flipDuration);
                twRight.to(ts._flipDuration, { eulerAngles: cc.Vec3.ZERO, skewY: 0 });
                twRight.call(ts.onPageRightFlipRightEnd, ts);
                twRight.start();
                break;
            case FlipDir.LEFT:
                ts.onPageRightFlipLeftStart();
                twRight = cc.tween(ts.pageRightFlip);
                twRight.set({ active: true, eulerAngles: cc.Vec3.ZERO, skewY: 0 });
                twRight.to(ts._flipDuration, { eulerAngles: cc.v3(0, 90, 0), skewY: 8 });
                twRight.call(ts.onPageRightFlipLeftEnd, ts);
                twRight.start();

                ts.onPageLeftFlipLeftStart();
                twLeft = cc.tween(ts.pageLeftFlip);
                twLeft.set({ active: true, eulerAngles: cc.v3(0, 90, 0), skewY: -8 });
                twLeft.delay(ts._flipDuration);
                twLeft.to(ts._flipDuration, { eulerAngles: cc.Vec3.ZERO, skewY: 0 });
                twLeft.call(ts.onPageLeftFlipLeftEnd, ts);
                twLeft.start();
                break;
        }
    }

    onPageLeftFlipRightStart(): void {
        let ts = this;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts.updateLeftPageRecipeData(ts.pageLeftFlip, ts._curPage);
                ts.updateLeftPageRecipeData(ts.pageLeftStatic, ts._curPage + 1);
                ts.updateRecipePageNum(ts.pageLeftFlip, ts._curPage);
                ts.updateRecipePageNum(ts.pageLeftStatic, ts._curPage + 1);
                // ts.pageNumFlip.string = `<b><color=#db452e>${ts._curPage}</color>/${ts._maxPage}</b>`;
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts.getPage(1)}</color>/${ts._maxPage}</b>`;
                break;
            case TabType.SLIVER:
                ts.updatePageSliverData(ts.pageLeftFlip, ts._curSliverType);
                ts.updatePageSliverData(ts.pageLeftStatic, ts._curSliverType - 2);
                ts.updateSliverPageNum(ts.pageLeftFlip, ts._curSliverType);
                ts.updateSliverPageNum(ts.pageLeftStatic, ts._curSliverType - 2);
                // ts.pageNumFlip.string = `<b><color=#db452e>${ts._curSliverType}</color>/${ts._maxSliverType}</b>`;
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts.getSliverType(-2)}</color>/${ts._maxSliverType}</b>`;
                break;
        }

    }
    onPageLeftFlipRightEnd(): void {
        let ts = this;
        ts.pageLeftFlip.active = false;
    }
    onPageRightFlipRightStart(): void {
        let ts = this;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts.updateRightPageRecipeData(ts.pageRightFlip, null);
                ts.updateRightPageRecipeData(ts.pageRightStatic, ts._curSelRecipe);
                break;
            case TabType.SLIVER:
                ts.updatePageSliverData(ts.pageRightFlip, ts._curSliverType - 1);
                break;
        }
    }

    onPageRightFlipRightEnd(): void {
        let ts = this;
        ts.pageRightFlip.active = false;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts.updateRightPageRecipeData(ts.pageRightStatic, null);
                ts.updateRightPageRecipeData(ts.pageRightFlip, null);
                ts._curSelRecipe = null;
                ts.CurPage++;
                break;
            case TabType.SLIVER:
                ts.updatePageSliverData(ts.pageRightStatic, ts._curSliverType - 1);
                ts.CurSliverType -= 2;
                break;
        }
        ts._isFlipping = false;
    }

    onPageRightFlipLeftStart(): void {
        let ts = this;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts.updateRightPageRecipeData(ts.pageRightFlip, ts._curSelRecipe);
                ts.updateRightPageRecipeData(ts.pageRightStatic, null);
                ts.updateRecipePageNum(ts.pageLeftFlip, ts._curPage - 1);
                // ts.updateRecipePageNum(ts.pageLeftStatic,ts._curPage);
                // ts.pageNumFlip.string = `<b><color=#db452e>${ts.getPage(-1)}</color>/${ts._maxPage}</b>`;
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts._curPage}</color>/${ts._maxPage}</b>`;
                break;
            case TabType.SLIVER:
                ts.updatePageSliverData(ts.pageRightFlip, ts._curSliverType + 1);
                ts.updatePageSliverData(ts.pageRightStatic, ts._curSliverType + 3);
                ts.updateSliverPageNum(ts.pageLeftFlip, ts._curSliverType + 2);
                // ts.updateSliverPageNum(ts.pageLeftStatic, ts._curSliverType + 3);
                // ts.pageNumFlip.string = `<b><color=#db452e>${ts.getSliverType(1)}</color>/${ts._maxSliverType}</b>`;
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts.getSliverType(3)}</color>/${ts._maxSliverType}</b>`;
                break;
        }
    }

    onPageRightFlipLeftEnd(): void {
        let ts = this;
        ts.pageRightFlip.active = false;
    }
    onPageLeftFlipLeftStart(): void {
        let ts = this;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts.updateLeftPageRecipeData(ts.pageLeftFlip, ts._curPage - 1);
                ts.updateLeftPageRecipeData(ts.pageLeftStatic, ts._curPage);
                break;
            case TabType.SLIVER:
                ts.updatePageSliverData(ts.pageLeftFlip, ts._curSliverType + 2);
                ts.updatePageSliverData(ts.pageLeftStatic, ts._curSliverType);
                break;
        }
    }
    onPageLeftFlipLeftEnd(): void {
        let ts = this;
        ts.pageLeftFlip.active = false;
        switch (ts._curTab) {
            case TabType.RECIPE:
                ts._curSelRecipe = null;
                ts.CurPage--;
                ts.updateLeftPageRecipeData(ts.pageLeftStatic, ts._curPage);
                ts.updateRecipePageNum(ts.pageLeftStatic, ts._curPage);
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts._curPage}</color>/${ts._maxPage}</b>`;
                break;
            case TabType.SLIVER:
                ts.CurSliverType += 2;
                ts.updatePageSliverData(ts.pageLeftStatic, ts._curSliverType);
                ts.updateSliverPageNum(ts.pageLeftStatic, ts._curSliverType);
                // ts.pageNumStatic.string = `<b><color=#db452e>${ts._curSliverType}</color>/${ts._maxSliverType}</b>`;
                break;
        }
        ts._isFlipping = false;
    }

    public getPage(extra: number = 0, page?: number): number {
        let ts = this;
        if (!page) page = ts._curPage;
        page += extra;
        if (page < 1) page = ts._maxPage;
        if (page > ts._maxPage) page = 1;
        return page;
    }

    public getSliverType(extra: number = 0, sliverType?: number): number {
        let ts = this;
        if (!sliverType) sliverType = ts._curSliverType;
        sliverType += extra;
        if (sliverType < 1) sliverType = ts._maxSliverType;
        if (sliverType > ts._maxSliverType) sliverType = 1;
        return sliverType;
    }

    onSelectRecipe(dto: DtoRecipe): void {
        let ts = this;
        if (!dto || ts._curSelRecipe === dto) return;
        ts._curSelRecipe = dto;
        ts.updateRightPageRecipeData(ts.pageRightFlip, ts._curSelRecipe);
        ts.updateRightPageRecipeData(ts.pageRightStatic, ts._curSelRecipe);
    }

    updateLeftPageRecipeData(pageNode: cc.Node, page: number, tab?: TabType): void {
        let ts = this;
        if (page < 1) page = ts._maxPage;
        if (page > ts._maxPage) page = 1;
        if (tab === undefined) tab = ts._curTab;
        let pages: cc.Node = pageNode.getChildByName('pages');
        pages.children.forEach((child: cc.Node, index: number) => {
            child.active = tab === index;
            if (child.active) {
                let container: cc.Node = child.getChildByName('container');
                container.children.forEach((item: cc.Node, idx: number, children: cc.Node[]) => {
                    let itemCntPerPage: number = children.length;
                    let dataIdx: number = itemCntPerPage * (page - 1) + idx;
                    let recipeItem: RecipeItem = item.getComponent(RecipeItem);
                    let dtoRecipe: DtoRecipe = ts._recipes[dataIdx];
                    recipeItem && recipeItem.setData(dtoRecipe);
                });
            }
        });
    }

    updateRightPageRecipeData(pageNode: cc.Node, selRecipe: DtoRecipe, tab?: TabType): void {
        let ts = this;
        if (tab === undefined) tab = ts._curTab;
        let pages: cc.Node = pageNode.getChildByName('pages');
        pages.children.forEach((child: cc.Node, index: number) => {
            child.active = tab === index;
            if (child.active) {
                let pizzaNode: cc.Node = child.getChildByName('pizzaItem');
                if (pizzaNode) {
                    let pizzaItem: PizzaItem = pizzaNode.getComponent(PizzaItem);
                    pizzaItem && pizzaItem.setData(selRecipe);
                }
                let container: cc.Node = child.getChildByName('container');
                container.children.forEach((item: cc.Node, idx: number, children: cc.Node[]) => {
                    let dataId: number = -1;
                    let sliverItem: SliverItem = null;
                    sliverItem = item.getComponent(SliverItem);
                    let recipe = selRecipe;
                    if (recipe) {
                        let sliverIds: number[] = recipe.sliverId;
                        if (idx < sliverIds.length) dataId = sliverIds[idx];
                    }
                    sliverItem && sliverItem.setData(SliverLogic.getSliverById(dataId));
                });
            }
        });
        this.node_diamond.active = selRecipe &&
            RecipeLogic.isUnlockedRecipe(selRecipe.id)
            && RecipeLogic.hasReward(selRecipe.id);
    }

    updatePageSliverData(pageNode: cc.Node, sliverType: SliverType, tab?: TabType): void {
        let ts = this;
        if (sliverType < 1) sliverType += ts._maxSliverType;
        if (sliverType > ts._maxSliverType) sliverType -= ts._maxSliverType;
        if (tab === undefined) tab = ts._curTab;
        let dtoSlivers: DtoSliver[] = SliverLogic.getSliversByType(sliverType);
        let pages: cc.Node = pageNode.getChildByName('pages');
        pages.children.forEach((child: cc.Node, index: number) => {
            child.active = tab === index;
            if (child.active) {
                let n_sliverType: cc.Node = child.getChildByName('sliverType');
                let container: cc.Node = child.getChildByName('container');
                let exist: boolean = Object.values(SliverType).includes(sliverType);
                n_sliverType.active = exist;
                container.active = exist;
                if (exist) {
                    let s_sliverType: cc.Sprite = n_sliverType.getComponent(cc.Sprite);
                    let sliverTypeSf = SliverLogic.SliverTypeSf[sliverType];
                    if (sliverTypeSf) {
                        s_sliverType.spriteFrame = sliverTypeSf;
                    } else {
                        let icon: string = SliverLogic.getSliverTypeIcon(sliverType);
                        WxSubpackageLoader.loadSpriteFrame('more', `uiFoodAtlas/${icon}`).then((sf) => {
                            s_sliverType.spriteFrame = sf;
                        });
                    }
                    container.children.forEach((item: cc.Node, idx: number) => {
                        let data: DtoSliver = idx < dtoSlivers.length ? dtoSlivers[idx] : null;
                        let sliverItem: SliverItem = item.getComponent(SliverItem);
                        sliverItem && sliverItem.setData(data);
                    });
                }

            }
        });
        this.node_diamond.active = false;
    }

    updateRecipePageNum(pageNode: cc.Node, page: number): void {
        let ts = this;
        if (page < 1) page = ts._maxPage;
        if (page > ts._maxPage) page = 1;
        let pages: cc.Node = pageNode.getChildByName('pages');
        let recipePage: cc.Node = pages.getChildByName('recipePage');
        let pageNum: cc.RichText = recipePage.getChildByName('pageNum').getComponent(cc.RichText);
        pageNum.string = `<b><color=#db452e>${page}</color>/${ts._maxPage}</b>`;
    }

    updateSliverPageNum(pageNode: cc.Node, sliverType: number): void {
        let ts = this;
        if (sliverType < 1) sliverType = ts._maxSliverType;
        if (sliverType > ts._maxSliverType) sliverType = 1;
        let pages: cc.Node = pageNode.getChildByName('pages');
        let sliverPage: cc.Node = pages.getChildByName('sliverPage');
        let pageNum: cc.RichText = sliverPage.getChildByName('pageNum').getComponent(cc.RichText);
        pageNum.string = `<b><color=#db452e>${Math.ceil(sliverType / 2)}</color>/${ts._maxSliverType / 2}</b>`;
    }

    createPageRecipeItem(pageNode: cc.Node, cnt: number): void {
        let ts = this;
        let pages: cc.Node = pageNode.getChildByName('pages');
        let recipePage: cc.Node = pages.getChildByName('recipePage');
        let container: cc.Node = recipePage.getChildByName('container');
        for (let i = 0; i < cnt; i++) {
            let n: cc.Node = cc.instantiate(ts.recipeItemPre);
            container.addChild(n);
        }
    }

    createPageSliverItem(pageNode: cc.Node, cnt: number): void {
        let ts = this;
        let pages: cc.Node = pageNode.getChildByName('pages');
        let recipePage: cc.Node = pages.getChildByName('sliverPage');
        let container: cc.Node = recipePage.getChildByName('container');
        for (let i = 0; i < cnt; i++) {
            let n: cc.Node = cc.instantiate(ts.sliverItemPre);
            container.addChild(n);
        }
    }

    onBtnReward() {
        uiBookReward.open(this._curSelRecipe).then(succ => {
            if (succ) this.node_diamond.active = false;
        });
    }
}