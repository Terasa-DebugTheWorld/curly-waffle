import { Ad } from "../3rd/Ad";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";
import UserData from "../userdata/UserData";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiVivoPrivacy extends uiPanel {
    @property(cc.Label)
    label_content: cc.Label = null
    @property
    app_name = ''

    onLoad(): void {
        if (!this.app_name) return;
        let text = this.label_content.string;
        text = text.replace(new RegExp('召唤神龙模拟器', 'g'), this.app_name);
        text = text.replace(new RegExp('成都景辰互娱科技有限公司', 'g'), '广州娜迦精灵科技有限公司');
        this.label_content.string = text;
    }

}