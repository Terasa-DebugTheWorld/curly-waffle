import { NativeCall } from "../3rd/NativeCall";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";
import UserData from "../userdata/UserData";
import { uiVivoPrivacy } from "./uiVivoPrivacy";
import GameUI from "../game/managers/GameUI";

const { ccclass, property } = cc._decorator;

@ccclass
export class uiAgreement extends uiPanel {

    public static open(): boolean {
        if (UserData.get('privacy') == 1) return false;
        uiFunc.open(uiAgreement);
        return true;
    }

    // LIFE-CYCLE CALLBACKS:
    protected onDisable(): void {

    }

    private onAgree() {
        UserData.set('privacy', 1);
        this.quit();
    }
    private onDisagree() {
        GameUI.inst.showToast('您需要同意使用条款和隐私政策才能继续游戏');
    }
    private openPrivacy() {
        uiFunc.open(uiVivoPrivacy, null, { force: true });
    }
}