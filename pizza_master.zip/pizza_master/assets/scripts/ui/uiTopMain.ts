import { ClientEvent } from "../common/ClientEvent";
import DataFunc from "../common/DataFunc";
import uiFunc from "../common/uiFunc";
import { CashDesk } from "../game/core/CashDesk";
import { PizzaLogic } from "../gameLogic/logics/PizzaLogic";
import { SaleLogic } from "../gameLogic/logics/SaleLogic";
import { EffectMgr } from "../managers/EffectMgr";
import { EventType } from "../static/EventType";
import { CurrencyType } from "../static/GameEnum";
import { Util } from "../utils/Util";
import uiOrderRecord from "./uiOrderRecord";
import uiSummary from "./uiSummary";
import uiWelfare from "./uiWelfare";

const { ccclass, property } = cc._decorator;
const TIME_PER_CAKE = 40;

@ccclass
export default class uiTopMain extends cc.Component {

    @property(cc.Sprite)
    di_time: cc.Sprite = null;
    @property(cc.Sprite)
    di_favor: cc.Sprite = null;
    @property(cc.Sprite)
    di_gold: cc.Sprite = null;
    @property(cc.Sprite)
    di_diamond: cc.Sprite = null;
    @property(cc.Sprite)
    di_atlas: cc.Sprite = null;
    @property(cc.Sprite)
    di_pause: cc.Sprite = null;
    @property(cc.Node)
    node_face2: cc.Node = null
    @property(cc.Node)
    node_face3: cc.Node = null
    @property(cc.Node)
    node_tip: cc.Node = null

    @property(cc.Sprite)
    sp_pm: cc.Sprite = null;
    @property(cc.Sprite)
    sp_favor: cc.Sprite = null;

    @property(cc.Label)
    t_date: cc.Label = null;
    @property(cc.Label)
    t_time: cc.Label = null;
    @property(cc.Label)
    t_pm: cc.Label = null;
    @property(cc.Label)
    t_favor: cc.Label = null;
    @property(cc.Label)
    t_gold: cc.Label = null;
    @property(cc.Label)
    t_diamond: cc.Label = null;

    public static ins: uiTopMain
    protected onLoad(): void {
        uiTopMain.ins = this;
        window.utm = this;
    }
    protected start(): void {
        this.t_gold.string = PizzaLogic.getTempGold() + '';
        this.t_diamond.string = PizzaLogic.getDiamond() + '';
        this.resetTime();
    }
    protected onEnable(): void {
        let ts = this;
        // ClientEvent.on(EventType.UPDATE_TIME, ts.onUpdateTime, ts);
        // ClientEvent.on(EventType.UPDATE_FAVOR, ts.onUpdateFavor, ts);
        // ClientEvent.on(EventType.UPDATE_GOLD, ts.onUpdateGold, ts);
        // ClientEvent.on(EventType.UPDATE_DIAMOND, ts.onUpdateDiamond, ts);
    }
    protected update(dt: number): void {
        if (uiFunc.uiList.length > 0) return;
        this.timeTick(dt);
        this.favorTick(dt);
    }
    protected onDisable(): void {
        let ts = this;
        // ClientEvent.off(EventType.UPDATE_TIME, ts.onUpdateTime, ts);
        // ClientEvent.off(EventType.UPDATE_FAVOR, ts.onUpdateFavor, ts);
        // ClientEvent.off(EventType.UPDATE_GOLD, ts.onUpdateGold, ts);
        // ClientEvent.off(EventType.UPDATE_DIAMOND, ts.onUpdateDiamond, ts);
    }

    public pauseAll() {
        this.isTimePause = this.isFavorPause = true;
    }
    public resumeAll() {
        this.isTimePause = this.isFavorPause = false;
    }
    private isTimePause = true
    public pauseTime() {
        this.isTimePause = true;
    }
    public resumeTime() {
        this.isTimePause = false;
    }
    private isFavorPause = true
    public pauseFavor() {
        this.isFavorPause = true;
    }
    public resumeFavor() {
        this.isFavorPause = false;
    }

    public showTips() {
        this.node_tip.active = true;
    }
    public hideTips() {
        this.node_tip.active = false;
    }

    private ft = 0
    private favorTick(dt: number) {
        if (this.isFavorPause) return;
        this.ft += dt;
        const itv = 3;
        if (this.ft < itv) return;
        this.ft -= itv;
        this.subFavor(1);
    }
    private tt = 0
    private h = 0
    private min = 0
    private timeTick(dt: number) {
        if (this.isTimePause) return;
        /**
         * 煎饼游戏内时间规则v2.0：
         * 营业时间是12:00pm~09:00pm；

         * 每个饼制作40秒的标准：
         * 第1天约做2个饼，80s；
         * 每天上涨35s，240s封顶。
         */
        const day = PizzaLogic.getDay();
        this.tt += dt;
        const t1 = DataFunc.getBaseConfig('TIME_DEFAULT'),
            timeAdd = DataFunc.getBaseConfig('TIME_EACHADD'),
            timeMax = DataFunc.getBaseConfig('TIME_MAX');
        const total = Math.min(timeMax, t1 + day * timeAdd);
        const itv = total / 9 / 4;  //9个小时，每小时4刻钟
        if (this.tt < itv) return;
        this.tt -= itv;
        this.addTime(15);
    }

    private favor = 100
    public resetFavor() {
        this.favor = 100;
        this.t_favor.string = this.favor + '%';
        this.ft = this.tt = 0;
        this.t_favor.string = 100 + '%';
        this.node_face2.active = this.node_face3.active = false;
    }
    public subFavor(n: number) {
        this.favor = Math.max(this.favor - n, 0);
        this.t_favor.string = this.favor + '%';
        if (this.favor <= 10) {
            this.node_face3.active = true;
        } else if (this.favor <= 50) {
            this.node_face2.active = true;
        }
    }

    public resetTime() {
        this.h = this.min = this.tt = 0;
        this.t_time.string = '00:00';
        this.t_date.string = this.getDate();
    }
    public getDate(): string {
        const date = new Date(new Date('1970/1/1').getTime() + 24 * 60 * 60 * 1000 * PizzaLogic.getDay());
        return date.getMonth() + 1 + '月' + date.getDate() + '日';
    }
    public getYesterday(): string {
        const date = new Date(new Date('1970/1/1').getTime() + 24 * 60 * 60 * 1000 * (PizzaLogic.getDay() - 1));
        return date.getMonth() + 1 + '月' + date.getDate() + '日';
    }

    private addTime(min: number) {
        this.min += min;
        if (this.h >= 9) return;
        if (this.min >= 60) {
            this.min -= 60;
            this.h++;
        }
        if (this.isSaleEnd()) {
            this.pauseTime();
            CashDesk.ins.onNight();
            if (CashDesk.ins.node.active) {
                CashDesk.ins.onTimeUp();
            }
        }
        this.t_time.string = Util.getNumberString(this.h, 2) + ':' + Util.getNumberString(this.min, 2);
    }
    public isSaleEnd(): boolean {
        return this.h >= 9;
    }

    public async addGold(cnt: number, isTemp = false, needAnim = true) {
        PizzaLogic.addGold(cnt, isTemp);
        if (needAnim) {
            await EffectMgr.playAddGold();
        }
        this.onUpdateGold();
    }
    public async addDiamond(cnt: number) {
        PizzaLogic.addDiamond(cnt);
        await EffectMgr.playAddDiamond();
        this.onUpdateDiamond();
    }
    public useGold(cnt: number, isCredit = true, target?: cc.Node, needAdd = false): boolean {
        const succ = isCredit ? PizzaLogic.useGoldCredit(cnt) : PizzaLogic.useGold(cnt);
        if (!succ) {
            if (needAdd) uiFunc.open(uiWelfare, { type: CurrencyType.GOLD }, { force: true });
            return false;
        }
        if (target) {
            EffectMgr.playUseGold(cnt, target).then(() => this.onUpdateGold());
        }
        this.onUpdateGold();
        return true;
    }
    public useDiamond(cnt: number, target?: cc.Node, needAdd = false): boolean {
        const succ = PizzaLogic.useDiamond(cnt);
        if (!succ) {
            if (needAdd) uiFunc.open(uiWelfare, { type: CurrencyType.DIAMOND }, { force: true });
            return false;
        }
        if (target) {
            EffectMgr.playUseDiamond(cnt, target).then(() => this.onUpdateDiamond());
            return true;
        }
        this.onUpdateDiamond();
        return true;
    }

    /**加钱 */
    onBtnAddGold(): void {
        uiFunc.open(uiWelfare, { type: CurrencyType.GOLD }, { force: true });
    }

    /**加钻石 */
    onBtnAddDiamond(): void {
        uiFunc.open(uiWelfare, { type: CurrencyType.DIAMOND }, { force: true });
    }

    /**打开图鉴界面 */
    onBtnAtlas(): void {
        uiFunc.open('uiFoodAtlas');
    }

    onBtnOrderRecord() {
        uiFunc.open(uiOrderRecord);
    }

    /**打开暂停界面 */
    onBtnPause(): void {

    }

    /**更新时间 */
    onUpdateTime(time: number): void {
        let ts = this;
    }

    /**更新好感度 */
    onUpdateFavor(favor: number): void {
        let ts = this;
        ts.t_favor.string = `${favor * 100}%`;
    }

    /**更新金币 */
    onUpdateGold(): void {
        let ts = this;
        ts.t_gold.string = PizzaLogic.getGold() + '';
    }

    /**更新钻石 */
    onUpdateDiamond(): void {
        let ts = this;
        ts.t_diamond.string = PizzaLogic.getDiamond() + '';
    }
}