import { Platform, PlatformEnum } from "../3rd/Platform";

const { ccclass, property } = cc._decorator;

@ccclass
export class VivoPrivacyEntry extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
    }
}