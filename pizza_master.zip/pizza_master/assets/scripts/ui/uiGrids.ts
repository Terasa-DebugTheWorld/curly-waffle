import { Ad } from "../3rd/Ad";
import uiPanel from "../common/uiPanel";
import { InsertMgr } from "../managers/InsertMgr";
import WxGridData from "../sdks/wx/grid/WxGridData";

const {ccclass, property} = cc._decorator;

@ccclass
export default class uiGrids extends uiPanel {
    protected onEnable(): void {
        WxGridData.closeContainer("zhuye");
        InsertMgr.instance.stop = true;
        InsertMgr.instance.autoTimer.pause();
    }

    protected onDisable(): void {
        WxGridData.showContainer("zhuye")
        InsertMgr.instance.stop = false;
        InsertMgr.instance.autoTimer.resume();
    }

    onClose(){

    }
}
