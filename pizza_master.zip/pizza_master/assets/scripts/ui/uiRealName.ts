import { nSdk } from './../sdks/wx/nSdk';
import { Http } from "../3rd/Http";
import Md5Helper from "../3rd/Md5Helper";
import { NativeCall } from "../3rd/NativeCall";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";

const getDateFromId = function (id: string): Date {
    return new Date(id.substr(6, 4) + '/' + id.substr(10, 2) + '/' + id.substr(12, 2));
};
const getParamStr = function (param: Dictionary<string>): string {
    let str = '?';
    for (let k in param) {
        if (str.length > 1) str += '&';
        str += k + '=' + param[k];
    }
    return str;
}
const { ccclass, property } = cc._decorator;
@ccclass
export class uiRealName extends uiPanel {
    @property(cc.Node)
    node_region: cc.Node = null
    @property(cc.Node)
    node_verify: cc.Node = null
    @property(cc.Node)
    node_select: cc.Node = null
    @property(cc.EditBox)
    box_name: cc.EditBox = null
    @property(cc.EditBox)
    box_iden: cc.EditBox = null
    @property(cc.Label)
    label_toast: cc.Label = null

    public static async  open() {
        if (cc.sys.localStorage.getItem('guide') == 1) return false;
        await nSdk.waitInit();
        if (nSdk.getConfig('realName') != 1) return false;
        if (cc.sys.localStorage.getItem('realName') == 1) return false;
        uiFunc.open(uiRealName);
        return true;
    }

    private toast(str: string) {
        this.label_toast.string = str;
        const actNode = this.label_toast.node.parent;
        actNode.stopAllActions();
        actNode.opacity = 255;
        cc.tween(actNode)
            .delay(1)
            .to(.5, { opacity: 0 })
            .start();
    }

    private onBtnCN(e: cc.Event.EventTouch) {
        this.node_region.active = false;
        this.node_verify.active = true;
        this.node_select.y = e.currentTarget.y;
    }
    private onBtnOther(e: cc.Event.EventTouch) {
        this.quit();
        cc.sys.localStorage.setItem('realName', 1);
        this.node_select.y = e.currentTarget.y;
    }

    private canTouch = true
    private async onBtnCommit() {
        if (!this.canTouch) {
            this.toast('正在验证，请稍候');
            return;
        }
        this.canTouch = false;
        const isSucc = await this.checkId();
        if (isSucc) {
            cc.sys.localStorage.setItem('realName', 1);
            this.quit();
        } else {
            this.canTouch = true;
        }
    }
    private async checkId() {
        const str = this.box_iden.string;
        if (str.length != 18 || getDateFromId(str).getDate() != Number(str.substring(12, 14))) {
            this.toast('身份证号码格式不正确!');
            return false;
        }
        const uid = NativeCall.getIDFA() || '1', time = Date.now() + '';
        const param = {
            uid,
            idcard: this.box_iden.string,
            name: this.box_name.string,
            time,
            sign: Md5Helper.do(uid + time + 'cnIgMBmu4ezRwbX9'),
            appid: '100066',
            package: 'com.naga.pizza',
        }
        return new Promise(resl => {
            const url = encodeURI('https://au.3yoqu.com/Home/GameAuth/check' + getParamStr(param));
            Http.request(url, text => {
                this.canTouch = true;
                try {
                    const ob = JSON.parse(text);
                    if (ob.errcode == 0) {
                        resl(true);
                    } else {
                        resl(false);
                        this.toast(ob.errmsg);
                    }
                } catch (err) {
                    console.log('response text:' + text + ',err:', err);
                }
            }, () => this.canTouch = true)
        });
    }
}