import { Ad } from "../3rd/Ad";
import { ad_byte } from "../3rd/ad_byte";
import { Analysis } from "../3rd/Analysis";
import { BusinessManager } from "../3rd/BusinessManager";
import { ByteMiniRecorder } from "../3rd/ByteMiniRecorder";
import { getDadian } from "../3rd/dadian";
import { Platform } from "../3rd/Platform";
import uiFunc from "../common/uiFunc";
import uiPanel from "../common/uiPanel";
import { CashDesk } from "../game/core/CashDesk";
import { PizzaLogic } from "../gameLogic/logics/PizzaLogic";
import { DtoSale, SaleLogic } from "../gameLogic/logics/SaleLogic";
import { DtoSliver, SliverLogic } from "../gameLogic/logics/SliverLogic";
import { InsertMgr } from "../managers/InsertMgr";
import { Util } from "../utils/Util";
import SumItem from "./items/sumItem";
import { uiDecoration } from "./uiDecoration";
import { uiPochan } from "./uiPochan";
import { uiRateUs } from "./uiRateUs";
import uiShop from "./uiShop";
import uiTopMain from "./uiTopMain";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiSummary extends uiPanel {

    @property(cc.Prefab)
    sumItemPre: cc.Prefab = null;

    @property(SumItem)
    sumSale: SumItem = null;
    @property(SumItem)
    sumTip: SumItem = null;
    @property(SumItem)
    sumRent: SumItem = null;
    @property(SumItem)
    sumRefund: SumItem = null;
    @property(SumItem)
    sumSliver: SumItem = null;
    @property(SumItem)
    sumProfit: SumItem = null;
    @property(cc.Label)
    label_date: cc.Label = null

    @property(cc.Node)
    node_share: cc.Node = null

    @property(cc.Node)
    sliverInfoContent: cc.Node = null;

    @property(cc.Node)
    sumContainer: cc.Node = null;

    @property(cc.Node)
    node_double: cc.Node = null
    @property(cc.Node)
    node_20: cc.Node = null

    private _isShowSliverCostInfo: boolean = false;

    setData(data: DtoSale): void {
        let ts = this;
        ts.label_date.string = uiTopMain.ins.getYesterday();
        ts.sumSale.setGold(data.sale);
        ts.sumTip.setGold(data.tip);
        ts.sumRent.setGold(data.rent);
        ts.sumRefund.setGold(data.refund);
        ts.sumSliver.setGold(data.sliver);
        ts.sumProfit.setGold(data.profit);

        let sliverInfo = data.sliverInfo;
        ts.sliverInfoContent.destroyAllChildren();
        for (const sliverId in sliverInfo) {
            let gold: number = sliverInfo[sliverId];
            let sumItemNode: cc.Node = cc.instantiate(ts.sumItemPre);
            ts.sliverInfoContent.addChild(sumItemNode);
            let sumItem: SumItem = sumItemNode.getComponent(SumItem);
            let sliverName: string = SliverLogic.getSliverNameById(sliverId);
            sumItem.setData({ name: sliverName, gold: gold });
        }

        const flag = data.profit > 0;
        ts.node_double.active = flag;
        ts.node_20.active = !flag;
    }

    onBtnSwitch(): void {
        let ts = this;
        ts._isShowSliverCostInfo = !ts._isShowSliverCostInfo;
        let tw = cc.tween(ts.sumContainer);
        let posY: number = ts._isShowSliverCostInfo ? 250 : 0;
        tw.to(0.5, { y: posY });
        tw.start();
    }

    private canTouch = true
    onBtnNext(): void {
        if (!this.canTouch) return;
        this.canTouch = false;
        this.quit();
    }

    onBtnExtraTip() {
        if (!this.canTouch) return;
        this.canTouch = false;
        BusinessManager.do(() => {
            const gold = this.node_double.active ? SaleLogic.SaleData.profit : 20;
            uiTopMain.ins.addGold(gold);
            this.quit();
        }, () => { this.canTouch = true }, 'fb');
    }

    onBtnShare() {
        ad_byte.videoShare({
            title: '可口的煎饼',
            videoTitle: '可口的煎饼',
            desc: '可口的煎饼',
            topics: ['抖音小游戏', '可口的煎饼'],
            hashtag_list: ['抖音小游戏', '可口的煎饼'],
            videoPath: ByteMiniRecorder.videoPath,
        });
        this.node_share.active = false;
    }

    protected onEnable(): void {
        this.canTouch = true;
        this.node_share.active = Platform.isByte;
        ByteMiniRecorder.stop();
        if (Platform.isByte) {
            Ad.playInsert();
        }
        Analysis.event(getDadian("end_" + PizzaLogic.getDay() + "day" as any));
    }
    private alreadyShop = false
    private alreadyDeco = false
    protected onDisable(): void {
        let ts = this;
        ts.sumContainer.cleanup();
        if (Platform.ios || cc.sys.isBrowser) {
            InsertMgr.instance.randomPlay(1);
            // Ad.playInsert();
        }

        /*20220729调整：
        1-游戏中第一天结算且不破产后仅弹食材购买
        2-游戏中第二天结算且不破产后仅弹装饰弹窗
        3-游戏中第三天结算后仅弹评分弹窗
        4-后续天数，结算且不破产后，（食材购买、装饰）在单次冷启动中分别最多各弹1次*/
        if (PizzaLogic.getTempGold() <= 0) {
            uiFunc.open(uiPochan);
        } else {
            CashDesk.ins.newDay();
            const day = PizzaLogic.getDay();
            if (day == 1) {
                uiFunc.open(uiShop);
            } else if (day == 2) {
                uiFunc.open(uiDecoration);
            } else if (day == 3) {
                uiRateUs.open();
            } else {
                if (!this.alreadyDeco) {
                    uiFunc.open(uiDecoration);
                } else if (!this.alreadyShop) {
                    uiFunc.open(uiShop);
                }
            }
        }
    }
}