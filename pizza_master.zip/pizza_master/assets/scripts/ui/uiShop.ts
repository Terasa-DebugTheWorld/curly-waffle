import uiPanel from "../common/uiPanel";
import { LockCailiao } from "../game/comp/LockCailiao";
import { CailiaoMgr } from "../game/managers/CailiaoMgr";
import { DtoSliver, SliverLogic } from "../gameLogic/logics/SliverLogic";
import ShopItem from "./items/shopItem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiShop extends uiPanel {

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    btnClose: cc.Node = null;

    @property(cc.Prefab)
    shopItemPre: cc.Prefab = null;

    public static unlockCnt = 0
    protected onEnable(): void {
        uiShop.unlockCnt = 0;
        let ts = this;
        ts.btnClose.active = false;
        ts.content.destroyAllChildren();
        for (const id in SliverLogic.Sliver) {
            const sliver: DtoSliver = SliverLogic.Sliver[id];
            let n: cc.Node = cc.instantiate(ts.shopItemPre);
            let shopItem: ShopItem = n.getComponent(ShopItem);
            ts.content.addChild(n);
            shopItem.setData(sliver);
        }
        ts.content.children.sort((a, b) => {
            const calc = (node: cc.Node): number => {
                const item = node.getComponent(ShopItem);
                const q = 1000;
                return (+SliverLogic.isSliverUnlocked(item._data.id)) * q * q
                    + (item._data.unlockDiamond || 0) * q
                    + (item._data.unlockGold || 0);
            }
            const na = calc(a),
                nb = calc(b);
            return na - nb;
        });
        ts.scrollView.scrollToLeft();
    }

    protected onDisable(): void {
        let ts = this;
        const end = SliverLogic.getUnlockedSlivers().length - 2;
        for (let i = 0; i < uiShop.unlockCnt; i++) {
            CailiaoMgr.ins.cls[end - i].playUnlock();
        }
    }

    onShow(): void {
        let ts = this;
        ts.btnClose.active = true;
    }

    onBtnClose(): void {
        let ts = this;
        ts.btnClose.active = false;
        ts.quit();
    }
}
