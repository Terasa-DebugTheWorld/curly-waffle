import uiPanel from "../common/uiPanel";
import { ClientEvent } from "../common/ClientEvent";
import uiFunc from "../common/uiFunc";

const { ccclass, property } = cc._decorator;
@ccclass
export default class uiMaskLayout extends uiPanel {
    // LIFE-CYCLE CALLBACKS:
    onLoad() {
        super.onLoad();
        ClientEvent.on(ClientEvent.eventType.openUI, this.uiOperateCallBack, this);
        ClientEvent.on(ClientEvent.eventType.closeUI, this.uiOperateCallBack, this);
    }

    start() {
        this.isUseMask = false;
        if (uiFunc.uiList.length > 0) {
            this.uiOperateCallBack();
        } else {
            this.node.active = false;
        }
    }

    uiOperateCallBack() {
        if (uiFunc.group) this.node.group = uiFunc.group;
        // 最后一个需要使用mask的panel
        var lastMaskIndex = -1;
        for (var i = uiFunc.uiList.length - 1; i >= 0; i--) {
            var ui = uiFunc.uiList[i];
            var panel = ui.getComponent("uiPanel");
            if (panel && panel.isUseMask) {
                lastMaskIndex = i;
                break;
            }
        }
        if (lastMaskIndex >= 0) {
            this.node.active = true;
            this.node.setSiblingIndex(Number.MAX_SAFE_INTEGER);
            for (var j = lastMaskIndex; j < uiFunc.uiList.length; j++) {
                var targetUI = uiFunc.uiList[j];
                if (targetUI) {
                    targetUI.setSiblingIndex(Number.MAX_SAFE_INTEGER);
                } else {
                    console.log("current show ui is null!");
                }
            }
        } else {
            this.node.active = false;
            return;
        }
    }

    refresh() {
        // 最后一个需要使用mask的panel
        var lastMaskIndex = -1;
        for (var i = uiFunc.uiList.length - 1; i >= 0; i--) {
            var ui = uiFunc.uiList[i];
            var panel = ui.getComponent("uiPanel");
            if (panel.isUseMask) {
                lastMaskIndex = i;
                break;
            }
        }
        if (lastMaskIndex >= 0) {
            this.node.active = true;
            for (var j = lastMaskIndex; j < uiFunc.uiList.length; j++) {
                var targetUI = uiFunc.uiList[j];
                if (targetUI) {
                    this.node.setSiblingIndex(Number.MAX_SAFE_INTEGER);
                    targetUI.setSiblingIndex(Number.MAX_SAFE_INTEGER);
                } else {
                    console.log("current show ui is null!");
                }
            }
        } else {
            this.node.active = false;
            return;
        }
    }

    onDestroy() {
        ClientEvent.off(ClientEvent.eventType.openUI, this.uiOperateCallBack, this);
        ClientEvent.off(ClientEvent.eventType.closeUI, this.uiOperateCallBack, this);
    }
}