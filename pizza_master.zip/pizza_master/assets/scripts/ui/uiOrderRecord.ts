import { System } from "../common/System";
import uiPanel from "../common/uiPanel";
import GameContext from "../game/GameContext";
import { DtoOrderRecord } from "../gameLogic/logics/OrderLogic";
import OrderRecordItem from "./items/orderRecordItem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiOrderRecord extends uiPanel {

    @property(cc.Node)
    mask:cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Prefab)
    orderRecordItemPre: cc.Prefab = null;

    protected onEnable(): void {
        let ts = this;
        ts.mask.setContentSize(System.getVisibleSize());
        ts.mask.on(cc.Node.EventType.TOUCH_END,ts.clickClose,ts);
        ts.content.destroyAllChildren();
        let orderRecords: DtoOrderRecord[] = GameContext.instance.OrderRecords;
        for (let i = 0; i < orderRecords.length; i++) {
            const orderRecord: DtoOrderRecord = orderRecords[i];
            const n: cc.Node = cc.instantiate(ts.orderRecordItemPre);
            ts.content.addChild(n);
            const orderRecordItem: OrderRecordItem = n.getComponent(OrderRecordItem);
            orderRecordItem.setData(orderRecord);
        }
    }

    protected onDisable(): void {
        let ts = this;
        ts.mask.off(cc.Node.EventType.TOUCH_END,ts.clickClose,ts);
    }

    clickClose(){
        this.quit();
    }

}
