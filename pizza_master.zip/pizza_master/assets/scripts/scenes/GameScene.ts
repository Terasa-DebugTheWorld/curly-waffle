import { uiUpdateTips } from './../ui/uiUpdateTips';
import { InsertMgr } from './../managers/InsertMgr';
import { Ad } from "../3rd/Ad";
import { ad_wx } from "../3rd/ad-wx";
import { Analysis } from "../3rd/Analysis";
import { getDadian } from "../3rd/dadian";
import { Platform } from "../3rd/Platform";
import { WxSubpackageLoader } from "../3rd/WxSubpackageLoader";
import { AudioHelper } from "../common/AudioHelper";
import { nSdk } from "../sdks/wx/nSdk";
import { uiAgreement } from "../ui/uiAgreement";
import { uiRealName } from '../ui/uiRealName';

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameScene extends cc.Component {
    async onLoad() {
        cc.Canvas.instance.node.on(cc.Node.EventType.TOUCH_START, this.onClickScreen, this, true);
        Analysis.eventOnce(getDadian('first_mian'))
        cc.macro.ENABLE_MULTI_TOUCH = false;
        uiAgreement.open();
        uiRealName.open();
        uiUpdateTips.open();
    }

    start() {
        this.scheduleOnce(() => {
            Ad.iosFirstPreload();
        }, 2)
        WxSubpackageLoader.loadSubpackage("audios", null, () => {
            AudioHelper.loadRes(null, () => {
                AudioHelper.playBgm("bgm");
            })
        })
        WxSubpackageLoader.loadSubpackage('more', null, null);
        if (Platform.isWx) {
            Ad.playBanner();
            ad_wx.insideRefreshBanner(100);
            wx.showShareMenu({ withShareTicket: false });
            wx.onShareAppMessage(function () {
                // 用户点击了“转发”按钮
                // const title = '指尖解压',
                //     imageUrl = 'https://cdn-res.nagagame.net/gameid/sharepic/jieya.jpg';
                // return { title, imageUrl };
                return nSdk.getShareInfo();
            });
        }
        if (Platform.ios) {
            Ad.playBanner();
        }
    }

    protected onDisable(): void {
        if (Platform.isWx) {
            // Ad.closeBanner();
        }
    }

    onClickScreen(e: cc.Event.EventTouch) {
        if (e.getCurrentTarget().getComponent(cc.Button)) {
            AudioHelper.playEffect('click');
        }
    }
}