import { Ad } from "../3rd/Ad";
import { Analysis } from "../3rd/Analysis";
import { BusinessManager } from "../3rd/BusinessManager";
import { getDadian } from "../3rd/dadian";
import { Platform } from "../3rd/Platform";
import XunguangSDK from "../3rd/XunguangSDK";
import { AudioHelper } from "../common/AudioHelper";
import DataFunc from "../common/DataFunc";
import uiFunc from "../common/uiFunc";
import { LogicBase } from "../gameLogic/LogicBase";
import { Glb } from "../Glb";
import { nSdk } from "../sdks/wx/nSdk";
import WxHack from "../sdks/wx/WxHack";
import UserData from "../userdata/UserData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class LoadingScene extends cc.Component {
    @property(cc.Label)
    label: cc.Label = null;

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;

    _mainScene = 'game';
    onLoad() {
        UserData.init();
        BusinessManager.init();
        // if (!UserData.isNew) Ad.playSplash();
        let allLoad = [DataFunc.loadConfigAsync(), /* this.loadGameScene(), */ uiFunc.init()];
        Promise.all(allLoad).then(() => {
            LogicBase.INIT_ALL();
            // Analysis.eventOnce(getDadian("scjzwc"));
            cc.director.loadScene(this._mainScene);
        });
        if (UserData.isNew) {
            // Analysis.eventOnce(getDadian("scdk"));
        }
        nSdk.init(Glb.gameId);
        // WxHack.init();
        // XunguangSDK.init();
        if (Platform.ios) {
            //开屏广告
        }
    }

    start() {
        // Analysis.eventOnce(getDadian("scjz"));
    }

    loadGameScene() {
        return new Promise((resolve, reject) => {
            cc.director.preloadScene(this._mainScene, (cnt, total) => {

            }, () => {
                cc.log('加载完主场景')
                resolve(null);
            })
        })
    }

    fakeProgress = 0;
    fakeLoadTime = 5;
    update(dt) {
        if (this.fakeProgress > 95) {
            this.fakeLoadTime = 10;
        }
        this.fakeProgress += dt / this.fakeLoadTime;
        this.label && (this.label.string = (this.fakeProgress * 100).toFixed(2) + "%");
        this.progressBar.progress = this.fakeProgress;
    }
}