import { Analysis } from "../../3rd/Analysis";
import { BusinessManager } from "../../3rd/BusinessManager";
import { getDadian } from "../../3rd/dadian";
import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { AudioHelper } from "../../common/AudioHelper";
import DataFunc from "../../common/DataFunc";
import uiFunc from "../../common/uiFunc";
import { SpinePlayer } from "../../components/SpinePlayer";
import { DtoOrder } from "../../gameLogic/logics/OrderLogic";
import { PizzaLogic } from "../../gameLogic/logics/PizzaLogic";
import { RecipeLogic } from "../../gameLogic/logics/RecipeLogic";
import { SaleLogic } from "../../gameLogic/logics/SaleLogic";
import { OrderRecordType } from "../../static/GameEnum";
import uiSummary from "../../ui/uiSummary";
import uiTopMain from "../../ui/uiTopMain";
import { Util } from "../../utils/Util";
import GameContext from "../GameContext";
import { CashDesk } from "./CashDesk";
import Dialog from "./Dialog";
import { PanCake } from "./PanCake";
type SpecialConfig = {
    id: number
    dialog0: string
    reply0_1: string
    reply0_2: string
    dialog1_1: string
    dialog1_2: string
    gold1: number
    diamond1: number
    gold2: number
    diamond2: number
    dialog2_1: string
    dialog2_2: string
    dialog3_1: string
    dialog3_2: string
    reply1_1: string
    reply1_2: string
    reply2_1: string
    reply2_2: string
}

const { ccclass, property } = cc._decorator;

@ccclass
export default class Guest extends cc.Component {

    @property(sp.Skeleton)
    spine: sp.Skeleton = null;
    @property(Dialog)
    dialog: Dialog = null;
    @property(cc.Node)
    node_video: cc.Node[] = []
    @property(cc.Node)
    node_new: cc.Node = null
    @property(cc.Label)
    label_btn: cc.Label[] = []

    private _order: DtoOrder | SpecialConfig = null;

    /**对话阶段 */
    private _phase: number = 1;
    public get Phase(): number {
        return this._phase;
    }
    public set Phase(v: number) {
        let ts = this;
        ts._phase = v;
        if (ts._phase >= 3) {
            ts._phase = 3;
        }
    }

    protected onLoad(): void {
        this.dialog.sp_talk.on(cc.Node.EventType.SIZE_CHANGED, this.moveNew, this);
    }
    protected onEnable(): void {
        let ts = this;
        // ts.node.active = false;
        ts.dialog.updateBtnState(false, false);
    }
    private moveNew() {
        if (!this.node_new.active) return;
        const node_dialog = this.dialog.sp_talk;
        const bx = node_dialog.x - node_dialog.width * node_dialog.anchorX,
            by = node_dialog.y + node_dialog.height * (1 - node_dialog.anchorY);
        this.node_new.x = bx + 20;
        this.node_new.y = by - 10;
    }

    /**出现 */
    private isSpecial = false
    async showUp(order: { data: DtoOrder | SpecialConfig, isLock?: boolean }, id?: string, isSpecial = false): Promise<void> {
        let ts = this;

        this.isSpecial = isSpecial;
        GameContext.instance.clearOrderRecord();
        ts._order = order.data;
        ts.node.active = true;
        ts.dialog.updateBtnState(false, false);
        this.node_new.active = false;
        ts.node_video[1].active = false;
        if (id) {
            await this.setSpine(id);
        } else {
            await ts.randSpine();
        }
        //客人现身
        AudioHelper.playEffect('npccome');
        await SpinePlayer.play(ts.spine, 0, 'chuxian', false);
        if (order.isLock) this.node_new.active = true;
        ts.Phase = 1;
        // let orderTalk = order.data[`talk${ts.Phase++}`];
        //客人说话
        ts.spine.setAnimation(0, 'shuohua', true);
        let orderTalk = '';
        if (isSpecial) {
            //@ts-ignore
            orderTalk = order.data.dialog0;
            this.label_btn.forEach((l, i) => l.string = order.data['reply0_' + (i + 1)]);
            Analysis.event(getDadian("specialnpc"));
        } else {
            orderTalk = order.data[`talk${ts.Phase++}`];
            ts.node_video[0].active = false;
            ts.moveNew();
            GameContext.instance.setOrderRecord({ target: OrderRecordType.GUEST, content: orderTalk })
            const strs = ['好的', '什么？']
            ts.label_btn.forEach((l, i) => l.string = strs[i]);
        }
        Analysis.eventOnce(getDadian("first_talk"));
        await ts.dialog.setText(orderTalk);
        SpinePlayer.play(ts.spine, 0, 'daiji', true);
        ts.dialog.updateBtnState(true, true);
        this.canTouch = true;
    }

    async getOut() {
        const ts = this;
        ts.dialog.hideDialog();
        ts.dialog.updateBtnState(false, false);
        await SpinePlayer.play(ts.spine, 0, 'likai', false);
        ts.node.active = false;
    }

    /**
     * 获得披萨
     * @param favorLevel 好感度等级
     */
    async getPizza(favorLevel: number): Promise<void> {
        AudioHelper.playEffect('npcget');
        AudioHelper.playEffect('moneyget');
        let tips = this._order[`finish${favorLevel}Tip`];
        // if (favorLevel == 1) {
        //     let price = RecipeLogic.getRecipeById(this._order.bookId1).price;
        //     if (this._order.bookId2) price = price / 2 + RecipeLogic.getRecipeById(this._order.bookId2).price / 2;
        //     tips = price / 2;
        // }
        if (tips) {
            uiTopMain.ins.addGold(tips, true, false);
            CashDesk.ins.cashIn(tips);
            SaleLogic.addTip(tips);
        }
        const refund = PanCake.ins.refund;
        if (refund > 0) {
            SaleLogic.addRefund(-refund);
            uiTopMain.ins.useGold(refund);
        }
        let ts = this;
        ts.dialog.updateBtnState(false, false);
        //客人说话
        SpinePlayer.play(ts.spine, 0, 'shuohua', true);
        await ts.dialog.setText(ts._order[`finish${favorLevel}`]);
        await Util.delay(1);
        await this.getOut();
    }

    async setSpine(id: string) {
        this.spine.skeletonData = await WxSubpackageLoader.loadSpine('more', `roles/r${id}`);
    }

    async randSpine() {
        let ts = this;
        ts.spine.skeletonData = null;
        let roleId: number = Util.getRandomClose(2, 30);
        ts.spine.skeletonData = await WxSubpackageLoader.loadSpine('more', `roles/r${roleId}`);
    }

    private replaceText(text: string): string {
        // let str = text.replace('$gold', '<img src="hexin_chaopiao" />' + this._order.gold);
        // return str.replace('$diamond', '<img src="hexin_zuanshi" />' + this._order.diamond);
        let str = text.replace('$gold', this._order['gold' + this.lastChoice] + '钱币');
        return str.replace('$diamond', this._order['diamond' + this.lastChoice] + '钻石');
    }

    private canTouch = true
    private lastChoice = 1
    async onBtnNo() {
        if (!this.canTouch) return;
        this.canTouch = false;
        let ts = this;
        if (this.isSpecial) {
            ts.node_video[0].active = ts.Phase == 1;
            let text = '';
            if (ts.Phase == 1) {
                text = ts._order['dialog1_2'];
            } else if (ts.Phase == 2) {
                text = ts._order[`dialog${1 + ts.lastChoice}_2`];
            }
            text = this.replaceText(text);
            ts.dialog.updateBtnState(false, false);
            this.label_btn.forEach((l, i) => l.string = ts._order[`reply${ts.lastChoice}_${(i + 1)}`]);
            await ts.dialog.setText(text);
            ts.dialog.updateBtnState(true, ts.Phase < 2);
            ts.Phase++;
            ts.canTouch = true;
        } else {
            const fn = async () => {
                GameContext.instance.setOrderRecord({ target: OrderRecordType.YOU, content: '什么?' })
                ts.dialog.updateBtnState(false, false);
                let orderTalk = ts._order[`talk${ts.Phase}`];
                GameContext.instance.setOrderRecord({ target: OrderRecordType.GUEST, content: orderTalk })
                await ts.dialog.setText(orderTalk);
                ts.dialog.updateBtnState(true, ts.Phase < 3);
                ts.Phase++;
                ts.node_video[1].active = ts.Phase > 1;
                uiTopMain.ins.subFavor(10);
                ts.canTouch = true;
            }
            if (ts.Phase >= 3) {
                BusinessManager.do(fn, () => ts.canTouch = true, 'sm');
            } else {
                fn();
            }
        }
    }

    async onBtnYes() {
        if (!this.canTouch) return;
        this.canTouch = false;
        const ts = this;
        if (this.isSpecial) {
            ts.node_video[0].active = ts.Phase == 1;
            if (ts.Phase > 2) {
                await this.getOut();
                uiFunc.open(uiSummary, SaleLogic.SaleData);
                return;
            }
            const fn = async () => {
                let text = '';
                if (ts.Phase == 1) {
                    text = ts._order['dialog1_1'];
                } else if (ts.Phase == 2) {
                    text = ts._order[`dialog${1 + ts.lastChoice}_1`];
                }
                text = this.replaceText(text);
                ts.dialog.updateBtnState(false, false);
                this.label_btn.forEach((l, i) => l.string = ts._order[`reply${ts.lastChoice}_${(i + 1)}`]);
                await ts.dialog.setText(text);
                ts.dialog.updateBtnState(true, this.Phase < 2);
                ts.Phase++;
                ts.canTouch = true;
            }
            if (ts.Phase > 1) {
                BusinessManager.do(() => {
                    const gold = ts._order['gold' + ts.lastChoice],
                        diamond = ts._order['diamond' + ts.lastChoice];
                    if (gold) uiTopMain.ins.addGold(gold);
                    if (diamond) uiTopMain.ins.addDiamond(diamond);
                    fn();
                }, () => this.canTouch = true, 'specialnpc');
            } else {
                fn();
            }
        } else {
            GameContext.instance.setOrderRecord({ target: OrderRecordType.YOU, content: '好的' })
            //@ts-ignore
            let price = RecipeLogic.getRecipeById(this._order.bookId1).price;
            //@ts-ignore
            if (this._order.bookId2) price = price / 2 + RecipeLogic.getRecipeById(this._order.bookId2).price / 2;
            uiTopMain.ins.addGold(price, true, false);
            SaleLogic.addSale(price);
            AudioHelper.playEffect('moneyget');
            this.node_new.active = false;
            CashDesk.ins.cooking = true;
            await CashDesk.ins.cashIn(price);
            await CashDesk.ins.transToCook();
            this.canTouch = true;
        }
    }

    unlockCurCake() {
        //@ts-ignore
        RecipeLogic.unlockRecipe(this.parseBookid(this._order.bookId1), true);
        //@ts-ignore
        if (this._order.bookId2) RecipeLogic.unlockRecipe(this.parseBookid(this._order.bookId2), true);
    }
    private parseBookid(id: number): number {
        return (Math.floor((id - 1) / 3) + 1) * 3;
    }

    //special
    public showSpecial() {
        const arr = Object.values(DataFunc.getConfig('specialGuest'));
        const sc = Util.getRandomValueInArray(arr) as SpecialConfig;
        this.showUp({ data: sc }, 'b1', true);
    }
}