import { Analysis } from "../../3rd/Analysis";
import { getDadian } from "../../3rd/dadian";
import { AudioHelper } from "../../common/AudioHelper";
import DrawingBoard from "../../common/DrawingBoard";
import NodePool from "../../common/NodePool";
import { SnapShot } from "../../common/SnapShot";
import { System } from "../../common/System";
import { DragAndDrop } from "../../components/DragAndDrop";
import { SpinePlayer } from "../../components/SpinePlayer";
import { PizzaLogic } from "../../gameLogic/logics/PizzaLogic";
import { RecipeLogic } from "../../gameLogic/logics/RecipeLogic";
import { SaleLogic } from "../../gameLogic/logics/SaleLogic";
import { SliverLogic } from "../../gameLogic/logics/SliverLogic";
import uiTopMain from "../../ui/uiTopMain";
import { PromiseUtil } from "../../utils/PromiseUtil";
import { Util } from "../../utils/Util";
import { cailiaoBtn } from "../comp/cailiaoBtn";
import { SlideJudger } from "../comp/SlideJudger";
import { GuideSteps } from "../managers/GuideSteps";
import { CashDesk } from "./CashDesk";

export enum CakeState {
    stop = 0,
    mianhu,
    moMianhu,
    putEgg,
    egg,
    flip,
    diy,
    fold,
    pack,
    finish,
}

const { ccclass, property } = cc._decorator;
const MIANHU_COLOR = cc.color().fromHEX('f8e7b9');
const MIANHU_OUT_WIDTH = 30;

// const CHAN_POS = cc.v3(273, -138);
@ccclass
export class PanCake extends cc.Component {
    @property(cc.Node)
    node_cake_front: cc.Node = null
    @property(cc.Sprite)
    spr_cake_back: cc.Sprite = null
    @property(cc.Sprite)
    spr_cake_up: cc.Sprite = null
    @property(cc.Sprite)
    spr_cake_dn: cc.Sprite = null

    @property(cc.Node)
    node_guo: cc.Node = null
    @property(cc.Sprite)
    spr: cc.Sprite = null
    @property(cc.Node)
    node_finger: cc.Node = null
    @property(cc.Node)
    node_mianhu: cc.Node = null
    @property(cc.Node)
    node_eggs: cc.Node = null

    @property(cc.Node)
    node_gan: cc.Node = null
    @property(cc.Node)
    node_chan: cc.Node = null

    @property(cc.Node)
    node_liquidMian: cc.Node = null
    @property(cc.Node)
    node_egg: cc.Node = null
    @property(cc.Sprite)
    spr_eggHu: cc.Sprite = null
    @property(cc.Node)
    node_tu_parent: cc.Node = null
    @property(cc.Node)
    node_items_parent: cc.Node = null
    @property(cc.Node)
    node_package: cc.Node = null
    @property(cc.Node)
    node_package_back: cc.Node = null
    @property(cc.Node)
    nodes_dot_line: cc.Node[] = []
    @property(cc.Node)
    node_scroll_btn: cc.Node = null
    @property(cc.Node)
    node_keli_guide: cc.Node = null
    @property(cc.Node)
    node_tiaozhuang_guide: cc.Node = null

    @property(sp.Skeleton)
    spine_spoon: sp.Skeleton = null
    @property(sp.Skeleton)
    spine_egg: sp.Skeleton = null
    @property(sp.Skeleton)
    spine_fanmian: sp.Skeleton = null

    //guide
    @property(cc.Node)
    nodes_guide: cc.Node[] = []
    @property(cc.Node)
    node_arrow: cc.Node = null
    @property(cc.Node)
    nodes_gold_ui: cc.Node[] = []
    @property(cc.Node)
    node_jiang: cc.Node = null
    @property(cc.Node)
    node_baocui: cc.Node = null
    @property(cc.Node)
    node_fold_btn: cc.Node = null
    @property(cc.Node)
    node_scroll: cc.Node = null

    //weak guide
    @property(cc.Node)
    node_finger_circle: cc.Node = null

    // LIFE-CYCLE CALLBACKS:
    public state = CakeState.stop
    public static ins: PanCake
    protected onLoad(): void {
        PanCake.ins = this;
        window.pc = this;
        this.drawer.init(this.node_cake_front.width, this.node_cake_front.height);

        this.node_guo.on(cc.Node.EventType.TOUCH_START, this.onTouchCakeStart, this);
        this.node_guo.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchCakeMove, this);
        this.node_guo.on(cc.Node.EventType.TOUCH_END, this.onTouchCakeEnd, this);
        this.node_guo.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCakeEnd, this);
        this.node_mianhu.on(cc.Node.EventType.TOUCH_END, this.onClickMianhu, this);
        this.node_eggs.on(cc.Node.EventType.TOUCH_END, this.onClickEgg, this);
        // this.node_chan.on(cc.Node.EventType.TOUCH_START, this.onTouchChanzi, this);
        // this.node_chan.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchChanziMove, this);
        this.spr.getComponent(DragAndDrop).on('drop', this.onDrop, this);
        // this.node_chan.on(cc.Node.EventType.TOUCH_END, this.onTouchChanziEnd, this);

        this.buffer = new ArrayBuffer(this.node_cake_front.width * this.node_cake_front.height);
        this.fillArray = new Uint8Array(this.buffer);
        this.node.active = false;
    }

    private isLeft = true
    private async onClickScroll() {
        if (!this.canTouch) return;
        this.canTouch = false;
        const vw = System.getVisibleWidth();
        const node = this.node.children[0];
        const w = node.width;
        const t = 0.5;
        if (this.isLeft) {
            this.node_scroll_btn.scaleX = -1;
            cc.tween(this.node_scroll_btn)
                .to(t, { x: 100 + this.node_scroll_btn.width / 2 - vw / 2 })
                .start();
            const tw = cc.tween(node)
                .to(t, { x: vw / 2 - w / 2 })
            await PromiseUtil.tween(tw);
        } else {
            this.node_scroll_btn.scaleX = 1;
            cc.tween(this.node_scroll_btn)
                .to(t, { x: vw / 2 - 100 - this.node_scroll_btn.width / 2 })
                .start();
            const tw = cc.tween(node)
                .to(t, { x: w / 2 - vw / 2 })
            await PromiseUtil.tween(tw);
        }
        this.canTouch = true;
        this.isLeft = !this.isLeft;
    }

    public reset() {
        const vw = System.getVisibleWidth();
        const node = this.node.children[0];
        const w = node.width;
        node.x = w / 2 - vw / 2;
        this.node_scroll_btn.x = vw / 2 - 100 - this.node_scroll_btn.width / 2;
        this.node_scroll_btn.scaleX = 1;
        this.liquidRecord = {};
        this.solidRecord = {};
        this.changeState(CakeState.mianhu);
        this.node_package.active = this.node_package_back.active = false;
    }
    private async changeState(state: CakeState) {
        this.state = state;
        const gs = GuideSteps.ins;
        switch (state) {
            case CakeState.mianhu:
                this.spr_cake_back.fillRange = 0;
                this.spr.fillStart = 0;
                this.node_cake_front.getComponent(cc.Sprite).fillRange = this.spr.fillRange = 1;
                this.node_cake_front.opacity = 0;
                this.node_liquidMian.opacity = 255;
                this.node_liquidMian.scale = 0;
                this.spr.node.position = cc.v3();
                this.spr.node.angle = 0;

                if (gs.isGuide) {
                    this.node_scroll.active = false;
                    this.scheduleOnce(() => {
                        gs.guide(this.node_mianhu, cc.v3(0, 50), [this.node_mianhu], '首先，平铺面儿糊');
                    });
                } else {
                    this.shine(this.node_mianhu.children[0]);
                }
                break;
            case CakeState.moMianhu:
                this.node_gan.active = true;
                this.node_gan.angle = 0;

                if (gs.isGuide) {
                    gs.guide(this.node_gan, cc.v3(), [this.node_guo, this.node_cake_front.parent, this.node_liquidMian, this.node_gan], '首先，平铺面儿糊',
                        null, null, true);
                } else {
                    this.node_finger_circle.active = true;
                }
                break;
            case CakeState.putEgg:
                this.node_gan.active = false;

                if (gs.isGuide) {
                    gs.guide(this.node_eggs, cc.v3(), [this.node_eggs], '在面糊上加个蛋儿');
                    Analysis.eventOnce(getDadian('first_dadan'));
                } else {
                    this.node_finger_circle.active = false;
                    this.shine(this.node_eggs.children[0]);
                }
                break;
            case CakeState.egg:
                this.node_gan.active = true;
                this.node_gan.angle = 0;

                if (gs.isGuide) {
                    gs.guide(this.node_gan, cc.v3(), [this.node_guo, this.node_cake_front.parent, this.node_egg.parent, this.node_gan], '在面糊上加个蛋儿',
                        null, null, true);
                } else {
                    this.node_finger_circle.active = true;
                }
                break;
            case CakeState.flip:
                this.node_gan.active = false;
                this.node_chan.active = true;
                this.node_chan.setSiblingIndex(7);
                this.spr_eggHu.fillType = cc.Sprite.FillType.HORIZONTAL;
                this.spr_eggHu.fillStart = 0;
                this.node_chan.x = this.node_cake_front.parent.x + this.node_cake_front.width / 2;
                this.node_chan.y = this.node_cake_front.parent.y;
                this.node_egg.active = false;
                this.node_egg.scale = 1;
                this.node_egg.opacity = 255;
                this.flipRange.fill(0);

                if (gs.isGuide) {
                    gs.guide(this.node_cake_front.parent, cc.v3(), [this.node_guo, this.node_chan, this.node_cake_front.parent, this.spr_eggHu.node, this.node_chan],
                        '铺完鸡蛋翻个面儿', null, null, true);
                    Analysis.eventOnce(getDadian('first_tandan'));
                }
                break;
            case CakeState.diy:
                this.spr_eggHu.fillRange = 0;
                this.node_cake_front.getComponent(cc.Sprite).fillRange = 1;
                this.spr_cake_back.fillRange = 0;
                // this.node_chan.position = CHAN_POS;
                // this.node_chan.active = true;
                this.node_chan.angle = 0;

                if (gs.isGuide) {
                    this.guideCailiao3();
                } else {
                    this.node_finger_circle.active = false;
                }
                break;
            case CakeState.fold:
                if (this.usingCl) {
                    this.usingCl.unuse();
                    this.usingCl = null;
                }
                PanCake.ins.node_tiaozhuang_guide.active = PanCake.ins.node_keli_guide.active = false;
                this.node_chan.setSiblingIndex(9);
                this.playFold();
                break;
            case CakeState.pack:
                SnapShot.shot(this.node_cake_front.parent, this.spr);
                this.spr_cake_dn.fillRange = this.spr_cake_up.fillRange = 0;
                this.spr.getComponent(DragAndDrop).enabled = this.node_package.active = this.node_package_back.active = true;

                if (gs.isGuide) {
                    this.guidePack();
                }
                break;
            case CakeState.finish:
                CashDesk.ins.setCake(this.spr.spriteFrame, this.calcLevel());
                await CashDesk.ins.transBack();
                this.spr.spriteFrame = null
                // this.changeState(CakeState.mianhu);
                this.node_scroll.active = true;
                this.node_package.active = this.node_package_back.active = false;
                uiTopMain.ins.pauseFavor();
                break;
        }
    }
    private nextState() {
        if (GuideSteps.ins.isGuide && this.state == CakeState.moMianhu && !this.node_arrow.active) {
            if (this.endMoMianhu) return;
            this.endMoMianhu = true;
            this.guideCailiao();
            return;
        }
        this.changeState(this.state + 1);
    }
    public isState(state: CakeState): boolean {
        return this.state == state;
    }
    public isNotState(state: CakeState): boolean {
        return this.state != state;
    }

    private rt = new cc.RenderTexture();
    private sf = new cc.SpriteFrame();
    private renderDraw() {
        const data = this.drawer.getData();
        this.rt.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, this.node_cake_front.width, this.node_cake_front.height);
        if (!this.sf.getTexture()) {
            this.sf.setTexture(this.rt);
            this.spr.spriteFrame = this.sf;
        }
    }

    private colorAdd(color1: cc.Color, color2: cc.Color): cc.Color {
        return cc.color(color1.r * color2.r / 255, color1.g * color2.g / 255, color1.b * color2.b / 255, color1.a * color2.a / 255);
    }

    private mianhuR = 0
    private get mhr() {
        return this.mianhuR;
    }
    private set mhr(v: number) {
        const x = this.node_cake_front.width / 2, y = this.node_cake_front.height / 2, r = v;
        for (let m = this.drawer.clampX(Math.round(x - r)); m <= this.drawer.clampX(Math.round(x + r)); m++) {
            const k = Math.sqrt(r * r - Math.pow(m - x, 2));
            for (let n = this.drawer.clampY(Math.round(y - k)); n <= this.drawer.clampY(Math.round(y + k)); n++) {
                const d = Math.sqrt(Math.pow(Math.abs(m - x), 2) + Math.pow(Math.abs(n - y), 2));
                if (v - d > MIANHU_OUT_WIDTH) {
                    this.drawer.drawPixel(m, n, MIANHU_COLOR);
                } else {
                    const dark = this.colorAdd(MIANHU_COLOR, MIANHU_COLOR);
                    const color = MIANHU_COLOR.lerp(dark, Math.abs((MIANHU_OUT_WIDTH / 2 - (MIANHU_OUT_WIDTH - v + d)) / MIANHU_OUT_WIDTH * 2));
                    this.drawer.drawPixel(m, n, color);
                }
                this.renderDraw();
            }
        }
    }
    private fireAudio = 0
    private async putMianhu() {
        this.spine_spoon.node.position = this.node_mianhu.position;
        this.spine_spoon.node.active = true;
        await SpinePlayer.play(this.spine_spoon, 0, 'daiji');
        const move = cc.tween(this.spine_spoon.node)
            .to(0.5, { position: this.node_cake_front.parent.position })
        await PromiseUtil.tween(move);
        SpinePlayer.play(this.spine_spoon, 0, 'dao');
        const tw = cc.tween(this.node_liquidMian)
            .set({ scale: 0 })
            .delay(0.3)
            .to(1.5, { scale: 1 }, { easing: 'sineOut' })
        await PromiseUtil.tween(tw);
        this.spine_spoon.node.active = false;
        this.fireAudio = AudioHelper.playEffect('fire', true);
    }
    private async playFanmian(isClockwise = false) {
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.hideGuide();
        }
        this.spine_fanmian.node.active = true;
        this.node_chan.active = false;
        this.spr_eggHu.node.opacity = this.node_cake_front.opacity = 0;
        this.scheduleOnce(() => AudioHelper.playEffect('flip'), 1);
        const anim = isClockwise ? 'daiji_f' : 'daiji';
        await SpinePlayer.play(this.spine_fanmian, 0, anim);
        this.spine_fanmian.node.active = false;
        this.node_cake_front.opacity = 255;
        this.nextState();
    }
    private async playFold() {
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.hideGuide();
        }
        AudioHelper.playEffect('flip');
        this.node_chan.angle = 90;
        this.node_chan.active = true;
        this.nodes_dot_line.forEach(Util.showNode);
        const x1 = this.node_cake_front.parent.x - this.node_cake_front.width / 2,
            x2 = this.node_cake_front.parent.x + this.node_cake_front.width / 2,
            y1 = this.node_cake_front.parent.y + this.node_cake_front.height / 6,
            y2 = this.node_cake_front.parent.y - this.node_cake_front.height / 6,
            t = 1;
        const tw1 = cc.tween(this.node_chan)
            .set({ angle: 90, active: true, y: y1 + this.node_chan.width / 2, x: x1 })
            .to(t, { x: x2 })
        await PromiseUtil.tween(tw1);

        const tw2 = cc.tween(this.node_chan)
            .set({ angle: 90, active: true, y: y2 + this.node_chan.width / 2, x: x1 })
            .to(t, { x: x2 })
        await PromiseUtil.tween(tw2);

        this.nodes_dot_line.forEach(Util.hideNode);
        this.node_chan.active = false;
        SnapShot.shot(this.node_cake_front.parent, this.spr);
        this.node_cake_front.getComponent(cc.Sprite).fillRange = 0;
        this.recycleAllItems();
        cc.tween(this.spr_cake_up.node)
            .set({ y: this.node_cake_front.height, })
            .to(t, { y: this.node_cake_front.height / 3 })
            .start()
        cc.tween(this.spr)
            .to(t, { fillStart: 1 / 3, fillRange: 2 / 3 })
            .start();
        const tw3 = cc.tween(this.spr_cake_up)
            .set({ fillRange: 0 })
            .to(t, { fillRange: 1 / 3 })
        await PromiseUtil.tween(tw3);

        cc.tween(this.spr_cake_dn.node)
            .set({ y: - this.node_cake_front.height, })
            .to(t, { y: - this.node_cake_front.height / 3 })
            .start()
        cc.tween(this.spr)
            .to(t, { fillRange: 1 / 3 })
            .start();
        const tw4 = cc.tween(this.spr_cake_dn)
            .set({ fillRange: 0 })
            .to(t, { fillRange: -1 / 3 })
        await PromiseUtil.tween(tw4);

        this.nextState();
    }
    private async playPack() {
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.hideGuide();
        }
        AudioHelper.stopEffect(this.fireAudio);
        const pos = Util.fromNodeToNode(this.spr.node, this.node_package);
        const tw = cc.tween(this.spr.node)
            .to(0.5, { angle: -90, x: pos.x, y: pos.y + this.node_package.height / 2 + this.node_cake_front.height / 2 + 100 })
            .to(0.5, { y: pos.y + this.node_cake_front.height / 2 + 10 })
        AudioHelper.playEffect('bagging');
        await PromiseUtil.tween(tw);
        CashDesk.ins.guest.unlockCurCake();
        // this.node_package.active = false;
    }

    private recycleAllItems() {
        const rcl = (node: cc.Node) => {
            for (let i = node.children.length; i > 0; i--) {
                this.pool.put(node.children[i - 1]);
            }
        }
        rcl(this.node_tu_parent);
        rcl(this.node_items_parent);
    }

    private drawer = new DrawingBoard(300, 300)
    public circle(x: number, y: number, r: number) {
        this.drawer.circleFill(x, y, r);
        this.renderDraw();
    }

    //interactive
    private async onClickMianhu() {
        if (this.isNotState(CakeState.mianhu)) return;
        if (!this.canTouch) return;
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.hideGuide();
        } else {
            const n = this.node_mianhu.children[0];
            n.stopAllActions();
            n.opacity = 0;
        }
        this.canTouch = false;
        Analysis.eventOnce(getDadian("first_miantuan"));
        await this.putMianhu();
        this.canTouch = true;
        this.nextState();
    }
    private flipRange: [number, number] = [0, 0]
    private buffer: ArrayBuffer
    private fillArray: Uint8Array
    private pool = new NodePool()
    private usingCl: cailiaoBtn
    private endMoMianhu = false
    private onTouchCakeStart(e: cc.Event.EventTouch) {
        switch (this.state) {
            case CakeState.moMianhu:
                this.onTouchCakeMove(e);
                break;
            case CakeState.egg:
                this.onTouchCakeMove(e);
                break;
            case CakeState.flip:

                break;
            case CakeState.diy:
                this.onTouchCakeMove(e);
                break;
        }
    }
    private onTouchCakeMove(e: cc.Event.EventTouch) {
        switch (this.state) {
            case CakeState.moMianhu:
                if (GuideSteps.ins.node_block.active && !this.endMoMianhu) {
                    GuideSteps.ins.hideGuide();
                }
                if (GuideSteps.ins.isGuide && this.endMoMianhu) return;
                var pos = this.node_guo.convertToNodeSpaceAR(e.getLocation());
                var angle = cc.v2(0, 1).signAngle(pos) * 180 / Math.PI;
                var diff = Math.abs(angle - this.node_gan.angle);
                if (diff >= 180) diff = 360 - diff;
                this.node_gan.angle = angle;
                var scale = Math.min(2, this.node_liquidMian.scale + diff / (360 / 1));
                this.node_liquidMian.scale = scale;
                if (scale >= 1.5) this.node_liquidMian.opacity = (2 - scale) * 255;
                this.node_cake_front.opacity = (scale - 1.5) * 2 * 255;
                if (scale >= 2) this.nextState();
                break;

            case CakeState.egg:
                if (GuideSteps.ins.node_block.active) {
                    GuideSteps.ins.hideGuide();
                }
                if (this.node_egg.scale >= 1.5) {
                    this.node_gan.active = false;
                    this.node_gan.angle = 0;
                    this.node_chan.active = true;
                    this.node_chan.x = this.node_cake_front.parent.x + this.node_cake_front.width / 2 + this.node_chan.width / 2;
                    this.node_chan.y = this.node_cake_front.parent.y;
                    this.node_chan.angle = 0;
                    return;
                }
                var pos = this.node_guo.convertToNodeSpaceAR(e.getLocation());
                var angle = cc.v2(0, 1).signAngle(pos) * 180 / Math.PI;
                var diff = Math.abs(angle - this.node_gan.angle);
                if (diff >= 180) diff = 360 - diff;
                this.node_gan.angle = angle;
                var scale = Math.min(1.5, this.node_egg.scale + diff / (360 / 0.5));
                this.node_egg.scale = scale;
                this.node_egg.opacity = (1.5 - scale) * 2 * 255;
                this.spr_eggHu.node.opacity = 255 - this.node_egg.opacity;
                break;

            case CakeState.flip:
                const judgeLine = 355;
                if (this.flipRange[1] - this.flipRange[0] >= judgeLine) return;
                var pos = this.node_cake_front.convertToNodeSpaceAR(e.getLocation());
                var radian = cc.v2(1).signAngle(pos);
                var angle = radian * 180 / Math.PI;
                var diff = angle - this.node_chan.angle;
                if (Math.abs(diff) >= 180) diff = (Math.abs(diff) - 360) * Math.sign(diff);
                this.node_chan.x = this.node_cake_front.parent.x + this.node_cake_front.width / 2 * Math.cos(radian);
                this.node_chan.y = this.node_cake_front.parent.y + this.node_cake_front.width / 2 * Math.sin(radian);
                const fit = function (a: number): number {
                    return a - Math.floor(a / 360) * 360;
                }
                const a = fit(angle);
                if (diff < 0) {
                    if (fit(this.flipRange[1] - this.flipRange[0]) < 180) {
                        if (fit(this.flipRange[0] - a) < 180) {
                            this.flipRange[0] = a > 0 ? a - 360 : a;
                        }
                    } else {
                        if (fit(a - this.flipRange[1]) < 180) {
                            this.flipRange[0] = a > 0 ? a - 360 : a;
                        }
                    }
                } else {
                    if (fit(this.flipRange[1] - this.flipRange[0]) < 180) {
                        if (fit(a - this.flipRange[1]) < 180) {
                            this.flipRange[1] = a;
                        }
                    } else {
                        if (fit(this.flipRange[0] - a) < 180) {
                            this.flipRange[1] = a;
                        }
                    }
                }
                this.node_chan.angle = angle;
                if (this.flipRange[1] - this.flipRange[0] >= judgeLine) {
                    this.playFanmian(diff <= 0);
                }
                break;

            case CakeState.diy:
                //涂抹液体材料
                if (!this.usingCl || !this.usingCl.isTu) return;
                var pos = this.node_cake_front.convertToNodeSpaceAR(e.getLocation());
                var rc = cc.v2(Math.round(pos.x + this.node_cake_front.width / 2), Math.round(pos.y + this.node_cake_front.height / 2));
                if (this.fillArray[rc.y * this.node_cake_front.width + rc.x]) return;
                const node = this.pool.get(this.usingCl.prefab);
                node.setParent(this.node_tu_parent);
                node.position = cc.v3(pos);
                const space = -10;
                const h = this.usingCl.prefab.height + space;
                const w = this.usingCl.prefab.width + space;
                for (let r = 0; r < h; r++) {
                    const y = Math.max(0, Math.min(this.node_cake_front.height - 1, Math.floor(rc.y - h / 2 + r)));
                    for (let c = 0; c < w; c++) {
                        const x = Math.max(0, Math.min(this.node_cake_front.width - 1, Math.floor(rc.x - w / 2 + c)));
                        this.fillArray[y * this.node_cake_front.width + x] = 1;
                    }
                }
                const cfg = SliverLogic.getSliverById(this.usingCl.id);
                PizzaLogic.useGoldCredit(cfg.cost);
                uiTopMain.ins.onUpdateGold();
                SaleLogic.addUseSliver(this.usingCl.id, cfg.cost);
                if (GuideSteps.ins.isGuide && this.guideCl == 4 && this.node_tu_parent.children.length > 30) {
                    this.guideCailiao5();
                }
                this.putLiquid(this.usingCl.id);
                AudioHelper.playEffect('put');
                break;
        }
    }
    private onTouchCakeEnd(e: cc.Event.EventTouch) {
        switch (this.state) {
            case CakeState.egg:
                if (this.node_egg.scale >= 1.5) {
                    this.nextState();
                }
                break;
            case CakeState.diy:
                //放置固体材料
                var pos = this.node_cake_front.convertToNodeSpaceAR(e.getLocation());
                if (!this.usingCl || this.usingCl.isTu) return;
                const isOut = pos.x * pos.x + pos.y * pos.y > Math.pow(this.node_cake_front.width / 2 - this.usingCl.prefab.height / 2, 2);
                if (isOut) return;
                const node = this.pool.get(this.usingCl.prefab);
                node.setParent(this.node_items_parent);
                node.position = cc.v3(pos);
                const cfg = SliverLogic.getSliverById(this.usingCl.id);
                PizzaLogic.useGoldCredit(cfg.cost);
                uiTopMain.ins.onUpdateGold();
                SaleLogic.addUseSliver(this.usingCl.id, cfg.cost);
                if (GuideSteps.ins.isGuide && this.guideCl == 5 && this.node_items_parent.children.length > 1) {
                    this.guideFold();
                }
                this.putSolid(this.usingCl.id, cc.v3(pos), SliverLogic.getSliverById(this.usingCl.id).put);
                AudioHelper.playEffect('put');
                break;
        }
    }

    //液体材料的摆放数量，id:数量
    public liquidRecord: Dictionary<number> = {}
    private putLiquid(id: number) {
        if (undefined == this.liquidRecord[id]) {
            this.liquidRecord[id] = 0;
        }
        this.liquidRecord[id]++;
    }

    private solid_poses1: cc.Vec3[]
    private solid_poses2: cc.Vec3[]
    //固体材料的摆放匹配度，id:各个指定位置的摆放匹配度
    public solidRecord: Dictionary<number[]> = {}
    private putSolid(id: number, pos: cc.Vec3, type = 2) {
        if (undefined == this.solidRecord[id]) {
            this.solidRecord[id] = new Array(type == 2 ? 6 : 2);
            this.solidRecord[id].fill(0);
        }
        if (!this.solid_poses1) {
            this.solid_poses1 = this.node_keli_guide.children.map(n => n.position);
            this.solid_poses2 = this.node_tiaozhuang_guide.children.map(n => n.position);
        }
        let vecs = this.solid_poses1;
        if (type == 3) {
            vecs = this.solid_poses2;
        }
        const perfectRadian = 10, //完美放置的半径范围
            outRadian = 30;       //完全超出的半径范围
        let dst = 999, idx = -1;
        vecs.forEach((v, i) => {
            const d = v.sub(pos).mag();
            if (d < dst) {
                dst = d;
                idx = i;
            }
        });
        let percent = 0;
        if (dst <= perfectRadian) {
            percent = 1;
        } else if (dst <= outRadian) {
            percent = dst / outRadian;
        }
        if (undefined == this.solidRecord[id][idx]) {
            this.solidRecord[id][idx] = percent;
        } else {
            if (this.solidRecord[id][idx] > percent) {
                this.solidRecord[id][idx] = percent;
            }
        }
    }

    //计算客人需求匹配度
    public refund = 0
    private calcLevel(): number {
        let bingoPercent = 1;
        const curOrder = CashDesk.ins.curOrder;
        let is2 = false, is3 = false, is4 = false;
        const needs = RecipeLogic.getRecipeById(curOrder.bookId1).sliverId; //必须的材料id
        for (let i in this.solidRecord) {
            //放了不能放的食材
            if (CashDesk.ins.curOrder.sliverId && curOrder.sliverId.indexOf(Number(i)) >= 0) {
                is2 = true;
                continue;
            }
            let p = 0;
            if (needs.includes(Number(i))) {
                this.solidRecord[i].forEach(n => {
                    if (n != undefined) {
                        //每个材料要放6个位置，取各个位置的放置匹配度的平均值
                        p += n / this.solidRecord[i].length;
                    }
                });

                //不同材料之间，取最低的放置匹配度
                if (p < bingoPercent) bingoPercent = p;
            }
        }
        for (let i in this.liquidRecord) {
            if (CashDesk.ins.curOrder.sliverId && CashDesk.ins.curOrder.sliverId.indexOf(Number(i)) >= 0) {
                is2 = true;
                continue;
            }

            //不同材料之间，取最低的放置匹配度
            if (needs.includes(Number(i)) && this.liquidRecord[i] < bingoPercent) {
                bingoPercent = this.liquidRecord[i];
            }
        }

        //漏放了食材
        this.refund = 0;
        needs.forEach(i => {
            const isLack = Object.keys(this.solidRecord).concat(Object.keys(this.liquidRecord)).indexOf(i + '') < 0;
            if (isLack) this.refund += SliverLogic.getSliverById(i).refund;
        });
        let price = RecipeLogic.getRecipeById(curOrder.bookId1).price;
        if (curOrder.bookId2) price = price / 2 + RecipeLogic.getRecipeById(curOrder.bookId2).price / 2;

        this.refund = Math.min(price, this.refund);
        if (this.refund > 0) {
            is3 = true;
        }

        //位置匹配度低
        if (bingoPercent < 0.5) {
            is4 = true;
        }

        //瞎抖要求的
        if (is2 && is3 && is4) {
            //都不匹配
            return 5;
        } else if (is2) {
            return 2;
        } else if (is3) {
            return 3;
        } else if (is4) {
            return 4;
        } else {
            //都匹配
            return 1;
        }
    }

    private canTouch = true
    private async onClickEgg() {
        if (!this.canTouch) return;
        if (this.isNotState(CakeState.putEgg)) return;
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.hideGuide();
        } else {
            const n = this.node_eggs.children[0];
            n.stopAllActions();
            n.opacity = 0;
        }
        this.canTouch = false;
        this.spine_egg.setAnimation(0, 'daiji', false);
        const move = cc.tween(this.spine_egg.node)
            .set({ active: true, position: this.node_eggs.position })
            .by(0.3, { y: 100 })
            .to(0.3, { position: cc.v3(this.node_guo.x - 160, this.node_guo.y + this.node_guo.height / 2) })
        await PromiseUtil.tween(move);

        const hit = cc.tween(this.spine_egg.node)
            .delay(0.3)
            .by(0.2, { y: -100, angle: 50 }, { easing: 'backOut' })
        await PromiseUtil.tween(hit);

        AudioHelper.playEffect('egg');
        this.spine_egg.setAnimation(0, 'daiji2', false);
        const pour = cc.tween(this.spine_egg.node)
            .delay(0.2)
            .to(0.2, { position: cc.v3(this.node_guo.x, this.node_guo.y + 10), angle: 0 })
        await PromiseUtil.tween(pour);

        cc.tween(this.node_egg)
            .set({ active: true, scale: 0 })
            .to(0.3, { scale: 1 })
            .start();
        await SpinePlayer.play(this.spine_egg, 0, 'dao');

        this.spine_egg.node.active = false;
        this.canTouch = true;
        this.nextState();
    }
    // private tsx = 0
    private onTouchChanzi(e: cc.Event.EventTouch) {
        // switch (this.state) {
        // case CakeState.pack:
        //     this.tsx = this.node_chan.parent.convertToNodeSpaceAR(cc.v3(e.getLocation())).y;
        //     break;
        // }
    }
    private onTouchChanziMove(e: cc.Event.EventTouch) {

    }
    private onTouchChanziEnd() {
        if (this.isNotState(CakeState.diy)) return;
        this.nextState();
    }
    public onClickCailiao(cl: cailiaoBtn) {
        if (cl.isUsing) {
            if (this.usingCl) {
                this.usingCl.unuse();
            }
            this.usingCl = cl;
            if (cl.isTu) this.fillArray.fill(0);
        } else {
            this.usingCl = null;
        }
    }
    private onDrop(data: { current: cc.Vec3, start: cc.Vec3, comp: DragAndDrop }) {
        if (this.node_package.getBoundingBoxToWorld().intersects(this.spr.node.getBoundingBoxToWorld())) {
            this.spr.getComponent(DragAndDrop).enabled = false;
            this.playPack().then(() => this.nextState());
            Analysis.eventOnce(getDadian("first_zhuangdai"));
        } else {
            this.spr.node.position = cc.v3();
        }
    }

    //guide
    private guideCailiao() {
        this.node_gan.active = false;
        GuideSteps.ins.guide(null, null, this.nodes_guide, '煎饼果子必备：\n鸡蛋、酱料和薄脆。');
        GuideSteps.ins.listenTouchAnywhere(this.guideCailiao2.bind(this));
        Analysis.eventOnce(getDadian("first_tanbing"));
    }
    private guideCailiao2() {
        CashDesk.ins.showUi();
        this.scheduleOnce(()=>{
            this.node_arrow.active = true;
            GuideSteps.ins.guide(null, null, this.nodes_guide.concat(this.nodes_gold_ui, this.node_arrow), '请注意控制原料成本，确保不要过度涂抹，均匀地涂一层就好。');
            GuideSteps.ins.listenTouchAnywhere(() => {
                GuideSteps.ins.hideGuide();
                this.nextState();
                this.node_arrow.active = false;
            });
        });
    }
    private guideCailiao3() {
        const gs = GuideSteps.ins;
        gs.guide(this.node_jiang, cc.v3(), [this.node_jiang], '先上个酱料');
        this.node_jiang.once(cc.Node.EventType.TOUCH_END, this.guideCailiao4, this);
        Analysis.eventOnce(getDadian("first_fanmian"));
    }
    private guideCl = 4
    private guideCailiao4() {
        this.guideCl = 4;
        GuideSteps.ins.guide(this.node_cake_front, cc.v3(), [this.node_guo, this.node_cake_front.parent], '先上个酱料',
            null, null, true);
    }
    private guideCailiao5() {
        this.guideCl = 5;
        GuideSteps.ins.guide(this.node_baocui, cc.v3(), [this.node_baocui], '再来个灵魂薄脆儿');
        this.node_baocui.once(cc.Node.EventType.TOUCH_END, this.guideCailiao6, this);
        Analysis.eventOnce(getDadian('first_tujiang'));
    }
    private guideCailiao6() {
        GuideSteps.ins.guide(this.node_cake_front, cc.v3(), [this.node_guo, this.node_cake_front.parent], '再来个灵魂薄脆儿');
    }
    private guideFold() {
        GuideSteps.ins.guide(this.node_fold_btn, cc.v3(), [this.node_fold_btn], '点击拿起铲子把煎饼包起来');
        Analysis.eventOnce(getDadian("first_bocui"));
    }
    private guidePack() {
        GuideSteps.ins.guide(this.spr.node, cc.v3(), [this.spr.node, this.node_package], '', [this.spr.node, this.node_package]);
        Analysis.eventOnce(getDadian("first_zuzhuang"));
    }

    //weak guide
    private shine(n: cc.Node) {
        cc.tween(n)
            .to(1, { opacity: 200 })
            .to(1, { opacity: 0 })
            .union()
            .repeatForever()
            .start();
    }
}