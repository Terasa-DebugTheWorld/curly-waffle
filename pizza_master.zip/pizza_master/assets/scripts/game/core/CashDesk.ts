import { Analysis } from "../../3rd/Analysis";
import { ByteMiniRecorder } from "../../3rd/ByteMiniRecorder";
import { getDadian } from "../../3rd/dadian";
import DataFunc from "../../common/DataFunc";
import uiFunc from "../../common/uiFunc";
import { DragAndDrop } from "../../components/DragAndDrop";
import { DtoOrder, OrderLogic } from "../../gameLogic/logics/OrderLogic";
import { PizzaLogic } from "../../gameLogic/logics/PizzaLogic";
import { SaleLogic } from "../../gameLogic/logics/SaleLogic";
import { uiFix } from "../../ui/uiFix";
import { uiRateUs } from "../../ui/uiRateUs";
import uiSummary from "../../ui/uiSummary";
import uiTopMain from "../../ui/uiTopMain";
import UserData from "../../userdata/UserData";
import { PromiseUtil } from "../../utils/PromiseUtil";
import { TweenUtil } from "../../utils/TweenUtil";
import { Util } from "../../utils/Util";
import { DecorateMgr } from "../managers/DecorateMgr";
import { GuideSteps } from "../managers/GuideSteps";
import Guest from "./Guest";
import { PanCake } from "./PanCake";

const { ccclass, property } = cc._decorator;

@ccclass
export class CashDesk extends cc.Component {
    @property(cc.Node)
    node_cake: cc.Node = null
    @property(cc.Sprite)
    spr: cc.Sprite = null
    @property(cc.Node)
    node_touch: cc.Node = null
    @property(cc.Node)
    node_black: cc.Node = null
    @property(Guest)
    guest: Guest = null
    @property(cc.Node)
    node_ui: cc.Node[] = []
    @property(cc.Node)
    node_cash: cc.Node = null
    @property(cc.Label)
    label_cash: cc.Label = null
    @property(sp.Skeleton)
    spine_lucky_cat: sp.Skeleton = null
    @property(cc.Node)
    node_open: cc.Node = null
    @property(cc.Node)
    node_sign: cc.Node = null
    @property(cc.Node)
    node_door: cc.Node = null

    // LIFE-CYCLE CALLBACKS:
    public static ins: CashDesk
    private cakePos = cc.v3()
    protected onLoad(): void {
        window.cd = this;
        CashDesk.ins = this;
        this.node_cake.getComponent(DragAndDrop).on('drop', this.onDrop, this);
        this.cakePos = this.node_cake.position;
    }
    protected start(): void {
        if (GuideSteps.ins.isGuide) {
            this.hideUi();
            const order = this.curOrder = OrderLogic.getOrderById(1);
            this.guest.showUp({ data: order, isLock: false }, '1');
            ByteMiniRecorder.start(300);
            this.spine_lucky_cat.setAnimation(0, 'daiji', true);
            this.downSign();
        } else {
            DecorateMgr.ins.setNight();
            this.newDay();
        }
        this.node_cake.active = false;
    }

    public showUi() {
        this.node_ui.forEach(Util.showNode);
    }
    public hideUi() {
        this.node_ui.forEach(Util.hideNode);
    }

    private level = 1
    public setCake(sf: cc.SpriteFrame, level: number) {
        this.node_cake.opacity = 255;
        this.node_cake.active = true;
        this.node_cake.position = this.cakePos;
        this.spr.spriteFrame = sf;
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.guide(this.node_cake, cc.v3(), [this.guest.node, this.node_cake], '', [this.node_cake, this.guest.node], [cc.v3(), cc.v3(0, 100)]);
        }
        this.level = level;
    }

    public curOrder: DtoOrder
    private nextGuest() {
        uiTopMain.ins.resetFavor();
        const d = this.randOrder();
        this.curOrder = d.data;
        this.guest.showUp(d);
    }
    private randOrder(): { data: DtoOrder, isLock: boolean } {
        // return OrderLogic.randOrderUnlocked();
        return OrderLogic.newOrderRule();
    }

    private canTouch = false
    private async onDrop() {
        if (!this.canTouch) return;
        if (!this.node_cake.getBoundingBoxToWorld().intersects(this.guest.node.getBoundingBoxToWorld())) {
            this.node_cake.position = this.cakePos;
            return;
        }
        this.canTouch = false;
        if (GuideSteps.ins.isGuide) {
            GuideSteps.ins.endGuide();
            UserData.set('guide', 1);
        }
        this.node_cake.getComponent(DragAndDrop).enabled = false;
        const tw = cc.tween(this.node_cake)
            .to(1, { opacity: 0 })
        await PromiseUtil.tween(tw);
        this.canTouch = true;
        await this.guest.getPizza(this.level);
        this.cooking = false;
        if (uiTopMain.ins.isSaleEnd()) {
            // this.summary();
            this.onTimeUp();
        } else {
            this.nextGuest();
        }
        this.node_cake.getComponent(DragAndDrop).enabled = true;
        this.node_cake.active = false;
        this.node_cake.position = this.cakePos;
        Analysis.eventOnce(getDadian("first_jiaofu"));
    }

    private async transIn() {
        const tw = cc.tween(this.node_black)
            .to(0.5, { opacity: 255 })
        await PromiseUtil.tween(tw);
    }
    private async transOut() {
        const tw = cc.tween(this.node_black)
            .to(0.5, { opacity: 0 })
        await PromiseUtil.tween(tw);
    }
    public cooking = false
    public leftCnt = 2
    public async transToCook() {
        this.canTouch = false;
        await this.transIn();
        this.node.active = false;
        PanCake.ins.node.active = true;
        PanCake.ins.reset();
        await this.transOut();
        this.canTouch = true;
        uiTopMain.ins.showTips();
        uiTopMain.ins.resumeAll();

        this.leftCnt--;
        if (this.leftCnt < 0) {
            uiFunc.open(uiFix);
        }
        Analysis.eventOnce(getDadian("first_cook"));
    }
    public async transBack() {
        this.canTouch = false;
        await this.transIn();
        this.node.active = true;
        PanCake.ins.node.active = false;
        await this.transOut();
        uiTopMain.ins.hideTips();
        this.canTouch = true;
        // this.cooking = false;
    }

    private checkSpecial(): boolean {
        const first = DataFunc.getBaseConfig('SPECIAL_FIRST'),
            inter = DataFunc.getBaseConfig('SPECIAL_INTER'),
            day = PizzaLogic.getDay();
        return (day - first) % (inter + 1) == 0;
    }
    public summary() {
        // if (PizzaLogic.getDay()) uiRateUs.open();
        this.isFirst = false;
        PizzaLogic.endToday();
        const rent = DataFunc.getBaseConfig('SHOP_COST');
        uiTopMain.ins.useGold(rent);
        SaleLogic.addRent(rent);
        if (this.checkSpecial()) {
            this.guest.showSpecial();
        } else {
            uiFunc.open(uiSummary, SaleLogic.SaleData);
        }
        this.spine_lucky_cat.setAnimation(0, 'sleep', true);
    }
    public onNight() {
        DecorateMgr.ins.outsideNight();
    }
    public async onTimeUp() {
        if (this.cooking) return;
        if (this.guest.node.active) {
            await this.guest.getOut();
        }
        DecorateMgr.ins.turnNight();
        await Util.delay(1);
        await this.flySign();
        await Util.delay(.5);
        this.summary();
    }

    private isFirst = true
    public async newDay() {
        DecorateMgr.ins.outsideDay();
        uiTopMain.ins.resetFavor();
        uiTopMain.ins.resetTime();
        SaleLogic.reset();
        const tw1 = cc.tween(this.node_open)
            .to(.3, { scale: 1 }, { easing: cc.easing.backOut })
        await PromiseUtil.tween(tw1);
        this.node_open.getComponent(cc.Button).interactable = true;
        cc.tween(this.node_open)
            .to(.3, { scale: 1.1 })
            .to(.3, { scale: .9 })
            .union()
            .repeatForever()
            .start();
    }
    private async openStore() {
        // if (!this.isFirst) {
        DecorateMgr.ins.turnDay();
        // }
        const btn = this.node_open.getComponent(cc.Button);
        btn.interactable = false;
        this.node_open.stopAllActions();
        cc.tween(this.node_open)
            .to(.3, { scale: 0 }, { easing: cc.easing.backIn })
            .call(() => btn.interactable = false)
            .start();
        this.spine_lucky_cat.setAnimation(0, 'daiji', true);
        uiTopMain.ins.resumeTime();
        this.downSign();
        await Util.delay(1);
        this.nextGuest();
        ByteMiniRecorder.start(300);
        Analysis.event(getDadian("begin_" + (PizzaLogic.getDay() + 1) + "day" as any));
    }

    //收客人钱飘字
    public async cashIn(cnt: number) {
        TweenUtil.jelly(this.node_cash, 3);
        this.label_cash.string = '+' + cnt.toFixed(2);
        const y = -206;
        const tw = cc.tween(this.label_cash.node)
            .set({ opacity: 255, y })
            .to(1, { opacity: 0, y: y + 100 })
        await PromiseUtil.tween(tw);
    }

    private orgSignY = 0
    private orgDoorY = 0
    private async flySign() {
        const s = .8, t = .15;
        const tw = cc.tween(this.node_sign)
            .to(t, { scaleY: 1 - s, scaleX: 1 + s })
            .to(t, { scaleY: 1 + s, scaleX: 1 - s })
            .to(t, { y: this.orgSignY }, { easing: cc.easing.sineOut })
        const tw1 = cc.tween(this.node_door)
            .to(t, { y: this.orgDoorY })
        await Promise.all([PromiseUtil.tween(tw), PromiseUtil.tween(tw1)]);
    }
    private async downSign() {
        if (!this.orgSignY) {
            this.orgSignY = this.node_sign.y;
            this.orgDoorY = this.node_door.y;
        }
        const s = .8, t = .15;
        const tw = cc.tween(this.node_sign)
            .to(t, { y: this.orgSignY - 500 }, { easing: cc.easing.sineIn })
            .to(t, { scaleY: 1 - s, scaleX: 1 + s })
            .to(t, { scaleY: 1, scaleX: 1 })
        const tw1 = cc.tween(this.node_door)
            .to(t, { y: this.orgDoorY + this.node_door.height })
        await Promise.all([PromiseUtil.tween(tw), PromiseUtil.tween(tw1)]);
    }
}