const { ccclass, property } = cc._decorator;

@ccclass
export default class Dialog extends cc.Component {

    @property(cc.Node)
    btnYes: cc.Node = null;
    @property(cc.Node)
    btnNo: cc.Node = null;

    @property(cc.Node)
    sp_talk: cc.Node = null;
    @property(cc.RichText)
    t_talk: cc.Label = null;

    private _typeSpeed:number = 0.06;

    protected onEnable(): void {
        let ts = this;
        ts.hideDialog();
    }

    protected onDisable(): void {
        let ts = this;
        ts.hideDialog();
    }

    showDialog():void{
        let ts = this;
        ts.sp_talk.active = true;
    }
    
    hideDialog():void{
        let ts = this;
        ts.sp_talk.active = false;
    }

    setText(text: string, animated: boolean = true): Promise<void> {
        let ts = this;
        return new Promise<void>((resolve,reject)=>{
            ts.t_talk.string = '';
            if (!text || text.length <= 0) resolve();
            ts.showDialog();
            if (animated) {
                let loopTime: number = text.length;
                let curIdx: number = 0;
                ts.schedule(() => {
                    ts.t_talk.string += text[curIdx++];
                    if (curIdx === loopTime) resolve();
                }, ts._typeSpeed, loopTime - 1);
            } else {
                ts.t_talk.string = text;
                resolve();
            }
        });
    }

    updateBtnState(showYes:boolean,showNo:boolean):void{
        let ts = this;
        let both:boolean = (showYes && showNo) || (!showYes && !showNo);
        ts.btnYes.active = showYes;
        ts.btnNo.active = showNo;
        ts.btnYes.x = both ? -52 : 60;
        ts.btnNo.x = both ? 226 : 60;
    }
}
