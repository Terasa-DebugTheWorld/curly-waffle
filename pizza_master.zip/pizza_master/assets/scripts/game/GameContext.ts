import { ClientEvent } from "../common/ClientEvent";
import PersistBuffTime from "../common/PersistBuffTime";
import uiFunc from "../common/uiFunc";
import { DtoOrder, DtoOrderRecord, OrderLogic } from "../gameLogic/logics/OrderLogic";
import { SaleLogic } from "../gameLogic/logics/SaleLogic";
import { EventType } from "../static/EventType";
import Guest from "./core/Guest";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameContext extends cc.Component {
    public static instance: GameContext = null;

    @property(Guest)
    public guest: Guest = null;

    private _pause: boolean = false;
    public get Pause(): boolean {
        return this._pause;
    }
    public set Pause(v: boolean) {
        this._pause = v;
    }
    /**订单记录 */
    private _orderRecords: DtoOrderRecord[] = [];
    public get OrderRecords(): DtoOrderRecord[] {
        return this._orderRecords;
    }

    onLoad() {
        GameContext.instance = this;
        window["GameContext"] = this;
        //碰撞系统
        // var manager = cc.director.getCollisionManager();
        // manager.enabled = true;
        //物理系统
        // let physicsManager = cc.director.getPhysicsManager();
        // physicsManager.enabled = true;
        // physicsManager.debugDrawFlags =
        //     cc.PhysicsManager.DrawBits.e_jointBit |
        //     cc.PhysicsManager.DrawBits.e_shapeBit
        //     ;
        // uiFunc.group = "ui";
    }

    /**订单记录 */
    setOrderRecord(dto: DtoOrderRecord): void {
        let ts = this;
        ts._orderRecords.push(dto);
    }
    /**订单清空 */
    clearOrderRecord(): void {
        let ts = this;
        ts._orderRecords = [];
    }

}