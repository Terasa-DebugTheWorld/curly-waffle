import { System } from "../../common/System";
import UserData from "../../userdata/UserData";
import { Util } from "../../utils/Util";
import { FingerEffect } from "../comp/FingerEffect";

const { ccclass, property } = cc._decorator;

export enum GuideCode {
    none = 0,
    chef,
}
@ccclass
export class GuideSteps extends cc.Component {
    @property(sp.Skeleton)
    finger: sp.Skeleton = null
    @property(cc.Node)
    node_block: cc.Node = null
    @property(cc.Node)
    node_highlight: cc.Node = null
    @property(cc.Label)
    label_tips: cc.Label = null

    // LIFE-CYCLE CALLBACKS:
    public static ins: GuideSteps
    private code = GuideCode.none
    protected onLoad(): void {
        GuideSteps.ins = this;
        if (UserData.get('guide') != 1) {
            const vw = System.getVisibleWidth();
            this.node_block.x = this.node_block.width / 2 - vw / 2;
            this.label_tips.node.parent.x = -vw / 2;
            this.code = GuideCode.chef;
            this.node_block.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        }
    }

    public get isGuide(): boolean {
        return this.code != GuideCode.none;
    }

    public guide(pointTarget?: cc.Node, offset = cc.v3(), hightlights: cc.Node[] = [], tips = '', slideRange?: [cc.Node, cc.Node],
        slideOffset?: [cc.Vec3, cc.Vec3], isCircle = false) {
        this.hideGuide();
        if (hightlights) {
            this.pullUp(hightlights);
            this.blockInput();
        }
        if (pointTarget) {
            this.finger.animation = '';
            this.point(pointTarget, offset);
            if (slideRange) {
                slideOffset = slideOffset || [cc.v3(), cc.v3()];
                const a = Util.fromNodeToNode(this.finger.node.parent, slideRange[0]);
                const b = Util.fromNodeToNode(this.finger.node.parent, slideRange[1]);
                const s = a.add(slideOffset[0]);
                const d = b.add(slideOffset[1]);
                this.finger.node.parent.stopAllActions();
                cc.tween(this.finger.node.parent)
                    .set({ position: s })
                    .to(0.5, { position: d })
                    .delay(0.3)
                    .union()
                    .repeatForever()
                    .start();
            } else if (isCircle) {
                this.finger.setAnimation(0, 'quan', true);
            } else {
                this.finger.setAnimation(0, 'daiji', true);
            }
        }
        if (tips) {
            this.tips(tips);
        }
    }
    public hideGuide() {
        this.unpoint();
        this.unblockInput();
        this.putBack();
        this.untips();
    }
    public endGuide() {
        this.hideGuide();
        this.code = GuideCode.none;
    }

    public point(node: cc.Node, offset = cc.v3()) {
        this.finger.node.parent.active = true;
        const pos = Util.fromNodeToNode(this.finger.node.parent, node);
        this.finger.node.parent.position = pos.add(offset);
    }
    public unpoint() {
        this.finger.node.parent.active = false;
    }
    public blockInput() {
        this.node_block.active = true;
    }
    public unblockInput() {
        this.node_block.active = false;
    }
    private hls: { node: cc.Node, parent: cc.Node, pos: cc.Vec3, idx: number }[] = []
    public pullUp(nodes: cc.Node[]) {
        this.hls = nodes.map(n => { return { node: n, parent: n.parent, pos: n.position, idx: n.getSiblingIndex() } });
        nodes.forEach(n => {
            const pos = n.position;
            const parent = n.parent;
            n.parent = this.node_highlight;
            n.position = this.node_highlight.convertToNodeSpaceAR(parent.convertToWorldSpaceAR(pos));
        });
    }
    public putBack() {
        this.hls.forEach(n => {
            n.node.parent = n.parent;
            n.node.position = n.pos;
            this.hls.forEach(n => n.node.setSiblingIndex(n.idx));
        });
        this.hls.length = 0;
    }
    public tips(text: string) {
        this.label_tips.string = text;
        const n = this.label_tips.node.parent;
        n.y = n.height / 2 - 720 / 2;
    }
    public untips() {
        const n = this.label_tips.node.parent;
        n.y = -n.height / 2 - 720 / 2;
    }

    private cb: Function
    private onTouch() {
        const cb = this.cb;
        if (cb) {
            this.cb = null;
            cb();
        }
    }
    public listenTouchAnywhere(cb: Function) {
        this.cb = cb;
    }
}