const { ccclass, property } = cc._decorator;

@ccclass
export default class GameUI extends cc.Component {
    @property(cc.Label)
    label_toast: cc.Label = null

    public static inst: GameUI = null;
    protected onLoad(): void {
        GameUI.inst = this;
        window["GameUI"] = this;
    }

    private orgToastY = 0
    public showToast(str: string) {
        if (this.orgToastY == undefined) {
            this.orgToastY = this.label_toast.node.parent.y;
        }
        this.label_toast.node.parent.zIndex = cc.macro.MAX_ZINDEX;
        this.label_toast.string = str;
        this.label_toast.node.parent.stopAllActions();
        cc.tween(this.label_toast.node.parent)
            .set({ opacity: 255, y: this.orgToastY })
            .delay(1)
            .by(0.5, { opacity: -255, y: 100 })
            .start();
    }
    public static showToast(str: string) {
        this.inst.showToast(str);
    }
}