import NodePool from "../../common/NodePool";
import { SpinePlayer } from "../../components/SpinePlayer";
import { SliverLogic } from "../../gameLogic/logics/SliverLogic";
import { Util } from "../../utils/Util";
import { LockCailiao } from "../comp/LockCailiao";

const { ccclass, property } = cc._decorator;

@ccclass
export class CailiaoMgr extends cc.Component {
    @property(cc.Layout)
    layout: cc.Layout = null
    @property(LockCailiao)
    cls: LockCailiao[] = []
    @property(cc.Node)
    parent_smoke: cc.Node = null
    @property(cc.Prefab)
    prefab_smoke: cc.Prefab = null
    @property(cc.Node)
    parent_light: cc.Node = null
    @property(cc.Prefab)
    prefab_light: cc.Prefab = null

    protected resetInEditor(): void {
        this.cls = this.getComponentsInChildren(LockCailiao);
    }

    // LIFE-CYCLE CALLBACKS:
    public static ins: CailiaoMgr
    protected onLoad(): void {
        CailiaoMgr.ins = this;
        const datas = SliverLogic.getUnlockedSlivers();
        const temp = this.cls[0].node;
        const num = 15;
        for (let i = 0; i < num; i++) {
            const node = cc.instantiate(temp);
            node.parent = this.layout.node;
            const cl = node.getComponent(LockCailiao);
            this.cls.push(cl);
        }
        datas.forEach((d, i) => {
            if (i == 0) return;
            const cl = this.cls[i - 1];
            cl.init(d);
        });
        if (datas.length > this.cls.length) return;
        this.cls[datas.length - 1].init();
    }

    public onBuySliver(id: number) {
        const idx = SliverLogic.getUnlockedSlivers().length - 2;
        if (idx >= this.cls.length) return;
        this.cls[idx].init(id, true);
        const cnt = SliverLogic.getUnlockedSlivers().length - 1;
        if (cnt >= this.cls.length) return;
        this.cls[cnt].init();
    }
    private pool = new NodePool()
    private lights: cc.Node[] = []
    public playSmoke(cl: LockCailiao) {
        const target = cl.node;
        const node = this.pool.get(this.prefab_smoke);
        node.parent = this.parent_smoke;
        const spine = node.getComponent(sp.Skeleton);
        node.position = Util.fromNodeToNode(node, target);
        SpinePlayer.play(spine, 0, 'daiji')
            .then(() => this.pool.put(node));

        const node2 = this.pool.get(this.prefab_light);
        node2.parent = this.parent_light;
        node2.position = Util.fromNodeToNode(node2, target);
        this.lights[this.cls.indexOf(cl)] = node2;
    }
    public recycleLight(node: cc.Node) {
        const id = this.cls.indexOf(node.getComponent(LockCailiao));
        if (this.lights[id]) this.pool.put(this.lights[id]);
    }
}