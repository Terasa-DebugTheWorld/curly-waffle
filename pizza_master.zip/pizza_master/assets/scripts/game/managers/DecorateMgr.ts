import { ClientEvent } from "../../common/ClientEvent";
import { DecorateLogic } from "../../gameLogic/logics/DecorateLogic";
import { EventType } from "../../static/EventType";
import { SceneDecoration } from "../view/SceneDecoration";

const { ccclass, property } = cc._decorator;

@ccclass
export class DecorateMgr extends cc.Component {
    @property(SceneDecoration)
    outside: SceneDecoration = null

    // LIFE-CYCLE CALLBACKS:
    public static ins: DecorateMgr
    // public color = '120,190,240'
    protected onLoad(): void {
        // window.jb = this;
        DecorateMgr.ins = this;
        ClientEvent.on(EventType.CHANGE_DECORATION, this.onDecorationChange, this);
    }

    private decs: Dictionary<SceneDecoration[]> = {}
    public bindDec(dec: SceneDecoration) {
        if (dec.dec_id < 0) return;
        if (!this.decs[dec.dec_id]) {
            this.decs[dec.dec_id] = [];
        }
        this.decs[dec.dec_id].push(dec);
    }

    private onDecorationChange(type: number) {
        this.decs[type].forEach(d => d.refresh());
    }

    public async outsideNight() {
        await this.outside.turnNight();
    }
    public outsideDay() {
        this.outside.turnDay();
    }
    public turnNight() {
        for (let i in this.decs) {
            this.decs[i].forEach(d => d.turnNight());
        }
    }
    public turnDay() {
        for (let i in this.decs) {
            this.decs[i].forEach(d => d.turnDay());
        }
    }
    public setNight() {
        for (let i in this.decs) {
            this.decs[i].forEach(d => d.setNight());
        }
    }
}