import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { ClientEvent } from "../../common/ClientEvent";
import { DecorateLogic } from "../../gameLogic/logics/DecorateLogic";
import { EventType } from "../../static/EventType";

const { ccclass, property } = cc._decorator;

@ccclass
export class PackageBack extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        ClientEvent.on(EventType.CHANGE_DECORATION, this.onChange, this);
        this.onChange(11);
    }

    private onChange(type: number) {
        if (type == 11) {
            const frontName = DecorateLogic.getConfig(DecorateLogic.getUsing(type)).scene;
            const isMain = !frontName.endsWith('1');
            const backName = frontName.replace('dai', 'dai2');
            const bundle = isMain ? 'resources' : 'more',
                url = isMain ? 'textures/main/' : 'decorations/';

            WxSubpackageLoader.loadSpriteFrame(bundle, url + backName)
                .then(sf => this.getComponent(cc.Sprite).spriteFrame = sf);
        }
    }
}