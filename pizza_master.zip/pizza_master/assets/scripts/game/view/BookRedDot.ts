import { ClientEvent } from "../../common/ClientEvent";
import { RecipeLogic } from "../../gameLogic/logics/RecipeLogic";
import { EventType } from "../../static/EventType";

const { ccclass, property } = cc._decorator;

@ccclass
export class BookRedDot extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        this.check();
        ClientEvent.on(EventType.UPDATE_RECIPE_DOT, this.check, this);
    }

    private check() {
        const unlocks = RecipeLogic.getUnlockRecipeCnt();
        const rewardeds = RecipeLogic.getRewardedCnt();
        this.node.active = rewardeds < unlocks;
    }
}