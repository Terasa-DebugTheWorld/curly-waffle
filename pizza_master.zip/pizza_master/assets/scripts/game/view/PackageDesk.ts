import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { ClientEvent } from "../../common/ClientEvent";
import { DecorateLogic } from "../../gameLogic/logics/DecorateLogic";
import { EventType } from "../../static/EventType";

const { ccclass, property } = cc._decorator;

@ccclass
export class PackageDesk extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        ClientEvent.on(EventType.CHANGE_DECORATION, this.onChange, this);
        this.onChange(11);
    }

    private onChange(type: number) {
        if (type == 11) {
            const id = DecorateLogic.getConfig(DecorateLogic.getUsing(type)).scene.endsWith('1') ? '1' : '0';
            const name = 'yuanhua_zhuwanfa_bgbingdai_' + id;
            WxSubpackageLoader.loadSpriteFrame('resources', 'textures/main/' + name)
                .then(sf => this.getComponent(cc.Sprite).spriteFrame = sf);
        }
    }
}