import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { DecorateLogic } from "../../gameLogic/logics/DecorateLogic";
import { PromiseUtil } from "../../utils/PromiseUtil";
import { DecorateMgr } from "../managers/DecorateMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export class SceneDecoration extends cc.Component {
    @property
    dec_id = 0  //其实是type，编辑器里配置完了才发现命名错了，不改了
    @property
    noNight = false

    // LIFE-CYCLE CALLBACKS:
    private mtl: cc.Material
    onLoad() {
        DecorateMgr.ins.bindDec(this);
        WxSubpackageLoader.load('resources', 'shader/materials/Multiply', cc.Material)
            .then(mtl => {
                this.mtl = this.getComponent(cc.Sprite).setMaterial(0, mtl as cc.Material);
                if (this.nightPercent == 0) return;
                this.nightPercent = this.nightPercent;
            });

        //有的图需要转变白天黑夜，但其实不是装饰品，用负数id
        if (this.dec_id < 0) return;
        this.refresh();
    }

    public refresh() {
        if (this.dec_id < 0) return;
        const id = DecorateLogic.getUsing(this.dec_id);
        if (!id) return;
        const cfg = DecorateLogic.getConfig(id);
        const name = cfg.scene;
        const isMain = !name.endsWith('1');
        const bundle = isMain ? 'resources' : 'more',
            url = isMain ? 'textures/main/' : 'decorations/';
        WxSubpackageLoader.loadSpriteFrame(bundle, url + name)
            .then(sf => this.getComponent(cc.Sprite).spriteFrame = sf);
    }

    private _percent = 0
    private get nightPercent(): number {
        return this._percent;
    }
    private set nightPercent(v: number) {
        this._percent = v;
        if (!this.mtl) return;
        // const arr = DecorateMgr.ins.color.split(',').map(s => Number(s));
        // const c=cc.color(arr[0], arr[1], arr[2])
        const color = cc.Color.WHITE.lerp(cc.color(80, 100, 145), v);
        const vec = [color.r / 255, color.g / 255, color.b / 255, 1];
        this.mtl.setProperty('color', vec);
    }
    public async turnNight() {
        if (this.noNight) return;
        const tw = cc.tween(this)
            .to(.8, { nightPercent: 1 } as any)
        return PromiseUtil.tween(tw);
    }
    public async turnDay() {
        if (this.noNight) return;
        const tw = cc.tween(this)
            .to(.8, { nightPercent: 0 } as any)
        return PromiseUtil.tween(tw);
    }

    public setNight() {
        if (this.noNight) return;
        this.nightPercent = 1;
    }
}