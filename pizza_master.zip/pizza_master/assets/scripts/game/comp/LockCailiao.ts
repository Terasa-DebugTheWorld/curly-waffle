import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import uiFunc from "../../common/uiFunc";
import { SliverLogic } from "../../gameLogic/logics/SliverLogic";
import uiShop from "../../ui/uiShop";
import { Util } from "../../utils/Util";
import { CailiaoMgr } from "../managers/CailiaoMgr";
import { cailiaoBtn } from "./cailiaoBtn";

const { ccclass, property } = cc._decorator;

@ccclass
export class LockCailiao extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    private isLock = true
    init(id?: number, needAnim = false) {
        this.node.active = true;
        if (id) {
            this.unlock(id, needAnim);
        } else {
            this.node.on(cc.Node.EventType.TOUCH_END, this.onClick, this);
        }
    }

    private onClick() {
        if (this.isLock) {
            uiFunc.open(uiShop, this);
        }
    }

    public unlock(id: number, needAnim = false) {
        this.isLock = false;
        this.node.off(cc.Node.EventType.TOUCH_END, this.onClick, this);
        const cfg = SliverLogic.getSliverById(id);
        const picName = cfg.makeShow.slice(0, cfg.makeShow.length - 1);
        WxSubpackageLoader.loadSpriteFrame('more', 'sliver/' + picName).then(sf => {
            this.getComponent(cc.Sprite).spriteFrame = sf;
            const cl = this.addComponent(cailiaoBtn);
            cl.id = id;
            cl.isTu = cfg.put == 1;
            if (needAnim) this.node.opacity = 0;
        });
    }

    public playUnlock() {
        const node = new cc.Node();
        node.parent = this.node;
        const icon = node.addComponent(cc.Sprite);
        const spr = this.node.getComponent(cc.Sprite);
        icon.spriteFrame = spr.spriteFrame;
        spr.enabled = false;
        node.stopAllActions();
        node.y = 50;
        cc.tween(node)
            .delay(.5)
            .call(() => this.node.opacity = 255)
            .to(.2, { y: 0 }, { easing: cc.easing.backOut })
            .call(() => {
                node.destroy();
                spr.enabled = true;
                CailiaoMgr.ins.playSmoke(this);
            })
            .start();
    }
}