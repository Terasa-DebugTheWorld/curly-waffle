import { System } from "../../common/System";

const { ccclass, property } = cc._decorator;

@ccclass
export class MidInScreen extends cc.Component {
    @property
    isHori = false
    @property
    isVert = false

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        if (this.isHori) {
            this.node.x = System.getVisibleWidth() / 2;
        }
        if (this.isVert) {
            this.node.y = System.getVisibleHeight() / 2;
        }
    }
}