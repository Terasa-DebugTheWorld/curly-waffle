import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import { PizzaLogic } from "../../gameLogic/logics/PizzaLogic";
import { SliverLogic } from "../../gameLogic/logics/SliverLogic";
import { CakeState, PanCake } from "../core/PanCake";
import { CailiaoMgr } from "../managers/CailiaoMgr";
import { GuideSteps } from "../managers/GuideSteps";

const { ccclass, property } = cc._decorator;

@ccclass
export class cailiaoBtn extends cc.Component {
    @property
    id = 1
    @property
    isBaocui = false
    @property
    isTu = false

    // @property(cc.Prefab)
    prefab: cc.Node = new cc.Node()
    // @property(cc.Node)
    node_using: cc.Node = null
    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        this.node.on(cc.Node.EventType.TOUCH_END, this.onClick, this);
        const sf = this.node.getComponent(cc.Sprite).spriteFrame;

        const node = new cc.Node();
        WxSubpackageLoader.loadSpriteFrame('more', 'sliver/' + sf.name + '2').then(sf1 => {
            node.addComponent(cc.Sprite).spriteFrame = sf1;
            node.parent = this.node;
            this.node_using = node;
            node.y = node.height / 2 - this.node.height / 2;
            node.active = false;
        });

        this.prefab = new cc.Node();
        WxSubpackageLoader.loadSpriteFrame('more', 'sliver/' + sf.name + '3').then(sf1 => {
            this.prefab.addComponent(cc.Sprite).spriteFrame = sf1;
        });
    }

    public isUsing = false;
    private onClick() {
        CailiaoMgr.ins.recycleLight(this.node);
        if (PanCake.ins.isNotState(CakeState.diy)) return;
        if (GuideSteps.ins.isGuide && this.isUsing) return;
        this.isUsing = !this.isUsing;
        this.node_using.active = this.isUsing;
        PanCake.ins.onClickCailiao(this);
        PanCake.ins.node_tiaozhuang_guide.active = PanCake.ins.node_keli_guide.active = false;
        if (this.isUsing) {
            let guideNode: cc.Node;
            if (this.isBaocui) {
                guideNode = PanCake.ins.node_tiaozhuang_guide;
            } else {
                const put = SliverLogic.getSliverById(this.id).put;
                if (put == 2) {
                    guideNode = PanCake.ins.node_keli_guide;
                } else if (put == 3) {
                    guideNode = PanCake.ins.node_tiaozhuang_guide;
                }
            }
            if (guideNode) guideNode.active = true;
        }
    }
    public unuse(): void {
        this.node_using.active = this.isUsing = false;
    }

    public get cost(): number {
        if (this.isBaocui) return 0.03;
        return SliverLogic.getSliverById(this.id).cost;
    }
}