const { ccclass, property } = cc._decorator;

@ccclass
export class SlideJudger extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
    }

    private begain: cc.Node
    private target: cc.Node
    private cb: Function
    public set(begain: cc.Node, target: cc.Node, cb: Function) {
        this.begain = begain;
        this.target = target;
        this.cb = cb;
    }

    private isMoving = false
    private onTouchStart(e: cc.Event.EventTouch) {
        if (!this.begain || !this.target || !this.cb) return;
        if (!this.begain.getBoundingBoxToWorld().contains(e.getLocation())) return;
        this.isMoving = true;
    }
    private onTouchMove(e: cc.Event.EventTouch) {
        if (!this.begain || !this.target || !this.cb || !this.isMoving) return;
        if (!this.target.getBoundingBoxToWorld().contains(e.getLocation())) return;
        this.isMoving = false;
        this.cb();
    }
    private onTouchEnd(e: cc.Event.EventTouch) {
        if (!this.begain || !this.target || !this.cb) return;
        this.isMoving = false;
    }
}
