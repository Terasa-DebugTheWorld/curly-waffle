const { ccclass, property } = cc._decorator;

@ccclass
export class FingerEffect extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    private orgPos: cc.Vec3
    protected onLoad(): void {
        this.orgPos = this.node.position;
    }
    protected onEnable(): void {
        cc.tween(this.node)
            .to(0.5, { y: this.orgPos.y - 50, x: this.orgPos.x + 50 })
            .to(0.5, { y: this.orgPos.y, x: this.orgPos.x })
            .union()
            .repeatForever()
            .start();
    }
    protected onDisable(): void {
        this.node.stopAllActions();
    }
}