import { Platform } from "../../3rd/Platform";

var request = (url, succ, fail) => {
    var xhr = cc.loader.getXMLHttpRequest();
    var url = url;
    xhr.onerror = function () {
        if (fail) fail();
        fail = null;
    }
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
            var response = xhr.responseText;
            if (succ) succ(response);
        } else if (xhr.status != 0 && xhr.status != 200) {
            if (fail) fail();
            fail = null;
        }
    };
    // console.log('req:',url);
    xhr.open("GET", url, true);
    xhr.send();
}

var requestAsync = (url) => {
    return new Promise((resolve, reject) => {
        request(url, resolve, reject)
    })
}

const TAG = "WxHack";
const TEST_SERVER = "http://121.43.132.110:6785"
const PRODUCT_SERVER = "https://minigame.nagagame.net"
export default new class {
    debug = false;
    isInit = false;
    //骚操作总开关
    ban = true;
    //强弹视频开关
    qtsp = false;
    private _banData = {};
    init() {
        if (this.debug) {
            this.isInit = true;
            this._configResolve.forEach(r => {
                r();
            })
            this.ban = false;
            return;
        }
        let sceneid = 1;
        if (Platform.isWx) {
            let launchOptions = wx.getLaunchOptionsSync();
            sceneid = launchOptions.scene;
            console.log("场景id",sceneid);
        }
        request(`${PRODUCT_SERVER}/control/ban?sceneid=${sceneid}`, (resp) => {
            try {
                let obj = JSON.parse(resp);
                this._banData = obj;
                this.ban = obj.ban;
                this.qtsp = obj.qtsp;
                this.isInit = true;
                this._configResolve.forEach(r => {
                    r();
                })
                console.log(TAG, `init succ`, obj)
            } catch (error) {
                console.error(error);
            }
        }, null)
        window[TAG] = this;
    }

    _configResolve = [];
    public waitInit() {
        return new Promise((resolve, reject) => {
            if (this.isInit) {
                resolve(null);
            } else {
                this._configResolve.push(resolve);
            }
        })
    }

}