import { Ad } from "../../3rd/Ad";
import PersistBuffTime from "../../common/PersistBuffTime";
import uiFunc from "../../common/uiFunc";
import uiPanel from "../../common/uiPanel";
import BannerMgr from "../../managers/BannerMgr";
import { InsertMgr } from "../../managers/InsertMgr";
import UserData from "../../userdata/UserData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiClickBox extends uiPanel {

    @property(cc.ProgressBar)
    pb: cc.ProgressBar = null;

    bannerShowTimer = new PersistBuffTime(3);
    bannerFlag = false;
    percent
    protected onEnable(): void {
        this.pb.progress = 0;
        this.percent = 0;
        this.unscheduleAllCallbacks();
        this.schedule(() => {
            this.percent = Math.max(0, this.percent - 0.1);
        }, 1, cc.macro.REPEAT_FOREVER);
        cc.game.on(cc.game.EVENT_SHOW, this.onBgShow, this);
        this.bannerShowTimer.clearTime();
        this.bannerShowTimer.setOff();
        this.bannerShowTimer.setCallBack(this.onHideBanner, this);
        this.bannerFlag = false;

        //解压特有
        InsertMgr.instance.autoTimer.pause();
        InsertMgr.instance.stop = true;
        BannerMgr.inst.autoTimer.pause();
        BannerMgr.inst.showTimer.pause();
    }

    protected onDisable(): void {
        cc.game.off(cc.game.EVENT_SHOW, this.onBgShow, this);

        //解压特有
        InsertMgr.instance.autoTimer.resume();
        InsertMgr.instance.stop = false;
        BannerMgr.inst.autoTimer.resume();
        BannerMgr.inst.showTimer.resume();
    }

    onBgShow(): void {
        if (!this.node.active) return;
        if (!this.bannerFlag) return;
        this.quit();
        uiFunc.open("uiRemen");
    }

    onHideBanner() {
        Ad.hideBanner();
        this.quit();
        this.onPrize();
    }


    onClick() {
        this.percent = Math.min(1, this.percent + 0.2);
        if (!this.bannerFlag && this.percent > 0.6) {
            this.bannerFlag = true;
            Ad.playBanner();
            this.bannerShowTimer.clearTime();
            this.bannerShowTimer.setOn();
        }
    }

    onPrize() {
        //解压特有
        if (UserData.incr("wuchuBaoxiang") == 1) {
            let random = StageData.randomUnlock();
            uiFunc.open("uiGetStage", random);
        }
    }

    protected update(dt: number): void {
        this.pb.progress = this.percent;
        this.bannerShowTimer.update(dt);
    }
}
