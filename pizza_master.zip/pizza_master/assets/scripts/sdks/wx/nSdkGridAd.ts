import { ad_wx } from '../../3rd/ad-wx';
import { WeixinAPI } from '../../3rd/WeixinAPI';
import { ClientEvent } from '../../common/ClientEvent';
import { Util } from '../../utils/Util';
// import { nSdk } from './nSdk';

let customAdUnit = '';

const { ccclass, property } = cc._decorator;

@ccclass
export default class nSdkGridAd extends cc.Component {
    @property(cc.Sprite)
    sp: cc.Sprite = null;
    @property()
    unit = 1;

    daochu = false;

    public static instance: nSdkGridAd = null;
    onLoad() {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            customAdUnit = ad_wx.getHomeCustomUnit(this.unit);
        }
        nSdkGridAd.instance = this;
        // ClientEvent.on('hideNsdkGrid', () => {
        //     this.hide();
        // })
        // ClientEvent.on('showNsdkGrid', () => {
        //     this.show();
        // })
    }
    start() {
        this.show();
    }

    private showCnt = 0;
    showing = false;
    show() {
        console.log("显示格子广告", this.showCnt);
        // if (++this.showCnt <= 0) return;
        if (this.showing) return;
        this.showing = true;
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            if (this._isOnNad) {
                this.playnAd();
            } else {
                this.playWxAd();
            }
        } else {
            this.playnAd();
        }
    }

    _isOnNad = false;
    hide() {
        console.log("隐藏格子广告", this.showCnt);
        this.showCnt--;
        if (!this.showing) return;
        this.showing = false;
        if (this._isOnNad) {
            this.closenAd();
        } else {
            this.closeWxAd();
        }
    }

    customAd
    _customAdCloseFlag = false;
    _customAdLoading = false;
    private playWxAd() {
        if (this.customAd) {
            this.customAd.show();
            return;
        }
        this._customAdCloseFlag = false;
        if (this._customAdLoading) return;
        this._customAdLoading = true;
        let customAd = null
        const rect = this.node.getBoundingBoxToWorld();
        const wxRect = WeixinAPI.cocosUI2WxUi(rect.center, rect);
        console.log('grid rect', wxRect)
        if (wx.createCustomAd) {
            customAd = wx.createCustomAd({
                adUnitId: customAdUnit,
                adIntervals: 60,
                style: {
                    left: wxRect.left + wxRect.width / 10,
                    top: wxRect.top - wxRect.height / 3,
                    fixed: true,
                }
            });
        } else {
            this.playnAd();
        }

        if (customAd) {
            const closeCb = () => {
                if (customAd) {
                    customAd.destroy();
                    this.customAd = null;
                }
            };
            const errorCb = () => {

            };

            let showSucc = false;
            this.customAd = null;
            customAd.onClose(closeCb);
            customAd.onError(errorCb);
            customAd.show().then((msg) => {
                this._customAdLoading = false;
                showSucc = true;
                console.log('now show custom ad');
                this.customAd = customAd;
                if (this._customAdCloseFlag) {
                    this.closeWxAd();
                }
                ad_wx.closeInsert();
            }, (msg) => {
                this._customAdLoading = false;
                this.customAd = null;
                console.log('show custom ad fail, msg: ', msg);
                this.playnAd();
            });
        }
    }

    private closeWxAd() {
        this._customAdCloseFlag = true;
        if (this.customAd) {
            if (this.customAd.hide) {
                console.log('隐藏主页模板广告')
                this.customAd.hide()
            } else {
                this.customAd.destroy();
                this.customAd = null;
            }
        }
    }

    _freshTask
    _ad
    private async playnAd() {
        if (!this.daochu) return;
        await nSdk.waitInit();
        if (nSdk.isAudit()) return;
        if (nSdk.daochu.length == 0) {
            setTimeout(() => {
                this.playnAd();
            }, 5000)
            return;
        }
        this.node.opacity = 255;
        this._isOnNad = true;
        if (this._freshTask) clearInterval(this._freshTask)
        let showAd = () => {
            let arr = [];
            if (nSdk.getAdClickRecord().length >= nSdk.daochu.length) {
                arr = nSdk.daochu;
            } else {
                nSdk.daochu.forEach(d => {
                    if (nSdk.getAdClickRecord().indexOf(d.gameid) < 0) {
                        arr.push(d);
                    }
                })
            }
            let index = Util.getRandom(0, arr.length);
            this._ad = arr[index];
            cc.loader.load(this._ad.icon, (err, texture) => {
                if (err) {
                    cc.error(err);
                }
                else {
                    let sp = new cc.SpriteFrame(texture);
                    this.sp.spriteFrame = sp;
                }
            });
        }
        this._freshTask = setInterval(() => {
            showAd();
        }, 30 * 1000)
        showAd();
    }

    private closenAd() {
        this.node.opacity = 0;
    }

    onClick() {
        if (!this._ad) return;
        console.log(nSdk.gameid, this._ad)
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            wx.navigateToMiniProgram({
                appId: this._ad.appid,
                extraData: {
                    nfrom: nSdk.gameid
                },
                //envVersion: 'develop',
                success: (res) => {
                    // 打开成功
                    nSdk.setAdClick(this._ad.gameid);
                    this.playnAd();
                }
            })
        } else {
            nSdk.setAdClick(this._ad.gameid);
            this.playnAd();
        }
    }
}
