import { System } from "../../common/System";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BtnBottom extends cc.Component {
    
    protected start(): void {
        if (!System.isInDesignSize()) {
            this.node.y -= System.getVisibleHeight() * 0.032 * 2;
        }
    }
}
