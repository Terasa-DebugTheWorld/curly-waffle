import { AD_WX_PARAMS } from "../../../3rd/AdParams";
import WxGridContainer from "./WxGridContainer";
import WxGridData from "./WxGridData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class WxGridNode extends cc.Component {
    @property()
    param = ""
    @property()
    tag = ""
    @property()
    showByNode = true;

    protected onEnable(): void {
        this.scheduleOnce(() => {
            let grid = WxGridData.newGrid(AD_WX_PARAMS[this.param], this);
            let container = this.node.parent.getComponent(WxGridContainer);
            if (container) {
                container.add(this.tag);
            }
        })
    }

    protected onDisable(): void {
        if (this.showByNode) {
            WxGridData.closeGrid(this.tag);
        }
    }
}
