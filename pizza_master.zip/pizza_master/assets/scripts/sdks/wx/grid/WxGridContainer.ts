import WxGridData from "./WxGridData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class WxGridContainer extends cc.Component {
    @property()
    container_tag = ""

    add(tag) {
        WxGridData.registerContainer(this.container_tag, tag);
    }
}
