import { Platform } from "../../../3rd/Platform";
import { WeixinAPI } from "../../../3rd/WeixinAPI";
import WxGridNode from "./WxGridNode";

export class WxGrid {
    param
    tag
    customAd
    shown = false;
    constructor(param, gridNode: WxGridNode) {
        this.param = param;
        this.tag = gridNode.tag;
        const rect = gridNode.node.getBoundingBoxToWorld();
        const wxRect = WeixinAPI.cocosUI2WxUi(rect.center, rect);
        let customAd = wx.createCustomAd({
            adUnitId: param,
            adIntervals: 60,
            style: {
                left: wxRect.left,
                top: wxRect.top,
                fixed: true,
            }
        });
        this.customAd = customAd;
        customAd.show().then((msg) => {
            this.shown = true;
        }, (msg) => {

        });
    }

    show() {
        if (this.shown) return;
        if (this.customAd) {
            this.customAd.show();
            this.shown = true;
        }
    }

    close() {
        if (!this.shown) return;
        if (this.customAd) {
            this.shown = false;
            if (this.customAd.hide) {
                this.customAd.hide()
            } else {
                this.customAd.destroy();
                this.customAd = null;
            }
        }
    }
}


export default new class {
    grids = {}
    containers = {};
    newGrid(param, gridNode: WxGridNode) {
        if (!Platform.isWx) return;
        if (!this[gridNode.tag]) {
            let grid = new WxGrid(param, gridNode);
            this.grids[gridNode.tag] = grid;
        } else {
            console.log("找到缓存格子", gridNode.tag);
            this.grids[gridNode.tag].show();
        }
    }

    showGrid(tag) {
        let grid = this.grids[tag];
        if (grid) {
            grid.show();
        }
    }

    closeGrid(tag) {
        let grid = this.grids[tag];
        if (grid) {
            grid.close();
        }
    }

    registerContainer(containerTag, tag) {
        if (!this.containers[containerTag]) {
            this.containers[containerTag] = [];
        }
        this.containers[containerTag].push(tag);
    }

    unregisterContainer(containerTag, tag) {
        if (!this.containers[containerTag]) {
            this.containers[containerTag] = [];
        }
        let index = this.containers[containerTag].indexOf(tag);
        if (index >= 0) {
            this.containers[containerTag].splice(0, 1)
        }
    }

    showContainer(containerTag) {
        if (!this.containers[containerTag]) return;
        this.containers[containerTag].forEach(t => {
            this.showGrid(t);
        })
    }

    closeContainer(containerTag) {
        if (!this.containers[containerTag]) return;
        this.containers[containerTag].forEach(t => {
            this.closeGrid(t);
        })
    }
}