import { Ad } from "../../3rd/Ad";
import PersistBuffTime from "../../common/PersistBuffTime";
import uiFunc from "../../common/uiFunc";
import uiPanel from "../../common/uiPanel";
import BannerMgr from "../../managers/BannerMgr";
import { InsertMgr } from "../../managers/InsertMgr";
import { nSdk } from "./nSdk";
import WxHack from "./WxHack";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiRemenyouxi extends uiPanel {

    bannerTimer = new PersistBuffTime(1);
    bannerShowTimer = new PersistBuffTime(1.5);
    cnt
    wuchu = false;
    protected onEnable(): void {
        if (nSdk.isAudit() || nSdk.getConfig("remenwuchu") == "0") {
            this.wuchu = false;
        } else {
            this.wuchu = true;
        }
        Ad.hideBanner();
        this.cnt = 0;
        this.bannerTimer.clearTime();
        if (this.wuchu) this.bannerTimer.setOn();
        this.bannerTimer.setCallBack(this.showBanner, this);
        this.bannerShowTimer.setOff();
        this.bannerShowTimer.setCallBack(this.hideBanner, this);
        //解压特有
        InsertMgr.instance.autoTimer.pause();
        InsertMgr.instance.stop = true;
        BannerMgr.inst.autoTimer.pause();
        BannerMgr.inst.showTimer.pause();
    }

    protected onDisable(): void {
        Ad.hideBanner();
        //解压特有
        InsertMgr.instance.autoTimer.resume();
        InsertMgr.instance.stop = false;
        BannerMgr.inst.autoTimer.resume();
        BannerMgr.inst.showTimer.resume();
    }

    onContinue() {
        if (!this.wuchu) {
            this.quit();
            return;
        }
        this.cnt++;
        if (this.cnt == 1) return;
        let percent = Number(nSdk.getConfig("baoxiang"));
        if (!nSdk.isAudit() && Math.random() < percent && !WxHack.ban) {
            uiFunc.open("uiClickBox");
        }
        this.quit();
    }

    showBanner() {
        Ad.playBanner();
        this.bannerShowTimer.clearTime();
        this.bannerShowTimer.setOn();
    }

    hideBanner() {
        Ad.hideBanner();
        this.bannerTimer.clearTime();
        this.bannerTimer.setOn();
    }

    protected update(dt: number): void {
        this.bannerShowTimer.update(dt);
        this.bannerTimer.update(dt);
    }
}
