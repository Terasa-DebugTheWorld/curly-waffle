import { nSdk } from "./nSdk";
import WxHack from "./WxHack";

const { ccclass, property } = cc._decorator;

@ccclass
export default class wxSwitchBotton extends cc.Component {
    @property(cc.Node)
    btn_1: cc.Node = null;
    @property(cc.Node)
    btn_2: cc.Node = null;

    available = false;
    cnt = 0;
    pos1
    pos2
    protected start(): void {
        this.pos1 = this.btn_1.getPosition();
        this.pos2 = this.btn_2.getPosition();
    }

    protected onEnable(): void {
        if (!nSdk.isAudit() && nSdk.getConfig("button") == "1" && !WxHack.ban) {
            this.available = true;
        }
        this.cnt++;
        if (this.cnt % 3 == 0 && this.available) {
            let pos = this.btn_1.getPosition();
            if (pos.x == this.pos1.x && pos.y == this.pos1.y) {
                this.btn_1.setPosition(this.pos2);
                this.btn_2.setPosition(this.pos1);
            } else {
                this.btn_1.setPosition(this.pos1);
                this.btn_2.setPosition(this.pos2);
            }
        }
    }
}
