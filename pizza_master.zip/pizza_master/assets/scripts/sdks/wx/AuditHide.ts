import { nSdk } from "./nSdk";

const { ccclass, property } = cc._decorator;

@ccclass
export default class AuditHide extends cc.Component {

    protected start(): void {
        this.scheduleOnce(() => {
            if(nSdk.isAudit()) this.node.active = false;
        }, 0)
    }
}
