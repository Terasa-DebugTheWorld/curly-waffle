import { Http } from "../../3rd/Http";
import { Glb } from "../../Glb";
import UserData from "../../userdata/UserData";
import { Util } from "../../utils/Util";


const SDK_ENABLE = true;
const USE_XG_LOGIN = false;
const USE_DAOCHU = false;
export const nSdk = new class {
    isInit = false;
    openid = '';
    gameid = '';
    config = {};
    async init(gameid) {
        if (!SDK_ENABLE) {
            this.gameid = gameid;
            this.isInit = true;
            this.openid = '1';
            this.config = {
                ban_code_ver: Glb.version,
                "status": "1",
                "level": "1",
                "rmbOn": "1",
                "passRmbOn": "1",
                "videoIconOn": "1",
                "rmbVideoIconOn": "1",
                "insertCd": "35",
                "insert_ui_open": "0.8",
                "insert_ui_close": "0.8",
                "insert_new_stage": "0.65",
                "insert_pass_reward": "0.65",
                "bannerRefreshDelay": "145",
                "cycle": "7200",
                "dcgm": "1",
                "sharegm": "1",
                "userexchange": "2",
                "CustomAdRefresh": "60",
                "bannerclick": "0",
                "boxclick": "0",
                "gmbx": "6",
                "interstitialAdoutpost": "3",
                "cashbonus": "1",
                "gmbxlv": "6",
                "interstitialAdlv": "2",
                "cashamount0.3": "1",
                "interstitialAdTwoWaitTime": "0.7,2",
                "adLoopPlayNum_Red": "15",
                "share_1": " 99%的人都不知道答案#https://cdn-res.nagagame.net/gameid/sharepic/cy1.png",
                "share_2": " 99%的人都不知道答案#https://cdn-res.nagagame.net/gameid/sharepic/cy1.png",
                "Sharetime": "3.5",
                "Sharetips": "分享出错啦！再试试发给其他群吧:25,分享奖励获取失败，请再试试其他群哦~:25,失败啦，请分享至大于30人的群:50",
                "sharepoint": "202|201|202|202|202|201:50,101|202|101|202|101|202:50",
                "codeVer": "1.4000"
            }
            return false;
        }
        this.gameid = gameid;
        let promiseall = [];
        promiseall.push(this.remoteConfig());
        if (USE_DAOCHU) this.remoteDaochu();
        if (UserData.get('openid')) {
            this.openid = UserData.get('openid');
        } else {
            if (cc.sys.isBrowser) {
                this.openid = UserData.set('openid', Date.now());
            } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                if (!USE_XG_LOGIN) {
                    // this.getWxCode().then(() => {
                    //     this._openidResolve.forEach(r => {
                    //         r();
                    //     })
                    //     console.log('openid:', this.openid);
                    // });
                }
            }
        }
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            if (USE_XG_LOGIN) {
                let p = new Promise((resolve, reject) => {
                    XunguangSDK.init((openid) => {
                        if (openid) this.openid = UserData.set('openid', openid);
                        resolve(null);
                        this._openidResolve.forEach(r => {
                            r();
                        })
                        console.log('openid:', this.openid);
                    })
                })
                // promiseall.push(p);
            }
        }
        console.log('openid:', this.openid);
        await Promise.all(promiseall);
        this.isInit = true;
        this._configResolve.forEach(r => {
            r();
        })
    }

    private remoteConfig() {
        let get = (resolve) => {
            Http.request(`https://cdn-res.nagagame.net/gameid/${this.gameid}.json?a=` + Date.now(), (body) => {
                this.config = JSON.parse(body);
                this.config['shares'] = [];
                for (let k in this.config) {
                    if (k.indexOf('share_') == 0) {
                        let rest = k.slice(6);
                        try {
                            let i = parseInt(rest);
                            if (i) {
                                let arr = this.config[k].split('#');
                                this.config['shares'].push({ imageUrl: arr[1], title: arr[0] })
                            }
                        } catch (error) {

                        }
                    }
                }
                console.log(this.config);
                resolve(body)
            }, () => {
                setTimeout(() => {
                    get(resolve);
                }, 1000)
            })
        }
        return new Promise((resolve, reject) => {
            get(resolve);
        })
    }

    daochu = [];
    private remoteDaochu() {
        Http.request(`https://cdn-res.nagagame.net/gameid/daochu.json?a=` + Date.now(), (body) => {
            let obj = JSON.parse(body);
            if (obj[this.gameid]) {
                let arr = obj[this.gameid].split(',');
                arr.forEach(a => {
                    if (obj.all[a]) {
                        obj.all[a].gameid = a;
                        this.daochu.push(obj.all[a])
                    }
                });
            }
            cc.log('导出:', this.daochu);
        }, () => {
            setTimeout(() => {
                this.remoteDaochu();
            }, 5000)
        })
    }

    private getWxCode() {
        const login = (resolve) => {
            wx.login({
                success: async (res) => {
                    if (res.code) {
                        //发起网络请求
                        let rlt = await Http.requestAsync(`https://minigame.nagagame.net/users/getOpenId?gameid=${this.gameid}&code=${res.code}`)
                        rlt = JSON.parse(rlt);
                        this.openid = UserData.set('openid', rlt.data.openid);
                        resolve(res.code)
                    } else {
                        console.log('登录失败！')
                        setTimeout(() => {
                            login(resolve);
                        }, 1000)
                    }
                }
            })
        }
        return new Promise((resolve, reject) => {
            login(resolve);
        })
    }

    _configResolve = [];
    public waitInit() {
        return new Promise((resolve, reject) => {
            if (this.isInit) {
                resolve(null);
            } else {
                this._configResolve.push(resolve);
            }
        })
    }

    _openidResolve = [];
    public waitOpenid() {
        return new Promise((resolve, reject) => {
            if (this.openid) {
                resolve(null);
            } else {
                this._openidResolve.push(resolve);
            }
        })
    }

    public getConfig(key) {
        if (Object.keys(this.config).length == 0) {
            cc.error('还没获取到配置')
            return '';
        }
        return this.config[key];
    }

    _clickRecord;
    public getAdClickRecord() {
        if (this._clickRecord) return this._clickRecord.list;
        let dataStr = cc.sys.localStorage.getItem('nAdClick');
        if (dataStr) {
            let obj = JSON.parse(dataStr);
            if (this.makeDateStr(obj.time) != this.makeDateStr()) {
                obj.list = [];
                obj.time = Date.now();
            }
            this._clickRecord = obj;
        } else {
            this._clickRecord = { list: [], time: Date.now() }
        }
        cc.sys.localStorage.setItem('nAdClick', JSON.stringify(this._clickRecord));
        return this._clickRecord.list;
    }

    public setAdClick(gameid) {
        this.getAdClickRecord();
        this._clickRecord.list.push(gameid);
        cc.sys.localStorage.setItem('nAdClick', JSON.stringify(this._clickRecord));
        Http.request(`https://minigame.nagagame.net/log/gamePush?fromGid=${this.gameid}&toGid=${gameid}`, null, null)
    }

    makeDateStr(time = null) {
        var d = null;
        if (time) d = new Date(time);
        else d = new Date();
        var gd = d.getDate();
        var day = gd < 10 ? '0' + gd : gd;
        var gm = d.getMonth() + 1;
        var month = gm < 10 ? '0' + gm : gm;
        return '' + d.getFullYear() + month + day;
    }

    isAudit() {
        return Glb.version == this.getConfig('ban_code_ver');
    }

    share() {
        wx.shareAppMessage(this.getShareInfo());
    }
    getShareInfo(): { title: string, imageUrl: string } {
        let s = this.getConfig('shares');
        let info = null;
        if (!s || s.length == 0) {
            console.log('use wx screen shot', cc.game.canvas.toTempFilePathSync);
            const image = cc.game.canvas.toTempFilePathSync({
                destWidth: 720,
                destHeight: 1280
            });
            info = { title: '消他', imageUrl: image }
        }

        let rand = Util.getRandom(0, s.length)
        return s[rand];
    }
};

if (cc.sys.isBrowser) window['nSdk'] = nSdk;