import { System } from "./System";

var DIR = cc.Enum({
    顶部: 0,
    底部: 1,
    左: 2,
    右: 3
});
const { ccclass, property } = cc._decorator;
@ccclass
export default class ScreenAdapter extends cc.Component{
    @property({type:DIR})
    dir = DIR.顶部

    _widget:cc.Widget = null;
    onEnable() {
        this._widget = this.getComponent(cc.Widget);
        if (this._widget && !System.isInDesignSize()) {
            switch (this.dir) {
                case DIR.顶部:
                    this._widget.isAbsoluteTop = false;
                    this._widget.top = 0.032;
                    break;
                case DIR.底部:
                    this._widget.isAbsoluteBottom = false;
                    this._widget.bottom = 0.027;
                    break;
                default:
                    break;
            }   
        }
    }
}