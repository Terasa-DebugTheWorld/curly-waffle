import { Util } from "../utils/Util";

var _PATH = 'jsons'

export default class DataFunc {
    public static config = {}
    public static audios = {}

    public static loadConfigAsync() {
        return new Promise((resolve, reject) => {
            DataFunc.loadConfig(null, resolve);
        })
    }

    public static loadConfig(progressCb, callback) {

        cc.loader.loadResDir(_PATH, function (completedCount, totalCount) {
            if (progressCb) {
                progressCb(completedCount, totalCount);
            }
        }, function (err, content, urls) {
            if (err) {
                cc.error(err.message || err);
                return;
            }
            for (var i = 0; i < content.length; i++) {
                DataFunc.config[content[i].name] = content[i].json;
            }
            DataFunc.adjustConfig();
            if (callback) callback();
        });
    }
    public static loadArtRes() {

    }
    public static adjustConfig() {
        //调整配置表格

    }

    //--具体数据接口
    public static getConfig(cname) {
        return DataFunc.config[cname];
    }
    public static getBaseConfig(key) {
        return DataFunc.getLikeBase('base', key);
    }
    public static getLikeBase(cname, key) {
        const table = this.getConfig(cname);
        const config = table[key];
        if (!config) {
            cc.error(`找不到${cname}这个配置：${key}`);
            return;
        }
        if (void 0 != config.number) {
            return config.number;
        } else if (void 0 != config.string) {
            return config.string;
        } else if (void 0 != config.object) {
            return config.object;
        }
        cc.error(`配置解析失败:`, cname, key, config)
        return null;
    }

    public static query(cname, index) {
        if (!(cname in DataFunc.config)) {
            cc.log('找不到这个配置表:', cname);
            return null;
        } else if (DataFunc.config[cname][index] == undefined) {
            cc.log('找不到这个配置项目:', cname, index);
            return null;
        }

        return Util.copyObj(DataFunc.config[cname][index]);
    }
    public static getConfigMax(cname) {
        let c = DataFunc.config[cname]
        if (!c) return null;
        let keys = Object.keys(c);
        let length = keys.length;
        let max = keys[keys.length - 1]
        return { length: length, max: max, item: c[max] }
    }
    public static toMap(json, mainKey, itemKey) {
        let ret = {};
        for (let k in json) {
            let item = json[k];
            if (!ret[item[mainKey]]) ret[item[mainKey]] = {};
            ret[item[mainKey]][item[itemKey]] = item;
        }
        return ret;
    }
    public static toMapTwoKey(json, mainKey, subKey, itemKey) {
        let ret = {};
        for (let k in json) {
            let item = json[k];
            if (!ret[item[mainKey]]) ret[item[mainKey]] = {};
            if (!ret[item[mainKey]][item[subKey]]) ret[item[mainKey]][item[subKey]] = {};
            ret[item[mainKey]][item[subKey]][item[itemKey]] = item;
        }
        return ret;
    }
};

window["DataFunc"] = DataFunc;