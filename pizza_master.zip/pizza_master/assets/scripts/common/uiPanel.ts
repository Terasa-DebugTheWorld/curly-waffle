import { ClientEvent } from "./ClientEvent";
import uiFunc from "./uiFunc";

var PanelAnimation = cc.Enum({
    None: -1,
    ScaleOpen: 1,
});

const { ccclass, property } = cc._decorator;
@ccclass
export default class uiPanel extends cc.Component {
    @property({ type: PanelAnimation })
    showAnimation = PanelAnimation.None
    @property({ type: PanelAnimation })
    hideAnimation = PanelAnimation.None
    @property()
    isUseMask = true

    @property({
        visible: (function () {
            return this.isUseMask;
        })
    })
    closeByClickOutside = false;
    @property({
        type: cc.Node,
        visible: (function () {
            return this.closeByClickOutside;
        })
    })
    contentNode: cc.Node = null;
    @property
    enterSound = ''
    @property
    closeSound = ''

    private nodeDict = {}
    private _oldScale = 0;
    private anim: cc.Animation
    onLoad() {
        // this.node.group = 'ui'
        // node load --
        // this.nodeDict = {};

        // var linkWidget = function(self, nodeDict) {
        //     var children = self.children;
        //     for (var i = 0; i < children.length; i++) {
        //         var widgetName = children[i].name;
        //         if (widgetName && widgetName.indexOf("key_") >= 0) {
        //             var nodeName = widgetName.substring(4);
        //             if (nodeDict[nodeName]) {
        //                 cc.error("控件名字重复!" + children[i].name);
        //             }
        //             nodeDict[nodeName] = children[i];
        //         }
        //         if (children[i].childrenCount > 0) {
        //             linkWidget(children[i], nodeDict);
        //         }
        //     }
        // }.bind(this);
        // linkWidget(this.node, this.nodeDict);

        // 添加动画--
        if (this['panelLoad']) this['panelLoad']();
        // this.closeByClickOutside = false;
        if (this.closeByClickOutside) {
            let closeNode = new cc.Node();
            closeNode.setContentSize(cc.size(800, 2000));
            closeNode.parent = this.node;
            closeNode.zIndex = -100;
            let closeBtn = closeNode.addComponent(cc.Button);
            var clickEventHandler = new cc.Component.EventHandler();
            clickEventHandler.target = this.node;
            clickEventHandler.component = "uiPanel";
            clickEventHandler.handler = "quit";
            closeBtn.clickEvents.push(clickEventHandler);

            let blockNode = new cc.Node();
            let blockSize = this.node.getContentSize();
            let blockPos = this.node.getPosition();
            if (this.contentNode) {
                blockSize = this.contentNode.getContentSize();
                blockPos = this.contentNode.getPosition();
            }
            blockNode.setPosition(blockPos);
            blockNode.setContentSize(blockSize);
            blockNode.parent = this.node;
            blockNode.zIndex = -99;
            blockNode.addComponent(cc.Button);
        }
    }

    async show() {
        switch (this.showAnimation) {
            case PanelAnimation.ScaleOpen:
                var clipName = PanelAnimation[this.showAnimation];
                // console.log('加载打开动画:', clipName, this.showAnimation);
                // this.anim.addClip(DataFunc.panelAnims[clipName]);
                // this.anim.play(clipName);
                if (!this._oldScale) this._oldScale = this.node.scale;
                cc.tween(this.node)
                    .set({
                        scale: 0.4
                    })
                    // .to(0.3, {
                    //     scale: this._oldScale
                    // }, { easing: 'backOut' })
                    .to(0.08, { scale: this._oldScale * 1.05 })
                    .to(0.04, { scale: this._oldScale })
                    .call(() => {
                        this.onShow();
                    })
                    .start();
                break;

            default:
                //动画为None时：
                if (!this.node.active) this.node.active = true;
                this.onShow();
        }
    }

    showCompleted() {
        // console.log(this.node.name + "动画播放完毕～");
    }

    hide(callback) {
        // 解除事件绑定--
        ClientEvent.clear(this);
        switch (this.hideAnimation) {
            case PanelAnimation.ScaleOpen:
                cc.tween(this.node)
                    .to(0.3, {
                        scale: 0
                    }, { easing: 'backIn' })
                    .set({ active: false, scale: 1 })
                    .call(() => {
                        this.onHide();
                        if (callback) callback();
                    })
                    .start();
                break;
            default:
                //动画为None时：
                this.node.active = false;
                if (callback) callback();
                this.onHide();
        }
    }

    onShow() {

    }
    onHide() {

    }

    onFreeze() {

    }

    setData(data: any) {

    }

    onDestroy() {
        if (this.anim) {
            this.anim.off('finished', this.showCompleted, this);
        }
    }

    quit() {
        uiFunc.close(this.node.name);
    }

    quitAndDestory() {
        uiFunc.close(this.node.name, true);
    }
};