import { System } from "./System";

const { ccclass, property } = cc._decorator;

@ccclass
export default class IPadAdapter extends cc.Component {

    onLoad () {
        this.mask = this.getComponent(cc.Mask);
        if (!this.mask) cc.error('请向Canvas添加遮罩');
        if(this.mask) this.mask.enabled = System.isPad()
        if(System.isPad()){
            this.getComponent(cc.Canvas).fitHeight = true;
            this.getComponent(cc.Canvas).fitWidth = true;
        }
    }
    mask: cc.Mask
    // start() {

    // }

    // update (dt) {}
}
