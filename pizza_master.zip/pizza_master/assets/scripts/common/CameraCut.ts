import { System } from "./System";


const PADDING = 10;
const Fps = 1 / 10;
let total = 0;

const { ccclass, property } = cc._decorator;
@ccclass
export default class CameraCut extends cc.Component {

    _delayUpdate = 0
    _isHide = false

    public static isInCamera(node) {
        let cam = cc.Camera.main;
        let vs = System.getVisibleSize();
        let nodeWp = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let cp = cam.getWorldToScreenPoint(nodeWp);
        let w = node.width / 2;
        let h = node.height / 2;
        if (cp.x < -PADDING - w
            || cp.x > vs.width + w + PADDING
            || cp.y < -PADDING - h
            || cp.y > vs.height + h + PADDING) {
            return false;
        } else {
            return true;
        }
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {
        // this._cam = cc.Camera.main;
        // this._vs = System.getVisibleSize();
        // let nodeWp = this.node.convertToWorldSpaceAR(cc.v2(0,0));
        // cc.error(this._cam.getWorldToScreenPoint(nodeWp))
        this._isHide = this.node.opacity == 0;
        // cc.log(++total)
    }

    update(dt) {
        this._delayUpdate += dt;
        if (this._delayUpdate < Fps) {
            return;
        }

        this._delayUpdate = 0;
        if (CameraCut.isInCamera(this.node)) {
            if (!this._isHide) {
                return;
            }

            this._isHide = false;
            this.node.opacity = 255;
        } else {
            if (this._isHide) {
                return;
            }

            this._isHide = true;
            this.node.opacity = 0;
        }
    }
}
