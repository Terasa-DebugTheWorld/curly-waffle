export default class SimpleStack {
    arr = [];
    top = 0;
    constructor() {

    }

    push(item) {
        return (this.arr[this.top++] = item);
    }

    pop() {
        return this.arr.splice(--this.top, 1)
    }

    peek() {
        return this.arr[this.top - 1];
    }

    //当元素不是对象时
    delete(item) {
        for (let i = this.arr.length - 1; i >= 0; i--) {
            if (this.arr[i] == item) {
                this.arr.splice(i, 1);
                this.top--;
                return true;
            }
        }
        return false;
    }

    delteObj(key, value) {
        for (let i = this.arr.length - 1; i >= 0; i--) {
            if (this.arr[i][key] == value) {
                this.arr.splice(i, 1);
                this.top--;
                return true;
            }
        }
        return false;
    }

    get size() {
        return this.top;
    }

    clear() {
        this.top = 0;
        this.arr = [];
    }

}