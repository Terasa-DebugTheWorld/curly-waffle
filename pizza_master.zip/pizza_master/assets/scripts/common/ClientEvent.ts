import EventListener from "./EventListener";

export const ClientEvent = {
    eventType: {
        openUI: "openUI",
        closeUI: "closeUI",

        //---
    },
    eventListener: new EventListener(),
    on(eventName, handler, target?) {
        if (typeof eventName !== "string") {
            return;
        }
        ClientEvent.eventListener.on(eventName, handler, target);
    },
    off(eventName, handler, target?) {
        if (typeof eventName !== "string") {
            return;
        }
        ClientEvent.eventListener.off(eventName, handler, target);
    },
    clear(target) {
        ClientEvent.eventListener.clear(target);
    },
    dispatch(eventName, data?: any) {
        if (typeof eventName !== "string") {
            return;
        }
        ClientEvent.eventListener.dispatch(eventName, data);
    },
    once(eventName, handler, target?) {
        if (typeof eventName !== "string") return;

        ClientEvent.eventListener.on(eventName, handler, target, true);
    }
}
