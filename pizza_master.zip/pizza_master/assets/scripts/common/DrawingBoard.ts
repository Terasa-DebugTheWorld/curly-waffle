export default class DrawingBoard {
    private _witdh: number;
    /**画板宽度 */
    public get width(): number { return this._witdh; }
    private _height: number;
    /**画板高度 */
    public get height(): number { return this._height; }

    /**存储像素数据的内存块 */
    private buffer: ArrayBuffer;
    /**颜色分量一维数组，供渲染使用 */
    private pixelColor: Uint8Array;

    /**记录最近一次绘制像素的颜色(十六进制颜色值)，调用绘制函数且未指定颜色值时，将使用该值 */
    private curColor: number;

    /**
    * 可对每个像素点绘制的画板，画板使用的坐标系原点为左下角，X轴向右为正，Y轴向上为正
    */
    public constructor(width: number, height: number, data?: Uint8Array) {
        this.init(width, height, data);
    }
    /**
    * 对画板进行初始化，会清空已绘制的所有内容
    */
    public init(width: number, height: number, data?: Uint8Array) {
        this.curColor = 0;
        this._witdh = Math.round(width);
        this._height = Math.round(height);
        this.initPixelColor();
        if (!!data) {
            this.setData(data);
        }
    }
    private initPixelColor() {
        this.buffer = new ArrayBuffer(this.width * this.height * 4);
        this.pixelColor = new Uint8Array(this.buffer);
        this.pixelColor.fill(0);
    }
    public setData(data: Uint8Array) {
        if (data.byteLength != this.width * this.height * 4) return;
        this.pixelColor = new Uint8Array(data);
    }
    public getData(): Uint8Array {
        return this.pixelColor;
    }

    public setColor(color: cc.Color | string) {
        if (typeof color == "string") {
            color = cc.color().fromHEX(color);
        }
        this.curColor = this.convertToNumber(color.r, color.g, color.b, color.a);
    }

    /**绘制一个像素点的颜色 */
    public drawPixel(x: number, y: number, color?: cc.Color) {
        const rgba = color || this.convertToRGBA(this.curColor);
        if (this.getPointColor(x, y) == this.convertToNumber(rgba.r, rgba.g, rgba.b, rgba.a)) return;
        const idx = this.calcIndex(x, y);
        this.pixelColor[idx] += rgba.r;
        this.pixelColor[idx + 1] = rgba.g;
        this.pixelColor[idx + 2] = rgba.b;
        this.pixelColor[idx + 3] = rgba.a;
    }
    //在一个像素点上叠加颜色
    public mixPixel(x: number, y: number, color?: cc.Color) {
        const idx = this.calcIndex(x, y);
        const rgba = color || this.convertToRGBA(this.curColor);
        this.pixelColor[idx] += rgba.r;
        this.pixelColor[idx + 1] += rgba.g;
        this.pixelColor[idx + 2] += rgba.b;
        this.pixelColor[idx + 3] += rgba.a;
    }

    public line(x1: number, x2: number) {
        for (let m = x1; m < x2; m++) {
            for (let y = 10; y <= 60; y++) {
                this.drawPixel(m, y);
            }
        }
    }

    public circleStroke(x: number, y: number, r: number) {
        for (let m = this.clampX(Math.round(x - r)); m <= this.clampX(Math.round(x + r)); m++) {
            const k = Math.sqrt(r * r - Math.pow(m - x, 2));
            const min = Math.round(y - k);
            const max = Math.round(y + k)
            if (min >= 0 && min < this.height) this.drawPixel(m, min);
            if (max >= 0 && max < this.height) this.drawPixel(m, max);
        }
    }
    public circleFill(x: number, y: number, r: number) {
        for (let m = this.clampX(Math.round(x - r)); m <= this.clampX(Math.round(x + r)); m++) {
            const k = Math.sqrt(r * r - Math.pow(m - x, 2));
            for (let n = this.clampY(Math.round(y - k)); n <= this.clampY(Math.round(y + k)); n++) {
                this.drawPixel(m, n);
            }
        }
    }

    public clear() {
        this.pixelColor.fill(0);
    }

    private calcVec(index: number): cc.Vec2 {
        index = Math.floor(index / 4);
        return cc.v2(this.clampX(index % this.width), this.clampY(Math.floor(index / this.width)));
    }
    private calcIndex(x: number, y: number): number {
        return (this.height - this.clampY(y)) * this.width * 4 + this.clampX(x) * 4;
    }
    public clampX(x: number): number {
        return Math.min(this.width - 1, Math.max(0, Math.round(x)));
    }
    public clampY(y: number): number {
        return Math.min(this.height - 1, Math.max(0, Math.round(y)));
    }

    public getPointColor(x: number, y: number): number {
        const idx = this.calcIndex(x, y);
        const rgba = this.pixelColor.slice(idx, idx + 4);
        return this.convertToNumber(rgba[0], rgba[1], rgba[2], rgba[3]);
    }

    /**将RGBA颜色分量转换为一个数值表示的颜色，颜色分量为0~255之间的值 */
    private convertToNumber(r: number, g: number, b: number, a: number = 255): number {
        return (r << 23) * 2 + (g << 16) + (b << 8) + a;
    }
    /**将十六进制的颜色转换为RGBA分量表示的颜色 */
    private convertToRGBA(color: number): { r: number, g: number, b: number, a: number } {
        return {
            r: Math.floor(color / 0x1000000),
            g: (color & 0x00ff0000) >> 16,
            b: (color & 0x0000ff00) >> 8,
            a: (color & 0x000000ff),
        };
    }
}