import { WxSubpackageLoader } from "../3rd/WxSubpackageLoader";

var _CHANNEL = 4;
var _PATH = "audios/";
var _USE_BUNDLE = true;
const BGM_VOLUM = 0.6;
export enum AudioTag {
    none = 0,
    miniGame = 1,
    train = 2,
    vip = 3,
    hall = 101,
    bath = 102,
}
export const AudioHelper = new class {
    public _audios = {}
    public _timeList = {}
    public _channel = 0
    public _channelList = {}
    public _effectSwitch = true
    public _bgmSwitch = true
    public isPlayingBgm = false;
    public _bgmId = 0;
    private _bgmVolum = BGM_VOLUM;
    public list = {
    }
    public loadRes(progressFunc, callback) {
        if (_USE_BUNDLE) {
            let bundle = WxSubpackageLoader.getBundle("audios");
            if (!bundle) {
                cc.error("audios subpackgae not loaded!");
                return;
            }
            bundle.loadDir("/", (err, assets) => {
                if (err) {
                    cc.error(err.message || err);
                    return;
                }
                for (var i = 0; i < assets.length; i++) {
                    this._audios[assets[i].name] = assets[i];
                }
                if (callback) callback();
            });
        } else {
            cc.resources.loadDir(_PATH, cc.AudioClip, function (completedCount, totalCount) {
                if (progressFunc) {
                    progressFunc(completedCount, totalCount);
                }
            }, (err, clips) => {
                if (err) {
                    cc.error(err.message || err);
                    return;
                }
                // cc.log(clips)
                for (var i = 0; i < clips.length; i++) {
                    this._audios[clips[i].name] = clips[i];
                }
                if (callback) callback();
            });
        }

        this.reloadSwitch();
        cc.game.on(cc.game.EVENT_SHOW, () => this._bgmSwitch && cc.audioEngine.resume(this._bgmId), this);
    }

    private lastTag: AudioTag = AudioTag.hall
    private curTag: AudioTag = AudioTag.hall
    public setTag(tag: AudioTag) {
        if (tag && this.curTag != tag) {
            this.pauseAllByTag(this.curTag);
            this.resumeAllByTag(tag);
            const lt = this.curTag;
            this.curTag = tag;
            this.lastTag = lt;
        }
    }
    public leaveTag() {
        this.setTag(this.lastTag);
    }
    public getTag(): AudioTag {
        return this.curTag;
    }
    public pauseAllByTag(tag: AudioTag) {
        if (tag && this.effectMap[tag]) {
            this.effectMap[tag].forEach(i => {
                cc.audioEngine.setVolume(Number(i), 0);
            });
        }
    }
    public resumeAllByTag(tag: AudioTag) {
        if (!this.getSwith()) return;
        if (tag && this.effectMap[tag]) {
            this.effectMap[tag].forEach(i => {
                cc.audioEngine.setVolume(Number(i), 1);
            });
        }
    }

    private effectMap: { [tag in AudioTag]?: number[] } = {}
    public playEffect(key: string, loop = false, tag: AudioTag = AudioTag.none): number {
        if (!this._effectSwitch && loop == false) {
            return;
        }
        if (!this._audios[key]) {
            cc.error(`no this audio:${key}`);
            return;
        }
        let vol = 1;
        if (!this._effectSwitch) vol = 0;

        const id = cc.audioEngine.play(this._audios[key], loop, vol);
        // cc.log('音效播放：' + key);
        if (!this.effectMap[tag]) {
            this.effectMap[tag] = [];
        }
        this.effectMap[tag].push(id);
        cc.audioEngine.setFinishCallback(id, this.delEffect.bind(this, tag, id));
        if (tag && tag != this.curTag) {
            cc.audioEngine.setVolume(id, 0);
        }
        return id;
    }
    private delEffect(tag: AudioTag, id: number) {
        const idx = this.effectMap[tag].indexOf(id);
        if (idx >= 0) {
            this.effectMap[tag].splice(idx, 1);
        }
    }

    public stopEffect(audioID) {
        cc.audioEngine.stop(audioID);
    }

    public pauseEffect(audioID) {
        cc.audioEngine.pause(audioID);
    }

    public resumeEffect(audioID) {
        cc.audioEngine.resume(audioID);
    }

    public playEffectLimit(key, limitTime = 100, loop = false, vol = 1) {
        if (!this._effectSwitch) {
            return;
        }

        if (false /*cc.sys.platform == cc.sys.WECHAT_GAME && cc.sys.os == cc.sys.OS_ANDROID*/) {
            this._playEffectLimitChannel(key, limitTime, loop, vol)
        } else {
            let now = Date.now();
            let ex = this._timeList[key];
            if (ex == undefined || (ex > 0 && now - ex > limitTime)) {
                this.playEffect(key, loop, vol);
                this._timeList[key] = now;
            }
        }
    }

    public _playEffectLimitChannel(key, limitTime = 100, loop = false, vol = 1) {
        if (!this._effectSwitch) {
            return;
        }

        let now = new Date().getTime();
        let ex = this._timeList[key];
        if (ex == undefined || (ex > 0 && now - ex > limitTime)) {
            if (this._channel > _CHANNEL) {
                return;
            }
            this._channel++;
            let id = this.playEffect(key, loop, vol);
            this._timeList[key] = now;
            cc.audioEngine.setFinishCallback(id, () => {
                this._channel--;
            });
        }
    }

    public playBgm(key, tag: AudioTag = AudioTag.none) {
        // if (!this._bgmSwitch) {
        //     return;
        // }

        if (this.isPlayingBgm == true) return;
        this.isPlayingBgm = true;
        if (this._bgmSwitch) {
            cc.audioEngine.setMusicVolume(BGM_VOLUM);
        } else {
            cc.audioEngine.setMusicVolume(0);
        }
        this._bgmVolum = cc.audioEngine.getMusicVolume();
        if (!this._audios[key]) return;
        this._bgmId = cc.audioEngine.playMusic(this._audios[key], true)
    }

    public stopBgm() {
        // if (!this._bgmSwitch) {
        //     return;
        // }

        this.isPlayingBgm = false;
        cc.audioEngine.stopMusic();
        this._bgmId = null;
    }

    private set bgmVol(vol: number) {
        cc.audioEngine.setMusicVolume(vol);
    }
    private get bgmVol(): number {
        return cc.audioEngine.getMusicVolume();
    }
    private bgmTween: cc.Tween
    public bgmFadeOut(t: number): Promise<void> {
        if (this.bgmTween) this.bgmTween.stop();
        return new Promise(res => {
            this.bgmTween = cc.tween(this)
                .to(t, { bgmVol: 0 } as any)
                .call(() => {
                    this.stopBgm();
                    this.bgmVol = BGM_VOLUM;
                    res();
                })
                .start();
        });
    }

    public setMusicVolume(scale) {
        cc.audioEngine.setMusicVolume(BGM_VOLUM * scale);
    }


    public pauseBgm() {
        // if (this._bgmId != undefined || this._bgmId != null)
        //     cc.audioEngine.pause(this._bgmId);
        cc.audioEngine.setMusicVolume(0);
    }

    public resumeBgm() {
        // if (this._bgmId != undefined || this._bgmId != null) {
        //     cc.audioEngine.resume(this._bgmId);
        // } else {
        //     this.playBgm(this.list.bgm);
        // }
        cc.audioEngine.setMusicVolume(this._bgmVolum);
    }

    public setBgmSwitch = (on, record = true) => {
        if (this._bgmSwitch == on) return;
        if (on) {
            //this._bgmSwitch = on;
            //this.resumeBgm();
            cc.audioEngine.setMusicVolume(BGM_VOLUM);
            this._bgmVolum = BGM_VOLUM;
        } else {
            //this.pauseBgm();
            cc.audioEngine.setMusicVolume(0);
            this._bgmVolum = 0;
        }
        this._bgmSwitch = on;
        if (record == true) {
            cc.sys.localStorage.setItem('bgmSwitch', on);
        }
    }

    public setEffectSwitch(on: boolean, record = true) {
        if (this._effectSwitch == on) return;
        this._effectSwitch = on;
        if (on) {
            // cc.audioEngine.setEffectsVolume(1);
            this.talkTag(AudioTag.none);
            this.talkTag(this.curTag);
        } else {
            // cc.audioEngine.setEffectsVolume(0);
            this.shutUpTag(AudioTag.none);
            this.shutUpTag(this.curTag);
        }
        if (record == true) {
            cc.sys.localStorage.setItem('effectSwitch', on);
        }
    }
    private shutUpTag(tag: AudioTag) {
        if (this.effectMap[tag]) {
            this.effectMap[tag].forEach(this.shutUp);
        }
    }
    private shutUp(id: number) {
        cc.audioEngine.setVolume(id, 0);
    }
    private talkTag(tag: AudioTag) {
        if (this.effectMap[tag]) {
            this.effectMap[tag].forEach(this.talk);
        }
    }
    private talk(id: number) {
        cc.audioEngine.setVolume(id, 1);
    }

    public setSwitch(on, record = true) {
        this.setBgmSwitch(on, record);
        this.setEffectSwitch(on, record);
    }

    public getBgmSwitch() {
        return this._bgmSwitch;
    }

    public getEffectSwitch() {
        return this._effectSwitch;
    }

    public getSwith() {
        return this._bgmSwitch;
    }

    public reloadSwitch() {
        let bgmSwitch = cc.sys.localStorage.getItem('bgmSwitch');
        this._bgmSwitch = (bgmSwitch == 'false' || bgmSwitch === false) ? false : true;
        let effectSwitch = cc.sys.localStorage.getItem('effectSwitch');
        this._effectSwitch = (effectSwitch == 'false' || effectSwitch === false) ? false : true;
    }

    //播完之后state可能是error
    public isAudioStoped(id: number): boolean {
        const state = cc.audioEngine.getState(id);
        return state == cc.audioEngine.AudioState.STOPPED;
    }
    public isAudioPlaying(id: number): boolean {
        const state = cc.audioEngine.getState(id);
        return state == cc.audioEngine.AudioState.PLAYING;
    }
}

window['AudioHelper'] = AudioHelper;
