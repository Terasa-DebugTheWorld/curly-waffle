export const DynamicResLoad = new class {
    resMap = {}
    public loadRes<T extends typeof cc.Asset>(url: string, type: T): Promise<InstanceType<T>> {
        if (this.resMap[url]) {
            return Promise.resolve(this.resMap[url]);
        }
        return new Promise((resl, reje) => {
            cc.assetManager.resources.load(url, type, null, (err, asset) => {
                if (err) {
                    console.error(err);
                }
                this.resMap[url] = asset;
                //@ts-ignore
                resl(asset);
            });
        });
    }
    /**
     * 
     * @param url 最后一个斜杠可有可无
     * @param type 
     * @returns path 是从resources文件夹到资源的完整路径
     */
    public getResInfo(url: string, type: typeof cc.Asset): { uuid: string, path: string }[] {
        return cc.resources.getDirWithPath(url, type) as any;
    }
}