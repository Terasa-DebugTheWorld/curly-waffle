
export const Vibrate = {
    _switch: true,
    _lastVibrate: 0,
    _interval: 100,//ms
    /**
     * 
     * @param power ios有1，2，3档
     */
    vibrate(power?) {
        if (!this.getSwitch()) {
            return;
        }

        let time = 20;//ms
        let now = Date.now();
        if (now - this._lastVibrate > this._interval) {
            this._lastVibrate = now;
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                wx.vibrateShort(null);
            } else if (cc.sys.platform == cc.sys.ANDROID) {
                jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "vibrate", "(I)V", time);
            } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
                power = power || 1;
                jsb.reflection.callStaticMethod("Utils", "vibrate:", power);
            } else {
                cc.log('vibrate')
            }
        }

    },
    longVibrate() {
        if (!this._switch) {
            return;
        }

        let time = 80;//ms
        let now = Date.now();
        if (now - this._lastVibrate > this._interval) {
            this._lastVibrate = now;
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {

            } else if (cc.sys.platform == cc.sys.ANDROID) {
                jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "vibrate", "(I)V", time);
            } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
                jsb.reflection.callStaticMethod("Utils", "vibrate");
            }
        }
    },
    setOn() {
        if (this._switch) return;
        this._switch = true;
        cc.sys.localStorage.setItem('_vibrate', true);
    },
    setOff() {
        if (!this._switch) return;
        this._switch = false;
        cc.sys.localStorage.setItem('_vibrate', false);
    },
    getSwitch() {
        if (!this._init) {
            this._init = true;
            let vibrateSwitch = cc.sys.localStorage.getItem('_vibrate') || true;
            this._switch = vibrateSwitch == 'false' ? false : true;
        }
        return this._switch;
    },
};