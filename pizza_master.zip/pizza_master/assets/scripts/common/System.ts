export const System = {
    _designSize: cc.size(720, 1280),
    getDesignSize() {
        return this._designSize;
    },
    isInDesignSize() {
        let dhw = this._designSize.height / this._designSize.width;
        let vs = this.getVisibleSize();
        let vhw = vs.height / vs.width;
        if (vhw > 2) {
            return false;
        }
        return true;
    },
    isPad() {
        let vs = this.getFrameSize();
        let vhw = vs.height / vs.width;
        // cc.log(vs,vhw)
        if (vhw < 1.6 && vhw > 1 / 1.6) {
            return true;
        }
        return false;
    },
    getVisibleSize() {
        return cc.view.getVisibleSize();
    },
    getVisibleHeight() {
        //获取游戏分辨率高度
        return cc.view.getVisibleSize().height;
    },
    getVisibleWidth() {
        //获取游戏分辨率宽度
        return cc.view.getVisibleSize().width;
    },

    getFrameSize() {
        return cc.view.getFrameSize();
    },

    getWxSystemInfo() {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            return wx.getSystemInfoSync();
        }

        return null;
    }
};