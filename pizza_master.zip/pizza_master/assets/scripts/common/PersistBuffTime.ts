import CallbackHelper from "./CallbackHelper";

//时间统一,秒
export default class PersistBuffTime {
    _recordTime = 0
    _pause = false
    _isOn = false
    _cb = new CallbackHelper();
    _isIncrease = true
    _tag = "";
    _lastedTime = 0;
    constructor(lastedTime) {
        this.setLastedTime(lastedTime);
    }
    setTag(tag) {
        this._tag = tag;
    }
    getTag() {
        return this._tag;
    }
    setReduce() {
        this._isIncrease = false;
    }
    setCallBack(handler, target) {
        this._cb.setCallback(handler, target);
    }
    setLastedTime(lastedTime) {
        this._lastedTime = lastedTime;
    }
    addLastedTime(dt) {
        this._lastedTime += dt;
    }
    isOn() {
        return this._isOn;
    }
    setOn() {
        this._isOn = true;
    }
    setOff() {
        this._isOn = false;
    }
    clearTime() {
        this._recordTime = 0;
    }
    setRunTime(time) {
        this._recordTime = time;
    }
    getRealRunTime() {
        return this._recordTime;
    }
    addRunTime(time) {
        this._recordTime += time;
    }
    getRunTime() {
        if (!this._isOn) {
            return 0;
        } else if (this._isIncrease) {
            return this._recordTime;
        } else {
            return this._lastedTime - this._recordTime;
        }
    }
    getPercent() {
        return this._recordTime / this._lastedTime;
    }
    getRestTime() {
        return this._lastedTime - this._recordTime;
    }
    judgeTimeRunOut() {
        if (this._recordTime >= this._lastedTime) {
            this._isOn = false;
        }
    }
    pause() {
        this._pause = true;
    }
    resume() {
        this._pause = false;
    }
    startIfStop(){
        if(!this.isOn()){
            this.clearTime();
            this.setOn();
        }
    }
    update(dt) {
        if (!this._isOn) return;
        if (this._pause) return;
        this._recordTime += dt;
        if (this._recordTime >= this._lastedTime) {
            this.setOff();
            this._cb.exc(this);
        }
    }
}