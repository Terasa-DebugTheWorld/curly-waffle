import uiFunc from "./uiFunc";

const { ccclass, property } = cc._decorator;

@ccclass
export default class uiFuncScene extends cc.Component {
    protected onLoad(): void {
        uiFunc.initMask();
    }

    protected onDisable(): void {
        uiFunc.clean();
    }
}