export const SnapShot = new class {
    public _cullingMask = 0x10000000;
    public shot(inNode: cc.Node, out: cc.Sprite) {
        // 截图图像是翻转的，所以y轴镜像
        out.node.scaleY = -1;

        // 创建渲染贴图对象
        const texture = new cc.RenderTexture();
        texture.initWithSize(cc.visibleRect.width, cc.visibleRect.height, cc.game['_renderContext']['STENCIL_INDEX8']);

        // 在node上创建摄影机
        const camera = inNode.getComponent(cc.Camera) || inNode.addComponent(cc.Camera);

        // 不渲染0x10000000的cullingMask对象
        // camera.cullingMask = 0xffffffff ^ this._cullingMask;
        // camera.alignWithScreen = false;
        // camera.orthoSize = texture.height / 2;
        camera.targetTexture = texture;
        // 关闭摄影机，否则每一帧它会自动进行渲染
        camera.enabled = false;

        // 将自身与忽略对象排除渲染
        // this.cull(this.node);
        // this.cull(out.node);

        // 手动渲染摄影机，保存截图
        camera.render(inNode);

        // this.fixOpacity(texture);

        // 创建一个sprite组件，由其进行渲染
        const spriteFrame = new cc.SpriteFrame();

        // 应用刚刚截图的贴图到sprite身上进行渲染
        spriteFrame.setTexture(texture);
        let mat = cc.mat4();
        camera.getWorldToScreenMatrix2D(mat);
        let rect = cc.rect();
        out.node.getBoundingBoxToWorld().transformMat4(rect, mat);
        spriteFrame.setRect(rect);
        out.spriteFrame = spriteFrame;
    }

    private fixOpacity(texture: cc.RenderTexture, width?: number, height?: number) {
        //论坛大佬给的解决透明像素截图的方案，但是实测很卡
        // let data = new Uint8Array(width * height * 4);
        const data = texture.readPixels();
        for (let i = 0; i < width; i++) {
            for (let j = 0; j < width; j++) {
                let w = j * height * 4 * j * 4 + 3;
                data[w] = Math.round(Math.sqrt(data[w] / 255) * 255);
                if (data[w] > 220) {
                    data[w] = 255;
                }
            }
        }
        texture.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, width, height);
    }

    // 排除忽略渲染对象及其子对象
    private cull(node: cc.Node) {
        if (node) {
            node["_cullingMask"] = this._cullingMask;
            if (node.childrenCount > 0) {
                node.children.map(child => this.cull(child));
            }
        }
    }
}