export default class CallbackHelper {
    _handler = null;
    _target = null;
    constructor(handler?: any, target?: any) {
        if (handler) {
            this.setCallback(handler, target)
        }
    }
    setCallback(handler, target) {
        this._handler = handler;
        this._target = target;
    }
    isSame(handler, target){
        if(this._handler == handler && this._target == target) return true;
        return false;
    }
    clear() {
        this._handler = null;
        this._target = null;
    }
    exc(data?) {
        if (this._handler) {
            let handler = this._handler;
            let target = this._target;
            try {
                if (target) {
                    handler.call(target, data);
                } else {
                    handler(data);
                }
            } catch (e) {
                console.error(e);
            }
        }
    }
    excByArguments(...values) {
        if (this._handler) {
            let handler = this._handler;
            let target = this._target;
            try {
                if (target) {
                    handler.apply(target, values);
                } else {
                    handler(values);
                }
            } catch (e) {
                console.error(e);
            }
        }
    }
}