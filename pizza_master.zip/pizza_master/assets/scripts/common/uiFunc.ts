import uiMaskLayout from '../ui/uiMaskLayout';
import { EventType } from './../static/EventType';
import AsyncQueue from './AsyncQueue';
import { ClientEvent } from "./ClientEvent";
import { DynamicResLoad } from './DynamicResLoad';
import EventListener from './EventListener';
import SimpleStack from './SimpleStack';
import uiPanel from './uiPanel';
export type UiOptions = {
    force?: boolean,
    callback?: (script: uiPanel, node: cc.Node) => void
}
const DEFAULT_OPTIONS: UiOptions = { force: false, callback: null };
const PATH = 'ui/';

export default new class {
    group = "";
    uiList = [];
    showList = {};
    cacheList = {};
    _maskPrefab = null;
    _mask: cc.Node = null;
    _openQueue = new AsyncQueue();
    _wait = [];
    constructor() {
        if (cc.sys.isBrowser) window["uiFunc"] = this;
    }
    async init() {
        // await DynamicResLoad.loadRes(PATH + 'uiMaskLayout', cc.Prefab)
    }

    async initMask() {
        if (this._mask) return;
        this._maskPrefab = await DynamicResLoad.loadRes(PATH + 'uiMaskLayout', cc.Prefab)
        var temp = cc.instantiate(this._maskPrefab);
        temp.setName('uiMaskLayout');
        temp.parent = cc.Canvas.instance.node;
        if (this.group) temp.group = this.group;
        this._mask = temp;
        var panel = temp.getComponent("uiPanel");
        if (panel) {
            panel.show();
        }
    }

    clean() {
        if (this._mask) {
            this._mask.destroy();
            this._mask = null;
        }
        this.closeAll();
        this.cacheList = [];
        this.uiList = [];
        this.showList = {};
        this.cacheList = {};
    }

    async load(uiPath) {
        uiPath = this.parseUIPath(uiPath);
        let prefab = await DynamicResLoad.loadRes(uiPath, cc.Prefab);
        return prefab;
    }

    _opening = false;
    async open<T extends uiPanel>(uiPath: { prototype: T } | string, data: Parameters<T['setData']>[0] = null, options: UiOptions = null) {
        if (!options) options = DEFAULT_OPTIONS;
        for (let k in DEFAULT_OPTIONS) {
            if (!(k in options))
                options[k] = DEFAULT_OPTIONS[k];
        }
        let uiName = typeof uiPath == 'string' ? this.uiPathToName(uiPath) : cc.js.getClassName(uiPath);
        //保证ui出现按照调用顺序
        if (this._opening) {
            await this._openQueue.wait(uiName);
        }
        //相同页面暂不支持同时打开
        if (this.showList[uiName]) {
            cc.error('这个页面已经打开', uiName);
            return;
        }
        //force是false的时候
        if (!options.force) {
            if (this.size > 0) {
                this.push(uiName, data, options);
                return;
            }
        }
        try {
            this._opening = true;
            let pannel = this.cacheList[uiName];
            if (!pannel) {
                let prefab = await this.load(uiName);
                pannel = cc.instantiate(prefab);
                this.cacheList[uiName] = pannel;
                // cc.log("uiFunc open new ui:", uiName);
            } else {
                // cc.log("uiFunc open cache ui:", uiName);
            }
            let scrpit = pannel.getComponent(uiName);
            if (!scrpit) {
                cc.error("ui没有继承uiPannle");
                this._opening = false;
                return;
            } else {
                scrpit.uiName = uiName;
            }
            this.uiList.push(pannel);
            let base = pannel.getComponent("uiPanel");
            if (base) {
                base.show && base.show();
            }
            if (data && scrpit) {
                scrpit.setData && scrpit.setData(data);
            }
            pannel.active = true;
            pannel.parent = cc.Canvas.instance.node;
            if (this.group) pannel.group = this.group;
            this.showList[uiName] = scrpit;
            ClientEvent.dispatch(ClientEvent.eventType.openUI, { uiName });
            this._opening = false;
            if (this._openQueue.length > 0) {
                this._openQueue.excu();
            }
            return scrpit;
        } catch (error) {
            if (this._openQueue.length > 0) {
                this._openQueue.excu();
            }
            console.error(error);
        }
    }

    push(uiPath, data, options) {
        this._wait.push({ uiPath, data, options })
    }

    close(uiName, destory = false) {
        let pannel = this.showList[uiName];
        if (!pannel) {
            return;
        }
        let base = pannel.node.getComponent("uiPanel");
        let removeCall = () => {
            // pannel.active = false;
            if (pannel.node.parent.active) pannel.node.removeFromParent(true);
            for (let i = this.uiList.length - 1; i >= 0; i--) {
                if (this.showList[uiName].node.uuid == this.uiList[i].uuid) {
                    this.uiList.splice(i, 1);
                    break;
                }
            }
            delete this.showList[uiName];
            if (destory) {
                let panel: cc.Node = this.cacheList[uiName];
                panel.destroy();
                delete this.cacheList[uiName];
            }
            ClientEvent.dispatch(ClientEvent.eventType.closeUI, { uiName });
            if (this._wait.length > 0) {
                let next = this._wait.pop();
                this.open(next.uiPath, next.data, next.options)
            }
            if (this._wait.length == 0 && this.size == 0) {
                ClientEvent.dispatch(EventType.UI_WILL_EMPTY)
            }
            // cc.log("uiFunc close ui", uiName);
        }
        if (base) {
            base.hide(removeCall);
        } else {
            removeCall();
        }
    }

    pop() {

    }

    closeAll(filters: string[] = []) {
        for (let k in this.showList) {
            if (filters.indexOf(k) >= 0) continue;
            this.close(k);
        }
    }

    get size() {
        return Object.keys(this.showList).length;
    }

    get(uiName) {
        return this.showList[uiName];
    }

    parseUIPath(uiPath: string) {
        if (uiPath.indexOf("/") >= 0) {
            let a = uiPath.split("/");
            if (!a[a.length - 1]) uiPath += a[a.length - 2];
        }
        return PATH + uiPath;
    }
    uiPathToName(uiPath: string) {
        if (uiPath.indexOf("/") >= 0) {
            let a = uiPath.split("/");
            return a[a.length - 1] || a[a.length - 2];
        }
        return uiPath;
    }
}