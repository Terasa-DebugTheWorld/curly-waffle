export default class EventListener {
    _isDispatching = false;
    _onQueue = [];
    _offQueue = [];
    handlers = {};
    on(eventName, handler, target, isOnce: boolean = false) {
        if (this._isDispatching) {
            this._onQueue.push({ eventName: eventName, handler: handler, target: target, isOnce: isOnce });
            return;
        }
        var handlerList = this.handlers[eventName];
        if (!handlerList) {
            handlerList = [];
            this.handlers[eventName] = handlerList;
        }

        for (var i = 0; i < handlerList.length; i++) {
            if (!handlerList[i]) {
                handlerList[i].handler = handler;
                handlerList[i].target = target;
                handlerList[i].isOnce = isOnce;
                return i;
            }
        }

        handlerList.push({ handler: handler, target: target, isOnce: isOnce });
        return handlerList.length;
    }
    off(eventName, handler, target) {
        var handlerList = this.handlers[eventName];
        if (!handlerList) {
            return;
        }

        if (this._isDispatching) {
            this._offQueue.push({ eventName: eventName, handler: handler, target: target });
            return;
        }

        for (var i = handlerList.length - 1; i >= 0; i--) {
            var oldHandler = handlerList[i].handler;
            var oldTarget = handlerList[i].target;
            if (oldHandler === handler && oldTarget === target) {
                handlerList.splice(i, 1);
                break;
            }
        }
    }
    dispatch(eventName, data) {
        var handlerListTemp = this.handlers[eventName];
        let handlerList = [];

        for (let key in handlerListTemp) {
            handlerList[key] = handlerListTemp[key];
        }

        if (!handlerList) {
            return;
        }

        this._isDispatching = true;
        var len = handlerList.length;

        for (var i = 0; i < len; i++) {
            var handler = handlerList[i].handler;
            var target = handlerList[i].target;
            var isOnce = handlerList[i].isOnce;
            if (handler) {
                try {
                    if (target) {
                        handler.call(target, data);
                    } else {
                        handler(data);
                    }
                    if (isOnce) this.off(eventName, handler, target);
                } catch (e) {
                    console.error(e);
                }
            }
        }
        this._isDispatching = false;

        this._dealQueue();
    }
    clear(target) {
        for (var eventName in this.handlers) {
            var handlerList = this.handlers[eventName];
            for (var i = handlerList.length - 1; i >= 0; i--) {
                var oldTarget = handlerList[i].target;
                if (oldTarget === target) {
                    handlerList.splice(i, 1);
                }
            }
        }
    }
    _dealQueue() {
        if (this._onQueue.length > 0) {
            this._onQueue.forEach(q => {
                this.on(q.eventName, q.handler, q.target, q.isOnce);
            })
            this._onQueue = [];
        }

        if (this._offQueue.length > 0) {
            this._offQueue.forEach(q => {
                this.off(q.eventName, q.handler, q.target)
            })

            this._offQueue = [];
        }
    }
}
