export default class NodePool {
    _prefabToNodeList = new Map();

    _nodeToList = new Map();

    _urlToPrefab = new Map();

    _outList = new Map();

    get(prefab: cc.Prefab | cc.Node): cc.Node {
        if (!prefab) {
            cc.error('[PoolManager] get prefab is null.');

            return;
        }

        let nodeList = null;

        if (!this._prefabToNodeList.has(prefab)) {
            nodeList = [];
            this._prefabToNodeList.set(prefab, nodeList);
        } else {
            nodeList = this._prefabToNodeList.get(prefab);
        }

        let node = nodeList.shift();
        let newFlag = false;
        if (!node) {
            node = cc.instantiate(prefab);
            newFlag = true;
        }

        if (newFlag == false && node.active == true) {
            // let cpns = node.getComponentsInChildren(cc.Component);
            // cpns.forEach(c => {
            //     c.onEnable();
            // })
        } else {
            node.active = true;
        }

        this._nodeToList.set(node, nodeList);

        return node;
    }

    printList() {

    }

    getByUrl(url, callBack) {
        if (!url) {
            cc.error('[PoolManager] getByUrl url is null.');

            return;
        }

        const self = this;
        const prefab = this._urlToPrefab.get(url);

        if (prefab) {
            const node = this.get(prefab);

            callBack(null, node);

            return;
        }

        cc.loader.loadRes(
            url,
            (err, res) => {
                if (res && res instanceof cc.Prefab) {
                    self._urlToPrefab.set(url, res);
                    const node = self.get(res);
                    callBack(err, node);
                }
                else {
                    cc.error("not find res in path:" + url);
                }
            });
    }

    put(node: cc.Node) {
        if (!node) {
            cc.error('[PoolManager] put node is null.');

            return;
        }

        node.removeFromParent(false);
        node.active = false;

        let list = this._nodeToList.get(node);

        if (list) {
            list.push(node);
            this._nodeToList.delete(node);
        }
    }

    putOutScreen(node) {
        if (!node) {
            cc.error('[PoolManager] put node is null.');

            return;
        }

        node.setPosition(cc.v2(10000, 10000))
        node.stopAllActions();
        // let cpns = node.getComponentsInChildren(cc.Component);
        // cpns.forEach(c => {
        //     c.onDisable();
        // })

        let list = this._nodeToList.get(node);

        if (list) {
            list.push(node);
            this._nodeToList.delete(node);
        }
    }

    putOutByScale(node) {
        if (!node) {
            cc.error('[PoolManager] put node is null.');

            return;
        }

        node.scale = 0;
        node.stopAllActions();

        let list = this._nodeToList.get(node);

        if (list) {
            list.push(node);
            this._nodeToList.delete(node);
        }
    }

    clear() {
        this.remove();
        this._prefabToNodeList.forEach((
            value,
            key,
            map
        ) => {
            value.forEach((
                value,
                index,
                array
            ) => {
                value.destroy();
            })
        })
        this._urlToPrefab.clear();
        this._nodeToList.clear();
        this._prefabToNodeList.clear();
    }

    remove() {
        // cc.log('--start--')
        this._nodeToList.forEach((
            value,
            key,
            map
        ) => {
            // cc.log(value,key,map)
            this.put(key);
        })
        this._prefabToNodeList.forEach((
            value,
            key,
            map
        ) => {
            value.forEach((
                value,
                index,
                array
            ) => {
                if (value.active == true) {
                    value.removeFromParent(true);
                    value.active = false;
                }
            })
        })
        // cc.log('--end--')
    }
}