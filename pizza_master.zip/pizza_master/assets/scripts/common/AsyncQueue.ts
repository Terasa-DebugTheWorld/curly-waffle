export default class AsyncQueue {
    debug = false;
    //毫秒
    _inter = 100;
    _queue = [];
    _keyqueue = [];

    constructor() {

    }

    _loop = null;
    setInter(inter) {
        this._inter = inter;
        if (this._loop) clearInterval(this._loop);
        this._loop = setInterval(this.excu.bind(this), inter);
    }

    get length() {
        return this._queue.length;
    }

    wait(key) {
        if (key && this._keyqueue.indexOf(key) >= 0) {
            return Promise.reject('重复提交队列:' + key);
        }
        if (this.debug) {
            console.log('入队列', key, this._queue.length);
        }
        return new Promise((resolve, reject) => {
            this._keyqueue.push(key || null);
            this._queue.push(resolve);
        })
    }

    excu() {
        if (this.length > 0) {
            let key = this._keyqueue.shift();
            let func = this._queue.shift();
            func();
            if (this.debug) {
                console.log('出队列', key, this._queue.length);
            }
        }
    }
}