

const { ccclass, property, menu } = cc._decorator;

@ccclass
export class CutStringInBytes extends cc.Component {

    @property
    maxBytes = 10
    @property
    endBy = '...'

    cut() {
        const reg = /[\u4e00-\u9fa5]/g;
        const label = this.node.getComponent(cc.Label);
        const str1 = label.string;
        const str2 = str1.replace(reg, "aa");
        if (str2.length > this.maxBytes) {
            const arr = str1.split('');
            let n = this.maxBytes;
            const i = arr.findIndex((v, i) => {
                reg.lastIndex = 0;
                const l = reg.test(v) ? 2 : 1;
                n -= l;
                if (n < 0) return true;
            });
            if (i >= 0) {
                label.string = str1.slice(0, i).concat(this.endBy);
            } else {
                label.string = this.endBy;
            }
        } else {
            label.string = str1;
        }
    }

    // LIFE-CYCLE CALLBACKS:

}
