import { BigNumberHelper, BigNumberData, BigNumberInitData } from "./BigNumberHelper";

enum PARAM_CODE {
    NEED_CHANGE = 0,
    NULL = 1,
    INSTANCE = 2
};
const _OPEN_LITTLE = true;
const SAFETY_LENGTH = 15;

export type NumType = (number | string | BigNumber);

interface FormateData { num: NumType, unit: string }

export class BigNumber {
    private _data: string = null;

    public static lerp(from: NumType, to: NumType, ratio: number): BigNumber {
        const a = new BigNumber(from), b = new BigNumber(to);
        ratio = Math.round(ratio * 100) / 100;
        return a.addSelf(b.subSelf(a).mulSelf(ratio));
    }

    public static isNegative(num: NumType): boolean {
        if (num == undefined || num == null) {
            return false;
        }

        const numStr: string = num.toString();
        let fchar = numStr[0];

        if (fchar === '-') {
            return true;
        }

        return false;
    }

    public static negative(num: NumType): string {
        if (num == undefined || num == null) {
            return '0';
        }

        if (BigNumber.isNegative(num)) {
            return num.toString().slice(1);
        } else {
            return '-' + num;
        }
    }

    public static abs(num: NumType): string {
        if (num == undefined || num == null) {
            return '0';
        }

        if (BigNumber.isNegative(num)) {
            return num.toString().slice(1);
        } else {
            return num.toString();
        }
    }

    //10k(10000)以下全显示
    public static formatShort(num: NumType): FormateData {
        const leastLength: number = 4;
        const numStr: string = num.toString();
        const numLength: number = numStr.length;

        if (numLength <= leastLength) {
            return { num: numStr, unit: "" };
        }

        const unitConfig: Array<BigNumberData> = BigNumberHelper.getData();

        for (let i: number = 0; i < unitConfig.length; i++) {
            const c: BigNumberData = unitConfig[i];

            if (c.unitLength >= numLength) {
                //取实际单位数+小数2位,+1个进位判断
                const cutIndex: number = 3 - (c.unitLength - numLength) + 2 - 1;
                const judge: number = +numStr[cutIndex + 1];
                let cutNum: number = +numStr.slice(0, cutIndex + 1);

                if (judge >= 5) {
                    cutNum++;
                }

                cutNum /= 100;

                return { num: cutNum.toFixed(2), unit: c.unit }
            }
        }

        const c: BigNumberData = unitConfig[unitConfig.length - 1];
        //取实际单位数+小数2位,+1个进位判断
        const cutIndex: number = 3 - (c.unitLength - numLength) + 2 - 1;
        const judge: number = +numStr[cutIndex + 1];
        let cutNum: number = +numStr.slice(0, cutIndex + 1);
        if (judge >= 5) {
            cutNum++;
        }
        cutNum /= 100;
        return { num: cutNum.toFixed(2), unit: c.unit }
    }

    public static showShort(num: NumType): string {
        const format: FormateData = BigNumber.formatShort(num);

        return format.num + format.unit;
    }

    //短显示往下2个单位
    public static formatLong(num: NumType): FormateData {
        const numStr: string = num.toString();
        const numLength: number = numStr.length;

        if (numLength <= BigNumberHelper.getFormatLongLength()) {
            return { num: numStr, unit: "" };
        }

        const unitConfig: Array<BigNumberData> = BigNumberHelper.getData();

        for (let i: number = 0; i < unitConfig.length; i++) {
            const c: BigNumberData = unitConfig[i];

            if (c.unitLength >= numLength) {
                //取显示个数6，+1个进位判断
                const cutIndex: number = 3 - (c.unitLength - numLength) + 6 - 1;
                const judge: number = +numStr[cutIndex + 1];
                let cutNum: number = +numStr.slice(0, cutIndex + 1);

                if (judge >= 5) {
                    cutNum++;
                }

                const lowUnit: BigNumberInitData = BigNumberHelper.getDataByIndex(i - 2);

                return { num: cutNum, unit: lowUnit.unit };
            }
        }
        return { num: numStr, unit: "" };
    }

    public static showLong(num: NumType): string {
        const format: FormateData = BigNumber.formatLong(num);

        return BigNumberHelper.withComma(format.num) + format.unit;
    }

    //分子，分母
    public static percent(numerator: NumType, denominator: NumType): number {
        const numeratorStr: string = numerator.toString();
        const denominatorStr: string = denominator.toString();
        const numLen: number = numeratorStr.length;
        const denLen: number = denominatorStr.length;
        const maxLen: number = Math.max(numLen, denLen);
        const calLen: number = 5;
        let numeratorNum = 0;
        let denominatorNum = 0;

        if (maxLen > calLen) {
            if (maxLen - calLen < denLen) {
                denominatorNum = Number(denominatorStr.slice(0, calLen + 1 - (maxLen - denLen)));
            }
            else {
                denominatorNum = 1;
            }

            if (maxLen - calLen < numLen) {
                numeratorNum = Number(numeratorStr.slice(0, calLen + 1 - (maxLen - numLen)));
            }
            else {
                numeratorNum = 0;
            }
            if (denominatorNum == 0) {
                return 0;
            }
            return numeratorNum / denominatorNum;
        } else {
            if (denominatorNum == 0) {
                return 0;
            }
            return Number(numeratorNum) / Number(denominatorNum);
        }
    }

    /** -1为前者小，1是前者大，0是相等 */
    public static compare(num1: NumType, num2: NumType): number {
        let numStr: string = num2.toString();
        let thisStr: string = num1.toString();
        const thisNegative: boolean = BigNumber.isNegative(thisStr);
        const targetNegative: boolean = BigNumber.isNegative(numStr);

        if (thisNegative !== targetNegative) {
            if (thisNegative === true) {
                return -1;
            } else if (targetNegative === true) {
                return 1;
            }
        } else {
            if (thisNegative === true) {
                thisStr = thisStr.slice(1);
                numStr = numStr.slice(1);

                if (numStr.length > thisStr.length) {
                    return 1;
                } else if (numStr.length < thisStr.length) {
                    return -1;
                }

                if (numStr > thisStr) {
                    return 1;
                } else if (numStr < thisStr) {
                    return -1;
                } else {
                    return 0;
                }
            } else {
                if (numStr.length > thisStr.length) {
                    return -1;
                } else if (numStr.length < thisStr.length) {
                    return 1;
                }

                if (numStr > thisStr) {
                    return -1;
                } else if (numStr < thisStr) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }
    }

    public static min(...args: NumType[]) {
        let lowestValue: NumType;
        args.forEach((value) => {
            if (!lowestValue || BigNumber.compare(value, lowestValue) == -1) {
                lowestValue = value;
            }
        });
        return lowestValue.toString();
    }

    public static max(...args: NumType[]) {
        let highestValue: NumType;
        args.forEach((value) => {
            if (!highestValue || BigNumber.compare(value, highestValue) == 1) {
                highestValue = value;
            }
        });
        return highestValue.toString();
    }

    //--静态方法end
    constructor(number: NumType) {
        this._data = String(number);
    }

    public set(number: NumType): BigNumber {
        this._data = String(number);

        return this;
    }

    public cmp(num: NumType): number {
        //-1为目标大，1是本体大，0是相等
        let check: PARAM_CODE = this._checkParam(num);

        if (check == PARAM_CODE.NULL) {
            cc.error('参数错误');

            return;
        }

        let numStr: string = num.toString();
        let thisStr: string = this.toString();
        const thisNegative: boolean = BigNumber.isNegative(thisStr);
        const targetNegative: boolean = BigNumber.isNegative(numStr);

        if (thisNegative !== targetNegative) {
            if (thisNegative === true) {
                return -1;
            } else if (targetNegative === true) {
                return 1;
            }
        } else {
            if (thisNegative === true) {
                thisStr = thisStr.slice(1);
                numStr = numStr.slice(1);

                if (numStr.length > thisStr.length) {
                    return 1;
                } else if (numStr.length < thisStr.length) {
                    return -1;
                }

                if (numStr > thisStr) {
                    return 1;
                } else if (numStr < thisStr) {
                    return -1;
                } else {
                    return 0;
                }
            } else {
                if (numStr.length > thisStr.length) {
                    return -1;
                } else if (numStr.length < thisStr.length) {
                    return 1;
                }

                if (numStr > thisStr) {
                    return -1;
                } else if (numStr < thisStr) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }
    }

    public equalTo(num: NumType): boolean {
        return this.cmp(num) == 0;
    }

    public isZero(): boolean {
        return this.equalTo(0);
    }

    private _checkParam(num: NumType): PARAM_CODE {
        if (num == undefined || num == null) {
            return PARAM_CODE.NULL;
        }

        if (num instanceof BigNumber) {
            return PARAM_CODE.INSTANCE;
        }

        return PARAM_CODE.NEED_CHANGE;
    }

    private _judgeAddSub(num: NumType): string {
        const check: PARAM_CODE = this._checkParam(num);

        if (check === PARAM_CODE.NULL) {
            cc.error('参数错误');

            return;
        }

        const numStr = num.toString();

        //测试时需要关闭这一段
        if (_OPEN_LITTLE) {
            if (numStr.length < SAFETY_LENGTH && this._data.length < SAFETY_LENGTH) {
                return String(Math.round(Number(this._data) + Number(numStr)))
            }
        }
        //------

        const thisNegative: boolean = BigNumber.isNegative(this._data);
        const targetNegative: boolean = BigNumber.isNegative(numStr);

        if (thisNegative !== targetNegative) {
            return this._runSub(numStr);
        } else {
            return this._runAdd(numStr, thisNegative);
        }
    }

    private _runAdd(num: NumType, isNegative: boolean): string {
        //num跟this._data保证同正或者同负
        let startIndex: number = 0;

        if (isNegative) {
            startIndex = 1;
        }

        let big: NumType = num;
        let small: NumType = this.toString();

        if (this.cmp(num) == 1) {
            big = this.toString();
            small = num;
        }

        big = big.toString();
        small = small.toString();

        const lengthDiff: number = big.length - small.length;
        let ans: Array<number> = [];

        for (let i = big.length - 1; i >= startIndex; i--) {
            const index2: number = i + 1;
            const add: number = Number(big[i] || 0) + Number(small[i - lengthDiff] || 0) + Number(ans[index2] || 0);

            ans[i] = Math.floor(add / 10);
            ans[index2] = add % 10;
            // cc.log(i, add, ans[index1], ans[index2])
        }
        // cc.log(ans)
        let result: string = ans.join('');
        result = +result === 0 ? '0' : result.replace(/^0+/, '');

        if (isNegative) {
            result = '-' + result;
        }

        return result;
    }

    private _runSub(target: NumType): string {
        const absThis: string = BigNumber.abs(this._data);
        target = BigNumber.negative(target);
        const absTarget: string = BigNumber.abs(target);
        let big: string = absTarget;
        let small: string = absThis;

        if (this.cmp(absTarget) === 1) {
            big = absThis;
            small = absTarget;
        }

        let ans: Array<number> = [];
        let lengthDiff: number = big.length - small.length;
        // cc.log(big, small)
        for (let i: number = big.length - 1; i >= 0; i--) {
            let index2: number = i + 1;
            let sub: number = Number(big[i] || 0) - Number(small[i - lengthDiff] || 0) + (ans[index2] || 0);

            if (sub < 0) {
                sub += 10;
                ans[i] = -1;
            } else {
                ans[i] = 0;
            }

            ans[index2] = sub;
            // cc.log(i, sub, ans[index1], ans[index2])
        }
        // cc.log(ans)
        let result: string = ans.join('');

        result = +result === 0 ? '0' : result.replace(/^0+/, '');

        if (this.cmp(target) == -1) {
            result = BigNumber.negative(result);
        }

        return result;
    }

    public add(num: NumType): string {
        return this._judgeAddSub(num);
    }

    public addSelf(num: NumType): BigNumber {
        this.set(this._judgeAddSub(num));

        return this;
    }

    public sub(num: NumType): string {
        return this._judgeAddSub(BigNumber.negative(num));
    }

    public subSelf(num: NumType): BigNumber {
        this.set(this._judgeAddSub(BigNumber.negative(num)));

        return this;
    }

    public mul(num: NumType): string {
        const thisNegative: boolean = BigNumber.isNegative(this._data);
        const targetNegative: boolean = BigNumber.isNegative(num);
        let isNegative: boolean = true;
        let thisData: string = this._data;

        let numStr: string = num.toString();

        if (thisNegative == targetNegative) {
            isNegative = false;
        }

        if (thisNegative) {
            thisData = BigNumber.negative(thisData);
        }

        if (targetNegative) {
            numStr = BigNumber.negative(numStr);
        }

        // let check = this._checkParam(num);
        // if (check == PARAM_CODE.NULL) {
        //     cc.error('参数错误');
        //     return;
        // }

        const len1: number = thisData.toString().length;
        let len2: number = numStr.length;
        //测试时需要关闭这一段
        if (_OPEN_LITTLE) {
            if (len1 < SAFETY_LENGTH && len2 < SAFETY_LENGTH) {
                return String(Math.round(Number(this._data) * Number(numStr)))
            }
        }
        //------
        let cut: number = 0;
        const dotIndex: number = numStr.indexOf('.');

        if (dotIndex > 0) {
            if (len2 - dotIndex >= 4) {
                cut = 3;
                numStr = numStr.slice(0, dotIndex + 4);
            } else {
                cut = 2;
            }
            numStr = numStr.replace('.', '');
            len2 = numStr.length;
            // cc.log(num,cut)
        }

        let ans: Array<number> = [];

        for (var i = len1 - 1; i >= 0; i--) {
            for (var j = len2 - 1; j >= 0; j--) {
                var index1 = i + j
                var index2 = i + j + 1
                var mul = Number(thisData)[i] * Number(numStr)[j] + (ans[index2] || 0)
                ans[index1] = Math.floor(mul / 10) + (ans[index1] || 0)
                ans[index2] = mul % 10
            }
        }

        let result: string = ans.join('');

        if (cut > 0) {
            result = result.slice(0, ans.length - cut);
        }

        result = +result === 0 ? '0' : result.replace(/^0+/, '');

        if (isNegative) {
            result = '-' + result;
        }

        //这里结果有可能会是多个零的情况，需要转成数字判断
        //原来写的是return +result === 0 ? '0' : result，result字符串会出现有前置0的情况，感谢评论区小伙伴@nicknice的提醒让我找到了这个错误
        return result;
    }

    public mulSelf(num: NumType): BigNumber {
        this.set(this.mul(num));

        return this;
    }

    public div(): void {

    }

    public toString(): string {
        return this._data;
    }

    public formatShort(): FormateData {
        return BigNumber.formatShort(this._data);
    }

    public showShort(): string {
        return BigNumber.showShort(this._data);
    }

    public formatLong(): FormateData {
        return BigNumber.formatLong(this._data);
    }

    public showLong(): string {
        return BigNumber.showLong(this._data);
    }

    public percent(denominator: NumType) {
        return BigNumber.percent(this.toString(), denominator);
    }
}

window['BigNumber'] = BigNumber;