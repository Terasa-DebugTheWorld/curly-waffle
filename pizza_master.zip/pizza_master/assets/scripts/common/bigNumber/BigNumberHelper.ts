import { NumType } from "./BigNumber";
import { BigNum } from "./BigNum";

export interface BigNumberData {
    "id": number,
    "unit": string,
    "times": number,
    "unitLength": number,
    "timesLength": number
}

export interface BigNumberInitData {
    "id": number,
    "unit": string,
    "times": number
}

export class BigNumberHelper {

    private static _data: Array<BigNumberData> = [];

    private static _formatLongLength: number = 0;

    public static init(): void {
        let lengthSum: number = 0;

        for (let k in BigNum) {
            const timesLength = String(BigNum[k].times).length;

            lengthSum += timesLength - 1;
            BigNum[k].unitLength = lengthSum;
            BigNum[k].timesLength = timesLength - 1;

            if (Number(k) == 2) {
                BigNumberHelper._formatLongLength = lengthSum;
            }

            BigNumberHelper._data.push(BigNum[k]);
        }
    }

    public static getFormatLongLength(): number {
        return BigNumberHelper._formatLongLength;
    }

    public static getData(): Array<BigNumberData> {
        return BigNumberHelper._data;
    }

    public static getDataByIndex(index: number): BigNumberData {
        return BigNumberHelper._data[index];
    }

    public static getDataById(id: string): BigNumberInitData {
        return BigNum[id];
    }

    public static fillZero(str: string, length: number): string {
        if (str.length >= length) {
            return str;
        }

        const strLength: number = str.length;

        for (let i: number = 0; i < length - strLength; i++) {
            str = '0' + str;
        }

        return str;
    }

    public static withComma(num: NumType): string {
        const numStr = num.toString();
        const re = /(?=(?!\b)(\d{3})+$)/g;

        return numStr.replace(re, ',');
    }
}

BigNumberHelper.init();