export default class JsZipHelper {
    public static zipFromJson(content):string {
        try {
            var t = new JSZip(),
                o = JSON.stringify(content);
            t.file("data.txt", o);
            let zipStr = t.generate({
                compression: "DEFLATE"
            });
            // cc.log('check unzip:',JsZipHelper.unzip2Json(zipStr))
            // cc.log(o.length,zipStr.length);
            return zipStr;
        } catch (t) {
            console.error("fail to zip = ", content);
        }
        return null;
    }

    public static unzip2Json(content) {
        try {
            var t = new JSZip(content, {
                base64: !0
            }).file("data.txt").asText();
            return JSON.parse(t);
        } catch (t) {
            console.error("fail to unzip = ", content);
        }
        return null;
    }

}
window.jszip=JsZipHelper