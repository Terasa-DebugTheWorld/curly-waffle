import { Util } from '../utils/Util';

export class WeightRandomer {
    private totalWeight: number = 0
    private weights: number[] = []
    constructor(weights: number[]) {
        this.resetWeights(weights);
    }
    public resetWeights(weights: number[]) {
        this.weights = [];
        if (weights.length == 0) return;
        this.totalWeight = weights.reduce((a, b) => {
            const r = Math.max(0, b);
            this.weights.push(r);
            return a + r;
        }, 0);
    }
    private rand(arr: number[], weight: number): number {
        let rand = Util.getRandomClose(0, weight);
        return arr.findIndex(w => {
            rand -= w;
            return rand <= 0;
        });
    }
    public randomIndex(): number {
        return this.rand(this.weights, this.totalWeight);
    }
    public randomIndexExcept(index: number): number {
        const arr = this.weights.slice();
        arr.splice(index, 1);
        return this.rand(arr, this.totalWeight - this.weights[index]);
    }
    public randomIndexIn(indexes: number[]): number {
        const weightsCopy = this.weights.filter((w, i) => indexes.includes(i));
        const randomerCopy = new WeightRandomer(weightsCopy);
        const rand = randomerCopy.randomIndex();
        return indexes[rand];
    }

    public setWeight(index: number, weight: number) {
        if (index < this.weights.length) {
            const incr = weight - this.weights[index];
            this.incrWeight(index, incr);
        }
    }
    public incrWeight(index: number, incr: number) {
        if (index < this.weights.length) {
            incr = Math.max(incr, -this.weights[index]);
            this.weights[index] += incr;
            this.totalWeight += incr;
        }
    }
    public getWeight(index: number): number {
        return this.weights[index];
    }
}