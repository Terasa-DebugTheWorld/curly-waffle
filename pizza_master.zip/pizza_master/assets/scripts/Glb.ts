enum MajiaEnum {
    app = 0
}
export const majiabao = MajiaEnum.app; //打马甲包前改这
export const Glb = [
    //app
    {
        version: "1.0",
        gameId: 50002,
        appid: 'wx9214e1cca97f5349',
        xg: false,
    },
][majiabao];
console.log('版本号:', Glb.version);