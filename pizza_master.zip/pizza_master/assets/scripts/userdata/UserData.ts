import { TemplateParse } from './TemplateParse';
import { LocalStorage } from "./LocalStorage";
import { DataTemplate } from './DataTemplate';
import UserDataFix from './UserDataFix';
import JsZipHelper from '../common/JsZipHelper';

let USE_SD_CARD = false;
export default class UserData {
    public static _data = {};
    public static isNew = false;
    public static isInit = false;
    public static chgFlag = false;
    private static resetList = {};
    public static async init() {
        LocalStorage.init();

        for (let k in DataTemplate) {
            let item = DataTemplate[k];
            if (item.dailyReset) {
                UserData.resetList[k] = item;
            }
            UserData._data[k] = TemplateParse.readParse(item, LocalStorage.getItem(k));
        }
        // if (UserData.get('userId') == DataTemplate.userId.default) {
        //     let userId = new Date().getTime() + '';
        //     for (let i = 0; i < 3; i++) {
        //         userId += Util.getRandom(0, 10);
        //     }
        //     UserData.set('userId', userId);
        // }
        if (USE_SD_CARD) {
            let phoneRecord = UserData.readFromPhone();
            if (phoneRecord._init) {
                UserData.setSaveData(phoneRecord);
            }
            cc.game.on(cc.game.EVENT_HIDE, () => {
                UserData.writeToPhone();
            });

            cc.game.on(cc.game.EVENT_SHOW, () => {

            });
            //自动存盘(时间可调)
            setInterval(() => {
                UserData.writeToPhone();
            }, 60 * 1000)
        }

        if (UserData.get('_init') == 0) {
            UserData.isNew = true;
        } else {
            UserData.isNew = false;
        }
        UserData._firstSet();
        UserData.isInit = true;
        cc.log(UserData._data)
    }

    private static _getSdCardFile() {
        let packageName = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getPackageName", "()Ljava/lang/String;");
        let path = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getSdCardPath", "()Ljava/lang/String;");
        let file = path + '/naga/' + packageName
        return file;
    }

    public static writeToPhone() {
        if (cc.sys.platform != cc.sys.ANDROID) return;
        if (!USE_SD_CARD) return;
        let data = this.getSaveData();
        data['_updateTime'] = Date.now();
        data = JsZipHelper.zipFromJson(data);
        let file = UserData._getSdCardFile();
        jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "writeFileToSdCard", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", file, 'data', data);
        jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "writeFileToSdCard", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", jsb.fileUtils.getWritablePath(), 'data', data);
    }

    public static readFromPhone() {
        if (cc.sys.platform != cc.sys.ANDROID) return {};
        if (!USE_SD_CARD) return {};
        let file = UserData._getSdCardFile();
        let data: any = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "readFileFromSdCard", "(Ljava/lang/String;)Ljava/lang/String;", file + '/data');
        if (data.length > 0) {
            data = JsZipHelper.unzip2Json(data);
        } else {
            file = jsb.fileUtils.getWritablePath();
            let backup = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "readFileFromSdCard", "(Ljava/lang/String;)Ljava/lang/String;", file + '/data');
            if (backup.length == 0) data = {};
            else data = JsZipHelper.unzip2Json(backup);
        }
        return data;
    }

    public static dealAllStorageQueue() {
        LocalStorage.dealAllStorageQueue();
    }

    public static writeAllData() {
        UserData.dealAllStorageQueue();
        UserData.writeToPhone();
    }

    private static _dayRecord = { d: 0, flag: false }
    private static _firstSet() {
        if (UserData.get('_init') == 0) {
            UserData.set('_init', 1);
            UserData.set('createTime', Date.now());
            //第一次创建数据

        } else {
            let createTime = UserData.get('createTime');
            let now = Date.now();
            let baseTime = 1577808000000;//2020-01-01 00:00:00
            let divisor = 1000 * 60 * 60 * 24;
            let createDays = Math.ceil((createTime - baseTime) / divisor);
            let nowDays = Math.ceil((now - baseTime) / divisor);
            let diffDays = nowDays - createDays;
            console.log('比创建账号差距' + diffDays + '天');
            let dRecord = UserData.get('dayRecord');
            let dflag = false;
            if (dRecord != diffDays) {
                UserData.set('dayRecord', diffDays);
                dflag = true;
            }
            UserData._dayRecord.d = diffDays;
            UserData._dayRecord.flag = dflag;
        }
    }

    /**
     * 
     * @param day 次留传2，七留传7
     */
    public static isDayFirst(day) {
        day = day - 1;
        if (UserData._dayRecord.d == day) {
            return true;
        }
        return false;
    }

    public static fix = () => {
        let historyVer = UserData.get('dataVer');
        let newVer = DataTemplate.dataVer.default;
        UserDataFix.fix(historyVer, newVer);
        UserData.set('dataVer', newVer);
    }

    public static clearData() {
        for (let k in DataTemplate) {
            LocalStorage.removeItem(k);
        }
        UserData._data = {};
        for (let k in DataTemplate) {
            let item = DataTemplate[k];
            UserData._data[k] = TemplateParse.readParse(item, LocalStorage.getItem(k));
        }
        UserData.isNew = true;
        UserData._firstSet();
        UserData.writeAllData();
    }

    public static _isFlushing = false;
    public static flush = () => {
        if (UserData._isFlushing) return;
        UserData._isFlushing = true;
        for (let k in DataTemplate) {
            LocalStorage.removeItem(k);
        }
        UserData._data = {};
        if (USE_SD_CARD) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "writeFileToSdCard", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", UserData._getSdCardFile(), 'data', "");
            USE_SD_CARD = false;
        }
        setTimeout(() => {
            cc.game.end();
        }, 100)
    }

    public static save = (key) => {
        if (!UserData.checkKey(key)) return;
        UserData.chgFlag = true;
        LocalStorage.setItem(key, TemplateParse.writeParse(DataTemplate[key], UserData._data[key]));
    }

    public static saveAll = () => {
        for (let k in DataTemplate) {
            UserData.save(k);
        }
    }

    public static getSaveData() {
        let ret = {};
        for (let k in DataTemplate) {
            let writeData = TemplateParse.writeParse(DataTemplate[k], UserData._data[k]);
            let defaultWriteData = TemplateParse.writeParse(DataTemplate[k], DataTemplate[k].default);
            // console.log(writeData,defaultWriteData)
            // if (defaultWriteData != writeData) {
            ret[k] = writeData;
            // }
        }
        return ret;
    }

    public static setSaveData(data) {
        for (let k in DataTemplate) {
            if (k in data) {
                let item = DataTemplate[k];
                if (!item) continue;
                UserData._data[k] = TemplateParse.readParse(item, data[k]);
            } else {
                let item = DataTemplate[k];
                UserData._data[k] = TemplateParse.readParse(item, TemplateParse.writeParse(item, item.default));
            }
        }
        // for (let k in data) {
        //     let item = DataTemplate[k];
        //     if (!item) continue;
        //     UserData._data[k] = TemplateParse.readParse(item, data[k]);
        // }
        UserData.saveAll();
        UserData.dealAllStorageQueue();
    }

    public static checkKey = (key) => {
        if (key in UserData._data) {
            return true;
        }
        cc.error('UserData no this key:', key);
        return false;
    }

    public static get = (key, ref = true) => {
        if (!UserData.checkKey(key)) return;
        if (ref == true) {
            return UserData._data[key];
        } else {
            let t = DataTemplate[key];
            if (t.type == 'obj' || t.type == 'list' || t.type == 'hash') {
                return JSON.parse(JSON.stringify(UserData._data[key]));
            } else {
                return UserData._data[key];
            }
        }
    }

    public static set = (key, value, save = true) => {
        if (!UserData.checkKey(key)) return;
        UserData._data[key] = value;
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key];
    }

    public static keys = () => {
        return Object.keys(UserData._data);
    }

    //number相关
    public static incr = (key, save = true) => {
        if (!UserData.checkKey(key)) return;
        UserData._data[key]++;
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key];
    }

    public static incrBy = (key, increment, save = true) => {
        if (!increment) return;
        if (!UserData.checkKey(key)) return;
        UserData._data[key] += increment;
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key];
    }

    //hash相关
    public static hget = (key, field) => {
        if (!UserData.checkKey(key)) return;
        let hash = UserData.get(key);
        return hash[field];
    }

    public static hset = (key, field, value, save = true) => {
        if (field == null || value == null) return;
        if (!UserData.checkKey(key)) return;
        UserData._data[key][field] = value
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key][field];
    }

    public static hdel = (key, field, save = true) => {
        if (field == null) return;
        if (!UserData.checkKey(key)) return;
        delete UserData._data[key][field];
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key];
    }

    public static hincrBy = (key, field, increment, save = true) => {
        if (field == null || increment == null) return;
        if (!UserData.checkKey(key)) return;
        if (UserData._data[key][field] == undefined) UserData._data[key][field] = 0
        UserData._data[key][field] += increment
        if (save == true) {
            UserData.save(key)
        }
        return UserData._data[key];
    }

    public static hincr = (key, field, save = true) => {
        return UserData.hincrBy(key, field, 1);
    }

    public static hexists = (key, field) => {
        if (!UserData.checkKey(key)) return;
        let hash = UserData.get(key);
        if (hash[field] == undefined || hash[field] == null) return false;
        return true;
    }

    public static hkeys = (key) => {
        if (!UserData.checkKey(key)) return;
        let hash = UserData.get(key);
        return Object.keys(hash);
    }

    //list相关
    public static lindex = (key, index) => {
        if (!UserData.checkKey(key)) return;
        return UserData.get(key)[index];
    }

    public static llen = (key) => {
        if (!UserData.checkKey(key)) return;
        return UserData.get(key).length;
    }

    public static rpush = (key, value) => {
        if (!UserData.checkKey(key)) return;
        let list = UserData.get(key);
        list.push(value);
        UserData.save(key);
    }

    public static lpush = (key, value) => {
        if (!UserData.checkKey(key)) return;
        let list = UserData.get(key);
        list.unshift(value);
        UserData.save(key);
    }

    public static lset = (key, index, value) => {
        if (!UserData.checkKey(key)) return;
        let list = UserData.get(key);
        if (list[index] != undefined) {
            list[index] = value;
            return;
        }
        UserData.save(key);
    }
}

window["UserData"] = UserData;