export const SceneDataTemplate = {

};