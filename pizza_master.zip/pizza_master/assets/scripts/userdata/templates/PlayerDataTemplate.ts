export const PlayerDataTemplate = {
    gold: {
        "type": "bigNumber",
        "default": "0"
    },
    rmb: {
        "type": "int",
        "default": 0
    },
    diamond: {
        "type": "int",
        "default": 0
    },
    exp: {
        "type": "int",
        "default": 0
    },
    lv: {
        "type": "int",
        "default": 1
    },
    stage: {
        "type": "obj",
        "default": 1
    },
    openId: {
        "type": "string",
        "default": ""
    },
    nickname: {
        "type": "string",
        "default": ""
    },
    headimgurl: {
        "type": "string",
        "default": ""
    },
    favor: {
        "type": "int",
        "default": 0
    },
    video_cnt: {
        "type": "int",
        "default": 0,
    },
};