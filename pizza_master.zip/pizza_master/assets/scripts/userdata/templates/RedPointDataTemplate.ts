export const RedPointDataTemplate = {

};
