export const SystemDataTemplate = {

};