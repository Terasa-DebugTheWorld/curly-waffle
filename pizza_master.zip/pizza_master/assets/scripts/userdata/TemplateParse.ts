import { BigNumber } from './../common/bigNumber/BigNumber';
export const TemplateParse = {
    typeParse(data, type) {
        switch (type) {
            case 'int':
                return parseInt(data);
            case 'number':
                return Number(data);
            case 'float':
                return parseFloat(data);
            case 'obj':
            case 'hash':
            case 'list':
                return JSON.parse(data);
            case 'string':
                return String(data);
            case 'bigNumber':
                return new BigNumber(data);
            default:
                return data;
                break;
        }

    },
    readParse(item, readData) {
        if (!readData) {
            if (item.type == 'bigNumber') {
                return new BigNumber(item.default);
            } else {
                return this.typeParse(this.writeParse(item,item.default),item.type);
            }
        } else {
            try {
                return this.typeParse(readData, item.type);
            } catch (error) {
                console.error('mark:',error);
                console.error(readData);
                return this.typeParse(this.writeParse(item,item.default),item.type);
            }
        }
    },
    writeParse(item, data) {
        let writeData = data;
        if (item.type == 'bigNumber') {
            writeData = data.toString();
        } else if (typeof data == 'object') writeData = JSON.stringify(data)
        else writeData = data.toString();
        return writeData;
    }
};