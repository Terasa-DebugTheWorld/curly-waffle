import encrypt = require('./encrypt/encryptjs');
const _KEY = 'nagagame'
export default class EncryptHelper {
    public static encode(content) {
        return encrypt.encrypt(content, _KEY, 128);
    }

    public static decode(content):string {
        return encrypt.decrypt(content, _KEY, 128)
    }

}