import UserData from './UserData';

export default class UserDataFix {
    public static fix(oldVer, newVer) {
        
    }
};