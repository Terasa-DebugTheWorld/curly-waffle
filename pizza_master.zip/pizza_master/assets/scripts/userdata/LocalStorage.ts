import EncryptHelper from "./EncryptHelper";

let _USE_ENCRYPT = false;
if (cc.sys.isBrowser) _USE_ENCRYPT = false;
export const LocalStorage = {
    _temp: {},
    _queue: [],
    _init: false,
    init() {
        if (this._init) return;
        this._init = true;
        this._updateCnt = 0;
        cc.director.on(cc.Director.EVENT_AFTER_UPDATE, () => {
            this._updateCnt++;
            if (this._updateCnt >= 60) {
                this._updateCnt = 0;
                // cc.log(this._queue)
                if (this._queue.length > 0) {
                    let key = this._queue.shift();
                    this.setItemInstant(key, this._temp[key]);
                    // cc.log('写入数据:', key, this._temp[key], '队列:', this._queue.length);
                }
            }
        });
    },
    dealAllStorageQueue() {
        for (let i = 0; i < this._queue.length; i++) {
            let key = this._queue[i];
            this.setItemInstant(key, this._temp[key]);
        }
        this._queue = [];
        this._temp = {};
    },
    getItem(key) {
        let str = cc.sys.localStorage.getItem(key);
        if (_USE_ENCRYPT && str) {
            return EncryptHelper.decode(str);
        }
        return str;
    },
    setItem(key, value) {
        // cc.log('写入数据:', key, value);
        this._temp[key] = value;
        if (this._queue.indexOf(key) < 0) {
            this._queue.push(key);
        }
        // cc.sys.localStorage.setItem(key, value);
    },
    setItemInstant(key, value) {
        //cc.log('写入数据:', key, value)
        if (_USE_ENCRYPT) {
            value = EncryptHelper.encode(value);
        }
        cc.sys.localStorage.setItem(key, value);
    },
    removeItem(key) {
        cc.sys.localStorage.removeItem(key);
    },
};