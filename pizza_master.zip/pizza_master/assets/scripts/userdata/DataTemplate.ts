import { RedPointDataTemplate } from './templates/RedPointDataTemplate';
import { SceneDataTemplate } from './templates/SceneDataTemplate';
import { PlayerDataTemplate } from './templates/PlayerDataTemplate';
import { SystemDataTemplate } from './templates/SystemDataTemplate';
//说明:
//数据支持,string,int,float,number,hash,obj,list
//hash不能嵌套hash，数据结构为key-value
//obj为自由的对象，通过get获取到引用，修改会直接导致内存修改，使用save接口存盘
//
var dataTemplate = {
    //数据版本号
    dataVer: {
        "type": "string",
        "default": "1.1"
    },
    _init: {
        "type": "int",
        "default": 0
    },
    userId: {
        "type": "string",
        "default": ""
    },
    openid: {
        "type": "string",
        "default": ""
    },
    wxLogin: {
        "type": "int",
        "default": 0
    },
    loginDay: {
        "type": "int",
        "default": 1
    },
    dayRecord: {
        "type": "int",
        "default": 0
    },
    loginDate: {
        "type": "string",
        "default": ""
    },
    createTime: {
        "type": "int",
        "default": Date.now()
    },
    playTime: {
        "type": "int",
        "default": 0
    },
    videoCount: {
        "type": "int",
        "default": 0,
        "dailyReset": true,
    },
    offlineTime: {
        "type": "int",
        "default": 0
    },
    guide: {
        "type": "int",
        "default": 0
    },

    privacy: {
        "type": "int",
        "default": 0
    },
    pizza: {
        'type': 'obj',
        'default': {
            gold: 0,
            diamond: 0,
            day: 0,
        }
    },
    recipe: {
        "type": "obj",
        "default": {
            "unlockedRecipes": [],
            "newRecipes": [],
            "rewarded": [],
        }
    },
    sliver: {
        "type": "obj",
        "default": {
            "unlockedSlivers": []
        }
    },
    decorate: {
        "type": "obj",
        "default": {
            "unlock": 0,
            "using": []
        }
    },
};

var list = [PlayerDataTemplate, SceneDataTemplate, RedPointDataTemplate, SystemDataTemplate];

list.forEach((t) => {
    for (let k in t) {
        if (!dataTemplate[k]) {
            dataTemplate[k] = t[k];
        } else {
            cc.log('重复定义数据:', k);
        }
    }
})

export var DataTemplate = dataTemplate;
