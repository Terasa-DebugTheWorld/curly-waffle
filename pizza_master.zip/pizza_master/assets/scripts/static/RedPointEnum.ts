export const RedPointEnum = cc.Enum({
    NONE: 0
});