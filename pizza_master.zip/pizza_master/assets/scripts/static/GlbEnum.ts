export const GlbEnum = {
    GOLD: 1,
    DIAMOND: 2,
    FAVOR: 3,
    VIDEO: 100,
};

export enum RewardType {
    rmb_coin = 1,
}