import uiFunc from "../common/uiFunc";

export enum ErrorCode {
    SUCC = 0,
    FAIL = 100,
    NOT_ENOUGH_GOLD = 1,
    NOT_ENOUGH_DIAMOND = 2,
    NOT_ENOUGH_FAVOR = 3,
    NOT_ENOUGH_YUBI = 4,
    NOT_ENOUGH_LV = 5,
    NOT_ENOUGH_VIDEO = 10,
    NOT_ENOUGH_CONDITION = 11,
    IS_MAX = 12,
    WAIT_UNLOCK = 13,
    UNLOCK_BEFORE_STAFF = 14,
}

let Tips = {
    format: (code) => {
        if (Tips[code] || Tips[code] == "") {
            return Tips[code];
        }
        return "未知错误:" + code;
    }
}
Tips[ErrorCode.WAIT_UNLOCK] = '等待解锁';
Tips[ErrorCode.NOT_ENOUGH_DIAMOND] = '钻石不足';

class ErrorClass {
    code = 0
    data = null;
    constructor(errcode, data) {
        this.code = errcode;
        this.data = data;
    }
    execute() {
        switch (this.code) {
            case ErrorCode.NOT_ENOUGH_GOLD:
            case ErrorCode.NOT_ENOUGH_YUBI:
            case ErrorCode.NOT_ENOUGH_DIAMOND:
                // uiFunc.openUI(uiNotEnoughGold, null, { force: true })
                break;
        }
        return this;
    }
}

export const ErrorWrapper = function (code: ErrorCode, data?: any): ErrorClass {
    return new ErrorClass(code, data).execute();
}