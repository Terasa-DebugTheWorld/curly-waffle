export const EventType = cc.Enum({
    NONE: 'none',
    UPDATE_GOLD: 'update_gold',
    UPDATE_FAVOR: 'update_favor',
    UPDATE_LV: 'update_lv',
    UPDATE_EXP: 'update_exp',
    UPDATE_DIAMOND: 'update_diamond',
    UPDATE_YUBI: 'update_yubi',
    OFFLINE_PRIZE: 'offline_prize',
    UI_WILL_EMPTY: 'ui_will_empty',
    VIDEO_COMPLETE: 'video_complete',
    VIDEO_AWARD_SUCC: 'video_award_succ',

    WECHAT_LOGIN_SUCCESS: 'wechat_login_success',
    WECHAT_BIND_SUCCESS: 'wechat_bind_success',
    WECHAT_BIND_ERROR: 'wechat_bind_error',

    //game
    ELIM_PROP: 'elim_prop',

    SELECT_RECIPE: 'select_recipe',//选择食谱

    UPDATE_TIME: 'update_time',//更新时间
    CHANGE_DECORATION: 'change_decoration',//更换装饰

    UPDATE_RECIPE_DOT: 'update_recipe_dot'
});