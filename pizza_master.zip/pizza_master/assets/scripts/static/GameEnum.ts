export const GameEnum = {
    WATERMELON: "watermelon",
    FISH: "fish",
    DROPFISH:"DROPFISH"
}

export enum SliverType {
    SAUCE = 1,//酱料
    MEAT,//肉类
    VEGETABLE,//素菜
    FRUIT,//水果
    OTHER,//其他
}

export enum PutType {
    DRAG = 1,//拖拽平铺
    PARTICLE,//颗粒状
    STRIP,//条状
}

/**货币类型 */
export enum CurrencyType{
    GOLD = 'gold',
    DIAMOND = 'diamond'
}

/**订单记录 */
export enum OrderRecordType{
    YOU,
    GUEST
}