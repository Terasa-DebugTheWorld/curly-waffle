import { Ad } from "../3rd/Ad";
import { Platform } from "../3rd/Platform";
import { ThirdType } from "../3rd/ThirdType";
import { ClientEvent } from "../common/ClientEvent";
import DataFunc from "../common/DataFunc";
import PersistBuffTime from "../common/PersistBuffTime";
import { Util } from "../utils/Util";

const { ccclass, property } = cc._decorator;

@ccclass
export class InsertMgr extends cc.Component {
    private timer = new PersistBuffTime(0)
    public randomPlay(rand: number, delay = 0): boolean {
        const flag = Math.random() <= rand;
        const succ = flag && this.timer.getRestTime() <= 0;
        if (succ) {
            Util.delay(delay).then(() => {
                console.log('插屏播放')
                Ad.playInsert(/* {
                    onError: () => {
                        if (UserData.get('guide') == 0) return;
                    }
                } */);
                this.cooldown();
            });
        }
        return succ;
    }

    //从后台回到游戏
    private playOnShow() {
        if (this.stop) return;
        this.randomPlay(1);
    }

    private cooldown() {
        this.timer.setLastedTime(this.cd);
        this.timer.clearTime();
        this.timer.setOn();
    }
    // LIFE-CYCLE CALLBACKS:
    public static instance: InsertMgr
    private cd: number
    autoTimer = new PersistBuffTime(30);
    stop = false;
    async onLoad() {
        InsertMgr.instance = this;
        if (Platform.isWx) {
            cc.game.on(cc.game.EVENT_SHOW, this.playOnShow, this);
            this.randomPlay(1);
            this.cd = 0;
            // this.autoTimer.setLastedTime(this.cd);
            // this.autoTimer.setOn();
            // this.autoTimer.setCallBack(this.onAutoPlay, this);
        }
        this.cd = DataFunc.getBaseConfig('INSERT_CD') || 150;
        this.timer.setLastedTime(this.cd);
        this.timer.setRunTime(this.cd);
        this.timer.setOn();

        ClientEvent.on("adVideo", (ret) => {
            // if (ret.code == ThirdType.AD_CODE.ON_EXCU_PLAY) {
            //     this.autoTimer.pause();
            // } else {
            //     this.autoTimer.resume();
            // }
            if (ret.code == ThirdType.AD_CODE.ON_CLOSE || ret.code == ThirdType.AD_CODE.ON_AWARD_SUCC) {
                this.cooldown();
            }
        })
        cc.game.addPersistRootNode(this.node);
    }
    update(dt: number) {
        this.timer.update(dt);
        // this.autoTimer.update(dt);
    }

    onAutoPlay() {
        this.autoTimer.clearTime();
        this.autoTimer.setOn();
        this.randomPlay(1);
    }
}
