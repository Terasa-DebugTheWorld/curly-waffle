import { Ad } from "../3rd/Ad";
import { ClientEvent } from "../common/ClientEvent";
import PersistBuffTime from "../common/PersistBuffTime";
import { nSdk } from "../sdks/wx/nSdk";

const { ccclass, property } = cc._decorator;

@ccclass
export default class BannerMgr extends cc.Component {
    autoTimer = new PersistBuffTime(40);
    showTimer = new PersistBuffTime(2);

    public static inst: BannerMgr = null;
    protected onLoad(): void {
        BannerMgr.inst = this;
        window["BannerMgr"] = this;
        cc.game.addPersistRootNode(this.node);
        // let banUI = ["uiRemen", "uiClickBox","uiGrids"]
        // ClientEvent.on(ClientEvent.eventType.openUI, ({ uiName }) => {
        //     if (banUI.indexOf(uiName) < 0)
        //         this.playBanner();
        // })
        // ClientEvent.on(ClientEvent.eventType.closeUI, ({ uiName }) => {
        //     if (banUI.indexOf(uiName) < 0)
        //         this.hidBanner();
        // })
    }

    protected start(): void {
        this.autoTimer.setOn();
        this.autoTimer.setCallBack(this.autoPlay, this);
        this.showTimer.setCallBack(this.autoHide, this);
    }

    protected update(dt: number): void {
        this.autoTimer.update(dt);
        this.showTimer.update(dt);
    }

    playBanner() {
        this.autoTimer.pause();
        this.showTimer.pause();
        Ad.playBanner();
    }

    hidBanner() {
        this.autoTimer.resume();
        this.showTimer.resume();
        Ad.hideBanner();
    }

    autoPlay() {
        if (!nSdk.isAudit() && nSdk.getConfig("auto_video") != "1") return;
        Ad.playBanner();
        this.showTimer.clearTime();
        this.showTimer.setOn();
    }

    autoHide() {
        this.autoTimer.clearTime();
        this.autoTimer.setOn();
        Ad.hideBanner();
    }
}
