import NodePool from "../common/NodePool";
import { SpinePlayer } from "../components/SpinePlayer";
import { Util } from "../utils/Util";

const { ccclass, property } = cc._decorator;

@ccclass
export class EffectMgr extends cc.Component {
    @property(sp.Skeleton)
    spine_add_diamond: sp.Skeleton = null
    @property(sp.Skeleton)
    spine_add_gold: sp.Skeleton = null
    @property(sp.Skeleton)
    spine_use_diamond: sp.Skeleton = null
    @property(sp.Skeleton)
    spine_use_gold: sp.Skeleton = null
    @property(cc.Prefab)
    prefab_smoke: cc.Prefab = null
    @property(cc.Label)
    label_use: cc.Label = null

    // LIFE-CYCLE CALLBACKS:
    public static ins: EffectMgr
    private orgIndex = 0
    protected onLoad(): void {
        EffectMgr.ins = this;
        this.orgIndex = this.spine_add_gold.node.parent.getSiblingIndex();
    }

    public static async playAddDiamond() {
        const spine = this.ins.spine_add_diamond;
        spine.node.active = true;
        await SpinePlayer.play(spine, 0, 'daiji');
        spine.node.active = false;
    }
    public static async playAddGold() {
        const spine = this.ins.spine_add_gold;
        spine.node.active = true;
        await SpinePlayer.play(spine, 0, 'daiji');
        spine.node.active = false;
    }
    public static async playUseDiamond(cnt: number, target: cc.Node) {
        const spine = this.ins.spine_use_diamond;
        spine.node.parent = target.parent;
        spine.node.position = target.position;
        spine.node.active = true;
        this.flyUse(cnt, target);
        await SpinePlayer.play(spine, 0, 'daiji');
        // spine.node.parent = this.ins.spine_add_diamond.node.parent;
        spine.node.removeFromParent();
        // spine.node.active = false;
    }
    public static async playUseGold(cnt: number, target: cc.Node) {
        const spine = this.ins.spine_use_gold;
        spine.node.parent = target.parent;
        spine.node.position = target.position;
        spine.node.active = true;
        this.flyUse(cnt, target);
        await SpinePlayer.play(spine, 0, 'daiji');
        // spine.node.parent = this.ins.spine_add_diamond.node.parent;
        spine.node.removeFromParent();
        // spine.node.active = false;
    }
    private static flyUse(cnt: number, target: cc.Node) {
        this.ins.label_use.string = '-' + cnt;
        const node = this.ins.label_use.node;
        node.parent = target.parent;
        node.stopAllActions();
        cc.tween(node)
            .set({ opacity: 255, position: target.position })
            .to(1, { opacity: 0, y: target.y + 100 })
            .removeSelf()
            .start()
    }

    private static pool = new NodePool()
    public static playSmoke(n: cc.Node) {
        const node = this.pool.get(this.ins.prefab_smoke);
        node.parent = this.ins.label_use.node.parent;
        node.position = Util.fromNodeToNode(node, n);
        SpinePlayer.play(node.getComponent(sp.Skeleton), 0, 'daiji', false)
            .then(() => this.pool.put(node));
    }
}