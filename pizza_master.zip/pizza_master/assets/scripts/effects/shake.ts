const { ccclass, property, menu } = cc._decorator;

@ccclass
export class shake extends cc.Component {
    @property({ displayName: '延迟时间' })
    delay: number = 2.5
    @property({ displayName: '幅度' })
    range: number = 5
    @property({ displayName: '单摆时间' })
    t: number = 0.1

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onEnable() {
        // this.node.runAction(cc.repeatForever(
        //     cc.rotateBy(this.roundTime, -360)
        // ));
        cc.tween(this.node)
            .to(0.1, { angle: 6 * this.range })
            .to(0.1, { angle: -5 * this.range })
            .to(0.1, { angle: 4 * this.range })
            .to(0.1, { angle: -3 * this.range })
            .to(0.1, { angle: 2 * this.range })
            .to(0.1, { angle: -1 * this.range })
            .to(0.1, { angle: 0 })
            .delay(2.5)
            .union()
            .repeatForever()
            .start();
    }

    onDisable() {
        this.node.angle = 0;
        this.node.stopAllActions();
    }

    // update (dt) {},
};
