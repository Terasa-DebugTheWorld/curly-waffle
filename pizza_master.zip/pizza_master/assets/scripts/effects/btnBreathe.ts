

const { ccclass, property, menu } = cc._decorator;

@ccclass
export class btnBreathe extends cc.Component {

    @property({ displayName: '缩放幅度' })
    scale = 0.2
    @property({ displayName: '周期' })
    duration = 1

    resetInEditor() {
        //本组件的缩放会和按钮的点击缩放起冲突
        const btn = this.getComponent(cc.Button);
        if (btn && btn.transition == cc.Button.Transition.SCALE) {
            btn.transition = cc.Button.Transition.NONE;
        }
    }
    // LIFE-CYCLE CALLBACKS:

    _oldScale: number = 1;
    onLoad() {
        this._oldScale = this.node.scale;
    }

    onEnable() {
        this.node.stopAllActions();
        cc.tween(this.node)
            .set({ scale: this._oldScale })
            .by(this.duration / 2, { scale: this.scale })
            .by(this.duration / 2, { scale: -this.scale })
            .union()
            .repeatForever()
            .start();
    }

    onDisable() {
        this.node.stopAllActions();
    }
}
