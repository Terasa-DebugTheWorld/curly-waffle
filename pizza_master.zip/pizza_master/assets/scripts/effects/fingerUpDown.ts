const { ccclass, property } = cc._decorator;

@ccclass
export class fingerUpDown extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    protected onLoad(): void {
        cc.tween(this.node)
            .by(0.5, { y: 50 })
            .by(0.5, { y: -50 })
            .union()
            .repeatForever()
            .start();
    }
}
