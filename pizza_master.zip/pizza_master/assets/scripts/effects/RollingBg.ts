const { ccclass, property } = cc._decorator;

let rolldir = cc.Enum({
    UP: 1,
    DOWN: 2,
    LEFT: 3,
    RIGHT: 4
})

@ccclass
export default class RollingBg extends cc.Component {
    @property(cc.Node)
    node_other: cc.Node = null;
    @property({ type: rolldir })
    dir = rolldir.LEFT;
    @property()
    speed = 1;

    resetPos
    protected onEnable(): void {
        this.resetPos = this.node_other.getPosition();
    }

    protected update(dt: number): void {
        this.node.x -= this.speed;
        this.node_other.x -= this.speed;
        if (this.node.x < -720) {
            this.node.setPosition(this.resetPos);
        }
        if (this.node_other.x < -720) {
            this.node_other.setPosition(this.resetPos);
        }
    }
}
