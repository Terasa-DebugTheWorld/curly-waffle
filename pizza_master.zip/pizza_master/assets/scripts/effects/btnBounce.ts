const { ccclass, property, menu } = cc._decorator;

/**
 * Q弹果冻效果
 */
@ccclass
export class btnBounce extends cc.Component {

    @property({ displayName: '缩放幅度' })
    scaleX = 0.02
    @property({ displayName: '缩放幅度' })
    scaleY = 0.02
    @property({ displayName: '周期' })
    duration = 1.25

    resetInEditor() {
        //本组件的缩放会和按钮的点击缩放起冲突
        const btn = this.getComponent(cc.Button);
        if (btn && btn.transition == cc.Button.Transition.SCALE) {
            btn.transition = cc.Button.Transition.NONE;
        }
    }
    // LIFE-CYCLE CALLBACKS:

    _oldScale: number = 1;
    onLoad() {
        this._oldScale = this.node.scale;
    }

    onEnable() {
        let ts = this;
        ts.node.stopAllActions();
        cc.tween(ts.node)
            // .set({ scale: this._oldScale })
            // .union()
            .repeatForever(
                cc.tween()
                .to(ts.duration / 2, { scaleX: ts._oldScale - ts.scaleX,scaleY:ts._oldScale + ts.scaleY },{"easing":'sineIn'})
                .to(ts.duration / 2, { scaleX: ts._oldScale + ts.scaleX,scaleY:ts._oldScale - ts.scaleY },{"easing":'sineIn'})
            )
            .start();
    }

    onDisable() {
        this.node.stopAllActions();
    }
}
