const { ccclass, property, menu } = cc._decorator;

@ccclass
export class rotate extends cc.Component {
    @property
    roundTime: number = 12

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onEnable() {
        // this.node.runAction(cc.repeatForever(
        //     cc.rotateBy(this.roundTime, -360)
        // ));
        cc.tween(this.node)
            .by(this.roundTime, { angle: 360 })
            .repeatForever()
            .start();
    }

    onDisable() {
        this.node.stopAllActions();
    }

    // update (dt) {},
};
