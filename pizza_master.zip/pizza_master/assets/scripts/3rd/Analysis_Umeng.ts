//62d8b2e688ccdf4b7ed93660
export const Analysis_Umeng = {
    init(config) {
        var isdebug = false;
        if (cc.sys.platform == cc.sys.ANDROID) {
            console.log('umeng init');
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "initUMeng", "(Ljava/lang/String;Ljava/lang/String;Z)V", config.Um_appkey, config.Um_channel, isdebug);
        } else if (cc.sys.platform == cc.sys.IPHONE || cc.sys.platform == cc.sys.IPAD) {
            jsb.reflection.callStaticMethod("Umeng", "init:channel:", config.Um_appkey_ios, config.Um_channel);
        }
    },
    event(e, parm) {
        //计数统计
        //e：事件名称
        //pram参数可以不传
        var parmstr = '';
        if (parm && Object.keys(parm).length > 0) parmstr = JSON.stringify(parm);
        //console.log('um:', e, parm);
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Umeng", "eventCount", "(Ljava/lang/String;Ljava/lang/String;)V", e, parmstr);
        } else if (cc.sys.platform == cc.sys.IPHONE || cc.sys.platform == cc.sys.IPAD) {
            jsb.reflection.callStaticMethod("Umeng", "eventCount:other:", e, parmstr);
        } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            wx.uma && wx.uma.trackEvent(e + '', parm);
        }
    },
    eventValue(e, parm, dt) {
        //计算统计
        //e：事件名称
        //pram:必须传，不能为空对象
        var parmstr = '';
        if (parm && Object.keys(parm).length > 0) parmstr = JSON.stringify(parm);
        else return;
        if (cc.sys.platform == cc.sys.ANDROID) {
            console.log('--event value');
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Umeng", "eventValue", "(Ljava/lang/String;Ljava/lang/String;I)V", e, parmstr, dt);
        }
    }
}
