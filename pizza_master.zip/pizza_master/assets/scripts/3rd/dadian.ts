export const getDadian = function (key: keyof typeof dadian): number {
	if (dadian[key]) {
		return dadian[key].number;
	}
	cc.error(`打点key: ${key} 不存在，请检查dadian表！`);
}
export const dadian = {
	"first_mian": {
		"id": "first_mian",
		"number": 1,
		"zh": "首次进入游戏主界面",
		"desc": "新手（只要没打过这个点，就算新手）"
	},
	"first_talk": {
		"id": "first_talk",
		"number": 2,
		"zh": "首次展示对话"
	},
	"first_cook": {
		"id": "first_cook",
		"number": 3,
		"zh": "首次进入做饼界面"
	},
	"first_miantuan": {
		"id": "first_miantuan",
		"number": 4,
		"zh": "完成放面团引导"
	},
	"first_tanbing": {
		"id": "first_tanbing",
		"number": 5,
		"zh": "完成摊饼引导"
	},
	"first_dadan": {
		"id": "first_dadan",
		"number": 6,
		"zh": "完成打鸡蛋引导"
	},
	"first_tandan": {
		"id": "first_tandan",
		"number": 7,
		"zh": "完成摊鸡蛋引导"
	},
	"first_fanmian": {
		"id": "first_fanmian",
		"number": 8,
		"zh": "完成煎饼翻面"
	},
	"first_tujiang": {
		"id": "first_tujiang",
		"number": 9,
		"zh": "完成涂酱料"
	},
	"first_bocui": {
		"id": "first_bocui",
		"number": 10,
		"zh": "完成放薄脆"
	},
	"first_zuzhuang": {
		"id": "first_zuzhuang",
		"number": 11,
		"zh": "完成煎饼组装"
	},
	"first_zhuangdai": {
		"id": "first_zhuangdai",
		"number": 12,
		"zh": "完成煎饼放入纸袋"
	},
	"first_jiaofu": {
		"id": "first_jiaofu",
		"number": 13,
		"zh": "完成煎饼交付给客人"
	},
	"end_1day": {
		"id": "end_1day",
		"number": 14,
		"zh": "进入第1天结算",
		"desc": "活跃用户"
	},
	"begin_2day": {
		"id": "begin_2day",
		"number": 32,
		"zh": "开启第2天"
	},
	"end_2day": {
		"id": "end_2day",
		"number": 33,
		"zh": "进入第2天结算"
	},
	"begin_3day": {
		"id": "begin_3day",
		"number": 34,
		"zh": "开启第3天"
	},
	"end_3day": {
		"id": "end_3day",
		"number": 35,
		"zh": "进入第3天结算"
	},
	"begin_4day": {
		"id": "begin_4day",
		"number": 36,
		"zh": "开启第4天"
	},
	"end_4day": {
		"id": "end_4day",
		"number": 37,
		"zh": "进入第4天结算"
	},
	"begin_5day": {
		"id": "begin_5day",
		"number": 38,
		"zh": "开启第5天"
	},
	"end_5day": {
		"id": "end_5day",
		"number": 39,
		"zh": "进入第5天结算"
	},
	"begin_6day": {
		"id": "begin_6day",
		"number": 40,
		"zh": "开启第6天"
	},
	"begin_7day": {
		"id": "begin_7day",
		"number": 41,
		"zh": "开启第7天"
	},
	"begin_8day": {
		"id": "begin_8day",
		"number": 42,
		"zh": "开启第8天"
	},
	"begin_9day": {
		"id": "begin_9day",
		"number": 43,
		"zh": "开启第9天"
	},
	"begin_10day": {
		"id": "begin_10day",
		"number": 44,
		"zh": "开启第10天"
	},
	"begin_15day": {
		"id": "begin_15day",
		"number": 45,
		"zh": "开启第15天"
	},
	"begin_20day": {
		"id": "begin_20day",
		"number": 46,
		"zh": "开启第20天"
	},
	"begin_25day": {
		"id": "begin_25day",
		"number": 47,
		"zh": "开启第25天"
	},
	"begin_30day": {
		"id": "begin_30day",
		"number": 48,
		"zh": "开启第30天"
	},
	"begin_40day": {
		"id": "begin_40day",
		"number": 49,
		"zh": "开启第40天"
	},
	"begin_50day": {
		"id": "begin_50day",
		"number": 50,
		"zh": "开启第50天"
	},
	"begin_60day": {
		"id": "begin_60day",
		"number": 51,
		"zh": "开启第60天"
	},
	"begin_70day": {
		"id": "begin_70day",
		"number": 52,
		"zh": "开启第70天"
	},
	"begin_80day": {
		"id": "begin_80day",
		"number": 53,
		"zh": "开启第80天"
	},
	"begin_90day": {
		"id": "begin_90day",
		"number": 54,
		"zh": "开启第90天"
	},
	"begin_100day": {
		"id": "begin_100day",
		"number": 55,
		"zh": "开启第100天"
	},
	"begin_150day": {
		"id": "begin_150day",
		"number": 56,
		"zh": "开启第150天"
	},
	"begin_200day": {
		"id": "begin_200day",
		"number": 57,
		"zh": "开启第200天"
	},
	"begin_250day": {
		"id": "begin_250day",
		"number": 58,
		"zh": "开启第250天"
	},
	"unlock_cailiao_1": {
		"id": "unlock_cailiao_1",
		"number": 101,
		"zh": "解锁辣椒酱"
	},
	"unlock_cailiao_2": {
		"id": "unlock_cailiao_2",
		"number": 102,
		"zh": "解锁榴莲酱"
	},
	"unlock_cailiao_3": {
		"id": "unlock_cailiao_3",
		"number": 103,
		"zh": "解锁烤肉酱"
	},
	"unlock_cailiao_4": {
		"id": "unlock_cailiao_4",
		"number": 104,
		"zh": "解锁肉松"
	},
	"unlock_cailiao_5": {
		"id": "unlock_cailiao_5",
		"number": 105,
		"zh": "解锁鸡柳"
	},
	"unlock_cailiao_6": {
		"id": "unlock_cailiao_6",
		"number": 106,
		"zh": "解锁培根"
	},
	"unlock_cailiao_7": {
		"id": "unlock_cailiao_7",
		"number": 107,
		"zh": "解锁香肠"
	},
	"unlock_cailiao_8": {
		"id": "unlock_cailiao_8",
		"number": 108,
		"zh": "解锁虾仁"
	},
	"unlock_cailiao_9": {
		"id": "unlock_cailiao_9",
		"number": 109,
		"zh": "解锁鱿鱼"
	},
	"unlock_cailiao_10": {
		"id": "unlock_cailiao_10",
		"number": 110,
		"zh": "解锁辣条"
	},
	"unlock_cailiao_11": {
		"id": "unlock_cailiao_11",
		"number": 111,
		"zh": "解锁生菜"
	},
	"unlock_cailiao_12": {
		"id": "unlock_cailiao_12",
		"number": 112,
		"zh": "解锁韭菜"
	},
	"unlock_cailiao_13": {
		"id": "unlock_cailiao_13",
		"number": 113,
		"zh": "解锁土豆丝"
	},
	"unlock_cailiao_14": {
		"id": "unlock_cailiao_14",
		"number": 114,
		"zh": "解锁臭豆腐"
	},
	"unlock_cailiao_15": {
		"id": "unlock_cailiao_15",
		"number": 115,
		"zh": "解锁芒果"
	},
	"unlock_cailiao_16": {
		"id": "unlock_cailiao_16",
		"number": 116,
		"zh": "解锁海带丝"
	},
	"unlock_cailiao_17": {
		"id": "unlock_cailiao_17",
		"number": 117,
		"zh": "解锁紫菜"
	},
	"unlock_cailiao_18": {
		"id": "unlock_cailiao_18",
		"number": 118,
		"zh": "解锁芝麻"
	},
	"unlock_cailiao_19": {
		"id": "unlock_cailiao_19",
		"number": 119,
		"zh": "解锁葱花"
	},
	"unlock_cailiao_20": {
		"id": "unlock_cailiao_20",
		"number": 120,
		"zh": "解锁香菜"
	},
	"unlock_bing_1": {
		"id": "unlock_bing_1",
		"number": 121,
		"zh": "解锁原味煎饼果子"
	},
	"unlock_bing_2": {
		"id": "unlock_bing_2",
		"number": 122,
		"zh": "解锁夏威夷肉松煎饼"
	},
	"unlock_bing_3": {
		"id": "unlock_bing_3",
		"number": 123,
		"zh": "解锁辣条煎饼"
	},
	"unlock_bing_4": {
		"id": "unlock_bing_4",
		"number": 124,
		"zh": "解锁辣条肉松煎饼"
	},
	"unlock_bing_5": {
		"id": "unlock_bing_5",
		"number": 125,
		"zh": "解锁绝味鸡柳煎饼"
	},
	"unlock_bing_6": {
		"id": "unlock_bing_6",
		"number": 126,
		"zh": "解锁菜鸡煎饼"
	},
	"unlock_bing_7": {
		"id": "unlock_bing_7",
		"number": 127,
		"zh": "解锁臭豆腐煎饼"
	},
	"unlock_bing_8": {
		"id": "unlock_bing_8",
		"number": 128,
		"zh": "解锁豆鸡煎饼"
	},
	"unlock_bing_9": {
		"id": "unlock_bing_9",
		"number": 129,
		"zh": "解锁又汇肠肉松煎饼"
	},
	"unlock_bing_10": {
		"id": "unlock_bing_10",
		"number": 130,
		"zh": "解锁小紫菜鸡煎饼"
	},
	"unlock_bing_11": {
		"id": "unlock_bing_11",
		"number": 131,
		"zh": "解锁培根鸡柳煎饼"
	},
	"unlock_bing_12": {
		"id": "unlock_bing_12",
		"number": 132,
		"zh": "解锁虾仁培根煎饼"
	},
	"unlock_bing_13": {
		"id": "unlock_bing_13",
		"number": 133,
		"zh": "解锁虾鸡煎饼"
	},
	"unlock_bing_14": {
		"id": "unlock_bing_14",
		"number": 134,
		"zh": "解锁海鲜豆腐煎饼"
	},
	"unlock_bing_15": {
		"id": "unlock_bing_15",
		"number": 135,
		"zh": "全家福豪华煎饼"
	},
	"unlock_drink": {
		"id": "unlock_drink",
		"number": 136,
		"zh": "饮料区ui完成解锁"
	},
	"click_drink": {
		"id": "click_drink",
		"number": 137,
		"zh": "饮料区点击"
	},
	"unlock_morecareer": {
		"id": "unlock_morecareer",
		"number": 138,
		"zh": "分店经营ui完成解锁"
	},
	"click_morecareer": {
		"id": "click_morecareer",
		"number": 139,
		"zh": "分店经营点击"
	},
	"each_bookzs": {
		"id": "each_bookzs",
		"number": 140,
		"zh": "图鉴领钻石"
	},
	"unlock_decorate_1": {
		"id": "unlock_decorate_1",
		"number": 141,
		"zh": "解锁装扮遮阳门"
	},
	"unlock_decorate_3": {
		"id": "unlock_decorate_3",
		"number": 142,
		"zh": "解锁装扮毛粉圈绒地板"
	},
	"unlock_decorate_5": {
		"id": "unlock_decorate_5",
		"number": 143,
		"zh": "解锁装扮粉菱格墙纸"
	},
	"unlock_decorate_7": {
		"id": "unlock_decorate_7",
		"number": 144,
		"zh": "解锁装扮实木柜台"
	},
	"unlock_decorate_9": {
		"id": "unlock_decorate_9",
		"number": 145,
		"zh": "解锁装扮猫猫门牌"
	},
	"unlock_decorate_11": {
		"id": "unlock_decorate_11",
		"number": 146,
		"zh": "解锁装扮吊灯天花板"
	},
	"unlock_decorate_13": {
		"id": "unlock_decorate_13",
		"number": 147,
		"zh": "解锁装扮粉格窗帘"
	},
	"unlock_decorate_14": {
		"id": "unlock_decorate_14",
		"number": 148,
		"zh": "解锁装扮小熊猫地毯"
	},
	"unlock_decorate_15": {
		"id": "unlock_decorate_15",
		"number": 149,
		"zh": "解锁装扮娃娃机"
	},
	"unlock_decorate_16": {
		"id": "unlock_decorate_16",
		"number": 150,
		"zh": "解锁装扮扭蛋机"
	},
	"unlock_decorate_17": {
		"id": "unlock_decorate_17",
		"number": 151,
		"zh": "解锁装扮公主椅前"
	},
	"unlock_decorate_18": {
		"id": "unlock_decorate_18",
		"number": 152,
		"zh": "解锁装扮公主椅后"
	},
	"unlock_decorate_19": {
		"id": "unlock_decorate_19",
		"number": 153,
		"zh": "解锁装扮花挂画"
	},
	"unlock_decorate_20": {
		"id": "unlock_decorate_20",
		"number": 154,
		"zh": "解锁装扮绿植"
	},
	"unlock_decorate_21": {
		"id": "unlock_decorate_21",
		"number": 155,
		"zh": "解锁装扮彩虹海报"
	},
	"unlock_decorate_22": {
		"id": "unlock_decorate_22",
		"number": 156,
		"zh": "解锁装扮猫饼袋"
	},
	"specialnpc": {
		"id": "specialnpc",
		"number": 157,
		"zh": "特殊客人出现"
	},
	"video_play": {
		"id": "video_play",
		"number": 201,
		"zh": "所有视频口播放",
		"desc": "视频"
	},
	"video_success": {
		"id": "video_success",
		"number": 202,
		"zh": "所有视频口完成播放"
	},
	"video_play_pc": {
		"id": "video_play_pc",
		"number": 203,
		"zh": "破产加金币视频播放"
	},
	"video_success_pc": {
		"id": "video_success_pc",
		"number": 204,
		"zh": "破产加金币视频完成播放"
	},
	"video_play_fb": {
		"id": "video_play_fb",
		"number": 205,
		"zh": "经营收入翻倍视频播放"
	},
	"video_success_fb": {
		"id": "video_success_fb",
		"number": 206,
		"zh": "经营收入翻倍视频完成播放"
	},
	"video_play_zs": {
		"id": "video_play_zs",
		"number": 207,
		"zh": "钻石获取视频播放"
	},
	"video_success_zs": {
		"id": "video_success_zs",
		"number": 208,
		"zh": "钻石获取视频完成播放"
	},
	"video_play_jb": {
		"id": "video_play_jb",
		"number": 209,
		"zh": "金币补充视频播放"
	},
	"video_success_jb": {
		"id": "video_success_jb",
		"number": 210,
		"zh": "金币补充视频完成播放"
	},
	"video_play_wx": {
		"id": "video_play_wx",
		"number": 211,
		"zh": "维修炉子视频播放"
	},
	"video_success_wx": {
		"id": "video_success_wx",
		"number": 212,
		"zh": "维修炉子视频完成播放"
	},
	"video_play_sm": {
		"id": "video_play_sm",
		"number": 213,
		"zh": "第2次点什么视频播放"
	},
	"video_success_sm": {
		"id": "video_success_sm",
		"number": 214,
		"zh": "第2次点什么视频完成播放"
	},
	"video_play_bookzs": {
		"id": "video_play_bookzs",
		"number": 215,
		"zh": "图鉴钻石多倍领取视频播放"
	},
	"video_success_bookzs": {
		"id": "video_success_bookzs",
		"number": 216,
		"zh": "图鉴钻石多倍领取完成播放"
	},
	"video_play_decorate_1": {
		"id": "video_play_decorate_1",
		"number": 217,
		"zh": "解锁装扮遮阳门视频播放"
	},
	"video_success_decorate_1": {
		"id": "video_success_decorate_1",
		"number": 218,
		"zh": "解锁装扮遮阳门完成播放"
	},
	"video_play_decorate_7": {
		"id": "video_play_decorate_7",
		"number": 219,
		"zh": "解锁装扮实木柜台视频播放"
	},
	"video_success_decorate_7": {
		"id": "video_success_decorate_7",
		"number": 220,
		"zh": "解锁装扮实木柜台完成播放"
	},
	"video_play_decorate_14": {
		"id": "video_play_decorate_14",
		"number": 221,
		"zh": "解锁装扮熊猫地毯视频播放"
	},
	"video_success_decorate_14": {
		"id": "video_success_decorate_14",
		"number": 222,
		"zh": "解锁装扮熊猫地毯完成播放"
	},
	"video_play_decorate_15": {
		"id": "video_play_decorate_15",
		"number": 223,
		"zh": "解锁装扮娃娃机视频播放"
	},
	"video_success_decorate_15": {
		"id": "video_success_decorate_15",
		"number": 224,
		"zh": "解锁装扮娃娃机完成播放"
	},
	"video_play_specialnpc": {
		"id": "video_play_specialnpc",
		"number": 225,
		"zh": "特殊客人视频播放"
	},
	"video_success_specialnpc": {
		"id": "video_success_specialnpc",
		"number": 226,
		"zh": "特殊客人完成播放"
	}
}