var debug = false;

export const Http = {
    request(url, succ, fail) {
        var xhr = cc.loader.getXMLHttpRequest();
        var url = url;
        if (debug) console.log('httpRequest:', url);
        xhr.onerror = function () {
            if (fail) fail();
            fail = null;
            if (debug) console.log('request error');
        }
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                var response = xhr.responseText;
                if (succ) succ(response);
                if (debug) console.log('request revc:', response);
            } else if (xhr.status != 0 && xhr.status != 200) {
                if (fail) fail();
                fail = null;
                if (debug) console.log("remote err:", xhr.status);
            }
        };
        // console.log('req:',url);
        xhr.open("GET", url, true);
        xhr.send();
    },

    requestAsync(url):any {
        return new Promise((resolve, reject) => {
            this.request(url, resolve, reject)
        })
    },

    post(url, body, succ, fail) {
        var xhr = cc.loader.getXMLHttpRequest();
        if (debug) console.log('httpPost:', url);
        xhr.onerror = function () {
            if (fail) fail();
            fail = null;
            if (debug) console.log('post error');
        }
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status >= 200 && xhr.status < 400) {
                    var response = xhr.responseText;
                    if (debug) console.log('post revc:', response);
                    if (succ) succ(response);
                } else if (xhr.status != 0 && xhr.status != 200) {
                    if (fail) fail();
                    fail = null;
                    if (debug) console.log("remote err:", xhr.status);
                }
            }
        };
        xhr.open("POST", url, true);
        if (debug) console.log('httpPost:', url, body);
        if (body) {
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.send(body);
        } else {
            xhr.send();
        }
    }
}