var _Android_PACKAGE = "org/cocos2dx/javascript/toponAd/";

export const Ad_topon = {
    ad: null,
    init() {
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {

        } else if (cc.sys.platform == cc.sys.ANDROID) {

        }
    },

    preload(data) {
        if (data.banner) {
            data.banner.forEach(k => {
                this.loadBanner(k);
            })
        }
        if (data.video) {
            data.video.forEach(k => {
                this.loadVideo(k);
            })
        }

        if (data.fullScreen) {
            data.fullScreen.forEach(k => {
                this.loadFullScreen(k);
            })
        }

        setTimeout(() => {
            if (data.insert) {
                data.insert.forEach(k => {
                    this.loadInsert(k);
                })
            }
        }, 100)

        if (data.nativeEx) {
            data.nativeEx.forEach(k => {
                this.loadNativeExpress(k);
            })
        }
        this._data = data;
    },
    //---BANNER---START
    loadBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "load", "(Ljava/lang/String;)V", slotID);
        }
    },

    playBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("BUDad", "playBanner:", "915435021");
        }
    },

    isLoadedBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
    },

    closeBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "close", "(Ljava/lang/String;)V", slotID);
        }
    },

    bannerCall(onCode, result) {

    },
    //---BANNER---END
    //---VIDEO---START
    loadVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
        return true;
    },

    playVideo(callback, slotID) {
        this.vc = callback;
        this._videoRewardFlag = false;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }

    },

    _videoReward() {
        if (this.vc) {
            setTimeout(() => {
                if (this.vc) {
                    this.vc(this.ad.CODE.ON_AWARD_SUCC);
                    this.vc = null;
                }
            }, 200)
        }
    },

    videoCall(onCode, result) {
        this.vlock = null;
        if (onCode == this.ad.CODE.ON_AWARD_SUCC) {
            this._videoRewardFlag = true;
            // this._videoReward();
        } else if (onCode == this.ad.CODE.ON_SHOW) {
            if (this.vc) this.vc(onCode, result);
            this._videoShowTime = Date.now();
        } else if (onCode == this.ad.CODE.ON_CLOSE) {
            if (this._videoRewardFlag || (Date.now() - this._videoShowTime > 5000)) {
                this._videoRewardFlag = false;
                this._videoShowTime = 9597990206708;
                this._videoReward();
            }
            if (this.vc) this.vc(onCode, result);
        } else if (onCode == this.ad.CODE.ON_ERROR) {

        } else if (onCode == this.ad.CODE.ON_READY) {

        } else if (onCode == this.ad.CODE.ON_REQUEST) {
            
        } else {
            if (this.vc) this.vc(onCode, result);
        }
    },
    //---VIDEO---END
    //---INSERT---START
    loadInsert(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedInsert(slotID = "") {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
    },

    playInsert(callback, slotID = "", cnt) {
        this._insertCb = callback;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "play", "(Ljava/lang/String;I)V", slotID, cnt);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }
    },

    insertCall(onCode, result) {
        if (onCode == this.ad.CODE.ON_CLOSE) {
        }
    },
    //---INSERT---END
    //---FULLSCREEN---START
    loadFullScreen(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedFullScreen(slotID = "") {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
    },

    playFullScreen(callback, slotID = "") {
        this._fullScreenCb = callback;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }

    },

    fullScreenCall(onCode, result) {
        if (onCode == this.ad.CODE.ON_CLOSE) {
            if (this._fullScreenCb) this._fullScreenCb(onCode, result);
            this._fullScreenCb = null;
        }
    },
    //---FULLSCREEN---END
    //---NATIVE_EXPRESS---START
    loadNativeExpress(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
    },

    playNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }

    },

    closeNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "close", "(Ljava/lang/String;)V", slotID);
        }
    },

    nativeExpressCall(onCode, result) {
        if (onCode == this.ad.CODE.ON_CLOSE) {

        }
    },
    //---NATIVE_EXPRESS---END
}

window["__TopOn"] = {
    adCall(onCode, ptype, result) {
        console.log('__TopOn:', ptype, onCode, result);
        if (ptype == 'banner') {
            Ad_topon.bannerCall(onCode, result);
        } else if (ptype == 'video') {
            Ad_topon.videoCall(onCode, result);
        } else if (ptype == 'insert') {
            Ad_topon.insertCall(onCode, result);
        } else if (ptype == 'fullscreen') {
            Ad_topon.fullScreenCall(onCode, result);
        } else if(ptype == 'nativeExpress'){
            Ad_topon.nativeExpressCall(onCode, result);
        }
    }
}