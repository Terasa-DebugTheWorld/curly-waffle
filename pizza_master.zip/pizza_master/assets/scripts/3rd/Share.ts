import { ClientEvent } from "../common/ClientEvent";
import { HttpServer } from "./HttpServer";
import { WeixinAPI } from "./WeixinAPI";
import { Assist } from "./Assist";

//分享ext传进来的对象属性名称定死
//title 标题
//content 内容
//imageUrl 图片

var _judgeRound = 0;
var _needJudge = false;
var _judge = {
    0: { percent: 80, tips: "不要总骚扰这个群，换个群分享吧" },
    1: { percent: 80, tips: "这个群发过啦，换个群邀请好友来玩吧" },
    2: { percent: 100, tips: "再发就刷屏啦~换个群试试吧" }
}
var _tempJudge = _judge[0];

export const Share = {
    share(succ, fail, ext) {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            _needJudge = true;
            this.__wxShare(succ, fail, ext);
        } else {
            if (succ) succ();
        }
        
    },
    __wxShare(succ, fail, ext) {
        if (!this._wxOnShowInit) {
            ClientEvent.on('wxOnShow', this._wxOnShow, this);
        }
        this._wxOnShowInit = true;
        wx.shareAppMessage({
            title: ext.title,
            imageUrl: ext.imageUrl,
        })
        this._wxShareStart = (new Date()).getTime();
        this._wxShareCb = succ;
        this._wxExt = ext;
        this._wxShareFail = fail;
    },
    _wxOnShow(res) {
        var self = this;
        if (this._wxShareStart > 0) {
            let nowTime = (new Date()).getTime();
            console.log('分享间隔 :', nowTime - this._wxShareStart);
            if (nowTime - this._wxShareStart >= HttpServer.getConfig().shareSuccTime) {
                this._doSucc();
            } else {
                this._doFail(_tempJudge.tips);
            }
            this._wxShareStart = null;
        }
    },
    _doSucc() {
        if (_needJudge == true) {
            let round = _judgeRound++ % 3;
            let info = _judge[round] || _judge[2];
            console.log(round, info);
            let judgeRlt = Assist.judgeRandom(info.percent);
            if (judgeRlt == true) {
                if (this._wxShareCb) this._wxShareCb();
                this._wxShareCb = null;
            } else {
                this._doFail(info.tips);
            }
            _tempJudge = info;
            _needJudge = false;
            return;
        }
        if (this._wxShareCb) this._wxShareCb();
        this._wxShareCb = null;
        this._wxShareFail = null;
    },
    _doFail(tips = '别总骚扰这个群，换个群分享吧~') {
        let self = this;
        wx.showModal({
            title: '提示',
            content: tips,
            showCancel: true,
            success(res) {
                if (res.confirm) {
                    console.log('用户点击确定')
                    self.__wxShare(self._wxShareCb, self._wxShareFail, self._wxExt)
                } else if (res.cancel) {
                    console.log('用户点击取消')
                    if (self._wxShareFail) self._wxShareFail();
                }
            }
        })
    }

}