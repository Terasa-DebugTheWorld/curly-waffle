import { Ad } from "../3rd/Ad";
import { ClientEvent } from "../common/ClientEvent";
import { Glb } from "../Glb";

const SDK_ENABLE = Glb.xg;
const XunguangSDK = new class {
    isInit = false;
    openId = '';
    EventType = {
        AUTH: 1,
        CUSTOM: 2,
        VIDEO: 3,
        SHARE: 4,
        DEEP: 5
    }
    init(callback?) {
        if (!SDK_ENABLE) return;
        if (cc.sys.platform != cc.sys.WECHAT_GAME) {
            callback && callback();
            return;
        }
        //在游戏入口文件对sdk进行初始化并获取openid
        wx.xgSdkInit((openid) => {
            // 初始化可获取用户openid，用于登录使用
            this.isInit = true;
            this.openId = openid;
            console.log('wx.xgsdkinit succ, openid: ' + openid)
            callback && callback(openid);
            this.event(this.EventType.AUTH);
        });

        ClientEvent.on('adVideo', (data) => {
            let key = data.key;
            let code = data.code;
            if (code == Ad.CODE.ON_AWARD_SUCC) {
                this.event(this.EventType.VIDEO);
            }
        })
    }

    event(type, name?) {
        if (!SDK_ENABLE) return;
        if (cc.sys.platform != cc.sys.WECHAT_GAME) {
            return;
        }
        switch (type) {
            case this.EventType.AUTH:
                wx.dot.auth();
                break;
            case this.EventType.CUSTOM:
                wx.dot.send(name);
                break;
            case this.EventType.VIDEO:
                wx.dot.videoCount();
                break;
            case this.EventType.SHARE:
                wx.dot.shareCount();
                break;
            case this.EventType.DEEP:
                wx.dot.deepAuth();
                break;
            default:
                break;
        }
    }
};

export default XunguangSDK;