// import { Ad_toponAdapter } from "./Ad_toponAdapter";
import { ClientEvent } from "../common/ClientEvent";
import { Analysis } from './Analysis';
import { ad_wx } from './ad-wx';
import { AudioHelper } from "../common/AudioHelper";
import { ad_byte } from "./ad_byte";
import { MyToponSDKAdapter } from "./ad-topon-sdk/MyToponSDKAdapter";
import { ThirdType } from "./ThirdType";
import { Ad_toponAdapter } from "./Ad_toponAdapter";
import { Ad_bud } from "./Ad_bud";

var adService = null;

if (cc.sys.platform == cc.sys.ANDROID) {
    // adService = Ad_toponAdapter;
} else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
    adService = Ad_bud;// MyToponSDKAdapter;
} else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
    adService = ad_wx;
} else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
    adService = ad_byte;
}

export const Ad = {
    CODE: ThirdType.AD_CODE,
    init() {
        if (adService == null) return;
        adService.init();
        if (!cc.sys.localStorage.getItem("__opened") && (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE)) {
            console.log('ios首次打开不预加载');
        } else {
            this.preload();
        }
    },
    preload() {
        if (adService == null) return;
        cc.sys.localStorage.setItem("__opened", "1");
        adService.preload && adService.preload();
    },
    iosFirstPreload() {
        if (!cc.sys.localStorage.getItem("__opened") && (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE)) {
            console.log('ios首次预加载');
            this.preload();
        }
    },
    getAdService() {
        return adService;
    },
    playBanner() {
        //播放横幅
        if (adService == null) return;
        adService.playBanner();
    },
    closeBanner(stopAuto = false) {
        //关闭横幅
        //stopAuto控制同时关闭自动切换
        if (adService == null) return;
        adService.closeBanner();
        if (stopAuto == true) {
            this.stopAutoBanner();
        }
    },
    hideBanner() {
        if (adService == null) return;
        adService.hideBanner();
    },
    autoBanner(time = 80) {
        //自动切换，time是秒
        if (adService == null) return;
        if (this.bannerTime > 0) time = this.bannerTime;
        this.bannerTime = time;
        adService.autoBanner(time);
    },
    stopAutoBanner() {
        //关闭切换
        if (adService == null) return;
        adService.stopAutoBanner();
    },
    playVideo(callback, key?) {
        //播放视频
        //callback(onCode,result) onCode对应ad.CODE,result是额外信息
        if (adService == null) {
            callback && callback(this.CODE.ON_SHOW, key);
            setTimeout(() => { callback && callback(this.CODE.ON_AWARD_SUCC, key); }, 100);
            setTimeout(() => { callback && callback(this.CODE.ON_CLOSE, key); }, 200);
            return true;
        }
        return adService.playVideo(callback, key);
    },
    playInsert(callback = null, cnt = 1) {
        //播放插屏
        if (adService == null) return;
        return adService.playInsert(callback, cnt);
    },
    playFullScreen(callback = null) {
        if (adService == null) {
            cc.log('播放全屏视频')
            if (callback) callback(this.CODE.ON_CLOSE);
            return;
        }
        //require('./businessManager')._lastInsertTime = Date.now();
        let selfCallBack = (code, result) => {
            if (code == this.CODE.ON_CLOSE) {
                AudioHelper.resumeBgm();
                ClientEvent.dispatch('AdFsOnClose', true);
            } else if (code == this.CODE.ON_SHOW) {
                AudioHelper.pauseBgm();
                ClientEvent.dispatch('AdFsOnShow', true);
            } else if (code == this.CODE.ON_READY) {
                ClientEvent.dispatch('AdFsOnReady', true);
            }
            if (callback) callback(code, result);
        }
        let rlt = adService.playFullScreen(selfCallBack);
        return rlt;
    },
    playNativeExpress() {
        if (adService == null || !adService.playNativeExpress) return;
        return adService.playNativeExpress();
    },
    closeNativeExpress() {
        if (adService == null || !adService.closeNativeExpress) return;
        return adService.closeNativeExpress();
    },

    playSplash() {
        if (adService == null) return;
        adService.playSplash && adService.playSplash();
    }
}

if (adService) adService.ad = Ad;