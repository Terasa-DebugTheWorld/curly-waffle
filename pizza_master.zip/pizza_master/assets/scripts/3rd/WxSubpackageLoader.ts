import EventListener from "../common/EventListener";

export const WxSubpackageLoader = new class {
    package = {
        watermelon: "watermelon",
        dropFish: "dropFish",
        chicken: "chicken",
        monster: "monster"
    }
    private listener = new EventListener()
    private loadedMarks: { [key: string]: boolean } = {}
    public loadSubpackage(num: string, progressCallback: (progress: number) => void, completeCallback: () => void) {
        if (this.bundles[num]) {
            console.log("subpackge has loaed", num);
            return;
        }
        console.log("load subpackge", num);
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            //@ts-ignore
            const loadTask = wx.loadSubpackage({
                name: num,
                success: () => {
                    cc.assetManager.loadBundle(num, (err, bundle) => {
                        if (err) {
                            console.error(err);
                        }
                        this.loadedMarks[num] = true;
                        this.bundles[num] = bundle;
                        this.listener.dispatch(num, null);
                        console.log('subpackage loaded: ' + num)
                        if (completeCallback) completeCallback();
                    });
                },
                fail: (err) => {
                    this.loadSubpackage(num, progressCallback, completeCallback);
                    console.error(err);
                },
                complete: () => { }
            });
            loadTask.onProgressUpdate(res => {
                if (progressCallback) progressCallback(res.progress);
            });
        } else {
            cc.assetManager.loadBundle(num, (err, bundle) => {
                if (err) {
                    console.error(err);
                }
                this.loadedMarks[num] = true;
                this.bundles[num] = bundle;
                this.listener.dispatch(num, null);
                if (completeCallback) completeCallback();
            });
        }
    }

    public loadSubpackageAsync(name) {
        return new Promise((resolve, reject) => {
            this.loadSubpackage(name, null, () => {
                resolve(null);
            })
        })
    }

    public isSubpackageLoaded(num: number): boolean {
        return !!this.loadedMarks[num];
    }

    private bundles: { [key: number]: cc.AssetManager.Bundle } = {}
    public getBundle(number): cc.AssetManager.Bundle {
        return this.bundles[number];
    }
    private _load<T extends typeof cc.Asset>(num: string, type: T, url: string): Promise<InstanceType<T>> {
        if (num == 'resources') {
            //@ts-ignore
            return new Promise(resl => cc.resources.load(url, type, null, (err, asset) => resl(asset)));
        }
        if (!this.loadedMarks[num]) {
            return new Promise(resl => {
                this.listener.on(num, async () => {
                    const asset = await this._load(num, type, url);
                    resl(asset);
                }, this, true);
            })
        }
        const bundle = this.bundles[num];
        const res = bundle.get(url, type) as InstanceType<T>;
        if (res) {
            return Promise.resolve(res);
        } else {
            return new Promise(resl => {
                bundle.load(url, type, (err, asset) => {
                    resl(asset as InstanceType<T>);
                });
            });
        }
    }
    // public loadSpriteFrame(num: number, url: string): Promise<cc.SpriteFrame> {
    //     return this._load(num, cc.SpriteFrame, url);
    // }

    public loadSpriteFrame(bundleName: string, url: string): Promise<cc.SpriteFrame> {
        return this._load(bundleName, cc.SpriteFrame, url);
        return new Promise(resl => {
            cc.assetManager.getBundle(bundleName).load(url, cc.SpriteFrame, (err, asset) => {
                resl(asset as any);
            });
        });
    }

    public loadSpine(bundleName: string, url: string): Promise<sp.SkeletonData> {
        return this._load(bundleName, sp.SkeletonData, url);
        return new Promise(resl => {
            cc.assetManager.getBundle(bundleName).load(url, sp.SkeletonData, (err, asset) => {
                resl(asset as any);
            });
        });
    }

    _assetsMap = {}
    public loadPrefab(bundleName: string, url: string): Promise<cc.Prefab> {
        if (this._assetsMap[bundleName] && this._assetsMap[bundleName][url]) {
            return Promise.resolve(this._assetsMap[bundleName][url]);
        }
        return this._load(bundleName, cc.Prefab, url);
        return new Promise(resl => {
            cc.assetManager.getBundle(bundleName).load(url, cc.Prefab, (err, asset) => {
                resl(asset as any);
                if (!this._assetsMap[bundleName]) this._assetsMap[bundleName] = {};
                this._assetsMap[bundleName][url] = asset;
            });
        });
    }

    public load<T extends cc.Asset>(bundleName: string, url: string, type: typeof cc.Asset): Promise<T> {
        return new Promise(resl => {
            cc.assetManager.getBundle(bundleName).load(url, type, (err: Error, asset: T) => {
                resl(asset);
            });
        });
    }
}