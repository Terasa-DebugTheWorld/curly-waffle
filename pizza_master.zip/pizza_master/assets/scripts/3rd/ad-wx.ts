import UserData from '../userdata/UserData';
import { ClientEvent } from '../common/ClientEvent';
import { System } from '../common/System';
import { WeixinAPI } from './WeixinAPI';
import { AD_WX_PARAMS } from './AdParams';
var unit = [AD_WX_PARAMS.Banner];//BANNER的广告位，字符串数组
var videoUnit = AD_WX_PARAMS.Video;//视频广告位
const shortVideoUnit = AD_WX_PARAMS.Video;   //短视频广告位
const interstitialAdUnit = AD_WX_PARAMS.Inter;//插屏广告位
const customAdUnit = AD_WX_PARAMS.SingleGrid;//原生模板广告
const customAdUnit2 = AD_WX_PARAMS.SingleGrid2;//原生模板广告2
const portCustAdUnit1 = '';//竖版原生模板广告1 
const portCustAdUnit2 = '';//竖版原生模板广告1
const gridAdUnit = '';//格子广告

export const ad_wx = {
    _bannerIndex: 0,
    _closeFlag: true,
    init() {
        this.createBanner();
    },
    getBannerUnit() {
        return unit[0];
    },
    getHomeCustomUnit(unit) {
        if (unit == 2) return customAdUnit2;
        return customAdUnit;
    },
    setBannerTop(y: number) {
        this.bannerTop = y;
    },
    getBannerCenterY(): number {
        const ba = this.bannerAd as wx.BannerAd;
        const h = ba ? this.bannerAd.style.realHeight : 300;
        const top = this.bannerTop == undefined ? h : this.bannerTop;
        return top - h / 2;
    },
    bannerTop: undefined,
    playBanner(unitId = -1) {
        //播放横幅
        if (!this.canBanner) {
            this.playBannerAfterUnblock = true;
            return;
        }
        this._closeFlag = false;
        if (unit.length == 0) return;
        if (this.bannerAd) {
            this.bannerAd.show().then(() => {
                this.onBannerShow();
            });
            return;
        }
        this.createBanner();
    },
    createBanner(unitId = -1) {
        if (unit.length == 0) return;
        if (this._bannerLoading) return;
        this._bannerLoading = true;
        if (!this.wxsystem) {
            this.wxsystem = wx.getSystemInfoSync();
            if (this.wxsystem) {
                const model = this.wxsystem.model;
                if (model && (String(model).indexOf('iPhone X') >= 0 || String(model).indexOf('unknown') >= 0 || String(model).indexOf('iPhone 11') >= 0)) {
                    this.iphoneX = true;
                }
            }
        }
        var ru = this.getBannerUnit();
        console.log('player banner:', unitId, ru);
        let w = this.wxsystem.windowWidth
        let bannerAd = wx.createBannerAd({
            adUnitId: ru,
            // adIntervals: 30,
            style: {
                left: 0,
                top: 0,
                width: w,
                height: 300,
            }
        })
        bannerAd.style.left = (this.wxsystem.windowWidth - w) / 2;
        bannerAd.style.width = w;
        bannerAd.style.top = this.wxsystem.windowHeight;
        bannerAd.onError((err) => {
            console.log('createBanner banner error:', err);
            // bannerAd.destroy();
            this.bannerAd = null;
            this._bannerLoading = false;
            ClientEvent.dispatch('wx_banner_error');
            // ClientEvent.dispatch('BannerError');
        })
        bannerAd.onLoad(() => {
            console.log('banner 广告加载成功')
            this._bannerLoading = false;
            this.bannerAd = bannerAd;
            if (!this._closeFlag) {
                this.lastTryShowDate = Date.now();
                let showSucc = false;
                // setTimeout(() => {
                //     if (!showSucc) {
                //         ClientEvent.dispatch('wx_banner_time_up');

                //     }
                // }, 1000);
                this.bannerAd.show().then(() => {
                    showSucc = true;
                    this.onBannerShow();
                });
            }
        })
        return bannerAd;
    },
    onBannerShow() {
        if (!this.canBanner) {
            this.bannerAd.hide();
        }
        let offsetY = 0;
        if (this.iphoneX) {
            offsetY = -this.wxsystem.statusBarHeight * 0.9;
        }
        let top = this.wxsystem.windowHeight - this.bannerAd.style.realHeight + offsetY;
        if (this.bannerTop != undefined) {
            top = WeixinAPI.world2WxSpace(cc.v3(0, this.bannerTop)).y;
        }
        this.bannerAd.style.top = top;
    },

    closeBanner(stopAuto = false) {
        //关闭横幅
        //stopAuto控制同时关闭自动切换
        this._closeFlag = true;
        if (this.bannerAd) {
            this.bannerAd.destroy();
            this.bannerAd = null;
            this.createBanner();
        }
    },
    bannerIsOn() {
        return !this._closeFlag;
    },
    hideBanner() {
        this.playBannerAfterUnblock = false;
        this._closeFlag = true;
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    },
    //内部自动刷新，不管是否在隐藏状态
    insideRefreshBanner(time) {
        if (this._insideRefreshBannerInter) return;
        this._insideRefreshBannerInter = setInterval(() => {
            // console.log('自动刷新banner')
            if (this.bannerAd) {
                this.bannerAd.destroy();
                this.bannerAd = null;
                this.createBanner();
            }
        }, time * 1000)
    },
    //----老版用于常驻的自动刷新
    autoBanner(time = 30) {
        //自动切换，time是秒
        if (unit.length == 0) return;
        var self = this;
        self.bannerIndex = 0;
        self.closeBanner();
        self.bannerAd = self.playBanner(self.bannerIndex);
        this.autoBannerInter = setInterval(() => {
            self.closeBanner();
            self.bannerIndex++;
            if (self.bannerIndex === unit.length) self.bannerIndex = 0;
            self.bannerAd = self.playBanner(self.bannerIndex);
        }, time * 1000);
    },
    stopAutoBanner() {
        //关闭切换
        if (this.autoBannerInter) {
            clearInterval(this.autoBannerInter);
            this.autoBannerInter = null;
        }
    },
    //------

    __VideoCall(res) {
        // 用户点击了【关闭广告】按钮
        // 小于 2.1.0 的基础库版本，res 是一个 undefined
        var self = this;
        console.log('video res: ', res);
        if (res && res.isEnded || res === undefined) {
            // 正常播放结束，可以下发游戏奖励
            console.log('video end succ');
            try {
                //mpsdk.Report.reportVideoTimeEvent();
            } catch (error) {

            }
            if (self.vc) self.vc(self.ad.CODE.ON_CLOSE);
            if (self.vc) self.vc(self.ad.CODE.ON_AWARD_SUCC);
            UserData.incr('videoCount');
        } else {
            wx.showToast({ title: '完整观看视频才能获得奖励哦！', icon: "none" });
            // 播放中途退出，不下发游戏奖励
            if (self.vc) self.vc(self.ad.CODE.ON_CLOSE);
            if (self.vc) self.vc(self.ad.CODE.ON_AWARD_FAIL, 'not complete');
        }
        self.vc = null;
    },

    playVideo(callback) {
        //播放视频
        //callback(onCode,result) onCode对应ad.CODE,result是额外信息
        // if (videoUnit.length == 0) return;
        var self = this;
        if (self.vlock && (Date.now() - self.vlock < 5000)) return;
        self.vc = callback;
        self.vlock = Date.now();

        let vu = videoUnit;
        if (UserData.get('videoCount') == 0) {
            vu = shortVideoUnit;
        }
        console.log('视频id:', vu);
        //提示
        wx.showToast({ title: '加载中' });
        let videoAd = wx.createRewardedVideoAd({
            adUnitId: vu
        });

        videoAd.onError((err) => {
            console.log('play video error', err);
            if (this.vc) this.vc(this.ad.CODE.ON_ERROR, '');
            this.vc = null;
            this.vlock = null;
        });

        videoAd.load().then(() => {
            videoAd.show().then(() => {
                if (self.vc) self.vc(self.ad.CODE.ON_SHOW);
            })
        }).catch(err => {
            console.log(err.errMsg);
            // if (self.vc) self.vc(self.ad.CODE.ON_ERROR, err);
            self.vc = null;
            self.vlock = null;
        })
        if (!self.vonc) {
            videoAd.onClose(res => {
                self.vlock = null;
                self.__VideoCall(res)
            })
            self.vonc = true;
        }
        return videoAd;
    },
    _lastInsert: null,
    playInsert(data?: { onShow?: Function, onClose?: Function, onError?: Function }) {
        let onShow, onClose, onError;
        if (data) {
            onShow = data.onShow;
            onClose = data.onClose;
            onError = data.onError;
        }
        if (!this.canInsert) return;
        if (cc.sys.isBrowser) {
            cc.log('插屏弹出');
            if (onShow) onShow();
            if (onClose) onClose();
            return;
        }
        // 定义插屏广告
        let interstitialAd = null
        const closeCb = () => {
            if (interstitialAd) interstitialAd.destroy();
            if (onClose) onClose();
        };
        const errorCb = () => {
            if (onError) onError();
        };

        // 创建插屏广告实例，提前初始化
        if (wx.createInterstitialAd) {
            interstitialAd = wx.createInterstitialAd({
                adUnitId: interstitialAdUnit
            });
        } else {
            errorCb();
            return;
        }
        if (interstitialAd) {
            // interstitialAd.load().then((msg) => {        //调load会报错，不知道什么鬼，反正不load也能播出来
            //     console.log('load interstitial succ');
            interstitialAd.onClose(closeCb);
            interstitialAd.onError(errorCb);
            interstitialAd.show().then((msg) => {
                console.log('now show interstitial');
                this._lastInsert = interstitialAd;
                if (onShow) onShow();
            }, (msg) => {
                console.log('show interstitial fail, msg: ', msg);
                errorCb();
            });
            // }, (msg) => {
            //     console.log('load interstitial fail, msg: ', msg);
            //     errorCb();
            // });
        } else {
            console.log("create interstitial ad fail");
            errorCb();
        }
    },
    closeInsert() {
        console.log('插屏：', this._lastInsert)
        if (this._lastInsert && this._lastInsert.destroy) {
            console.log('尝试销毁插屏');
            this._lastInsert.destroy();
        }
    },

    rightVideoUnit: videoUnit,
    switchVideoUnit() {
        if (videoUnit === '') {
            videoUnit = this.rightVideoUnit;
        } else {
            videoUnit = 'fuck';
        }
    },

    playCustomAd(data: { onShow: Function, onClose: Function, onError: Function }, position: cc.Vec3) {
        if (cc.sys.platform != cc.sys.WECHAT_GAME) {
            GameContext.instance.showFakeCustomAd();
            return;
        }
        if (!wx.createCustomAd) {
            GameContext.instance.showFakeCustomAd();
            data && data.onError && data.onError();
            return;
        }
        if (this.customAd) {
            this.customAd.show();
            data && data.onShow() && data.onShow();
            return;
        }
        this._customAdCloseFlag = false;
        if (this._customAdLoading) return;
        this._customAdLoading = true;
        let onShow, onClose, onError;
        if (data) {
            onShow = data.onShow;
            onClose = data.onClose;
            onError = data.onError;
        }

        let customAd = null
        const closeCb = () => {
            if (customAd) {
                customAd.destroy();
                this.customAd = null;
            }
            if (onClose) onClose();
        };
        const errorCb = () => {
            if (onError) onError();
        };

        if (!this.customLeft) {
            const wxsys: wx.systemInfo = this.wxsystem;
            const ch = cc.Canvas.instance.node.height;
            const cw = cc.Canvas.instance.node.width;
            this.customLeft = position.x * wxsys.windowWidth / cw;
            this.customTop = (ch - position.y) * wxsys.windowHeight / ch;
        }

        if (wx.createCustomAd) {
            customAd = wx.createCustomAd({
                adUnitId: customAdUnit,
                adIntervals: 60,
                style: {
                    left: this.customLeft,
                    top: this.customTop,
                    fixed: true,
                }
            });
        }
        if (customAd) {
            let showSucc = false;
            this.customAd = null;
            customAd.onClose(closeCb);
            customAd.onError(errorCb);
            customAd.show().then((msg) => {
                this._customAdLoading = false;
                showSucc = true;
                console.log('now show custom ad');
                this.customAd = customAd;
                if (this._customAdCloseFlag) {
                    this.closeCustomAd();
                } else {
                    if (onShow) onShow();
                }
            }, (msg) => {
                this._customAdLoading = false;
                this.customAd = null;
                console.log('show custom ad fail, msg: ', msg);
            });
        } else {
            console.log("create custom ad fail");
            errorCb();
        }
    },
    closeCustomAd() {
        this._customAdCloseFlag = true;
        if (this.customAd) {
            if (this.customAd.hide) {
                console.log('隐藏主页模板广告')
                this.customAd.hide()
            } else {
                this.customAd.destroy();
                this.customAd = null;
            }
        }
    },

    createGridAd(node: cc.Node, count: number = 8): any {
        // return {
        //     show: () => {
        //         return new Promise((resolve, reject) => {
        //             reject('没有这个接口')
        //         })
        //     },
        //     onError: (cb) => {
        //         cb && cb('没有这个接口');
        //     }
        // };
        if (cc.sys.platform != cc.sys.WECHAT_GAME) return;
        const rect = node.getBoundingBoxToWorld();
        const wxRect = WeixinAPI.cocosUI2WxUi(rect.center, rect);
        if (!wx.createCustomAd) {
            return {
                show: () => {
                    return new Promise((resolve, reject) => {
                        reject('没有这个接口')
                    })
                },
                onError: (cb) => {
                    cb && cb('没有这个接口');
                }
            };
        }
        const gridAd = wx.createCustomAd({
            adUnitId: gridAdUnit,
            adIntervals: 60,
            style: {
                left: wxRect.left,
                top: wxRect.top,
                width: wxRect.width
            }
        });
        // gridAd.onError(function (err) {  //onError会导致show().catch()抓不到错误，统一由catch来处理
        //     console.error('create grid ad error', err);
        // });
        console.log('created grid ad: ', gridAd);
        return gridAd;
    },

    createPortraitCustomAd(node: cc.Node, id: number): any {
        // return {
        //     show: () => {
        //         return new Promise((resolve, reject) => {
        //             reject('没有这个接口')
        //         })
        //     },
        //     onError: (cb) => {
        //         cb && cb('没有这个接口');
        //     }
        // };
        if (cc.sys.platform != cc.sys.WECHAT_GAME) return;
        if (!wx.createCustomAd) {
            return {
                show: () => {
                    return new Promise((resolve, reject) => {
                        reject('没有这个接口')
                    })
                },
                onError: (cb) => {
                    cb && cb('没有这个接口');
                }
            };
        }

        let adId = id == 0 ? portCustAdUnit1 : portCustAdUnit2;
        const rect = node.getBoundingBoxToWorld();
        const wxRect = WeixinAPI.cocosUI2WxUi(rect.center, rect);
        const pcad = wx.createCustomAd({
            adUnitId: adId,
            //adIntervals: 30,
            style: {
                left: wxRect.left,
                top: wxRect.top
            }
        });
        // pcad.onError(function (err) {
        //     console.error('create portrait custom ad' + id + ' error', err);
        // });
        console.log('created pc ad: ', pcad);
        return pcad;
    },
    // portraitCustomAds: {},
    // getPortraitCustomAd(id: number): any {
    //     let ad = this.portraitCustomAds[id];
    //     if (!ad) {
    //         ad = this.portraitCustomAds[id] = this.createPortraitCustomAd(id);
    //     }
    //     return ad;
    // },

    createSingleCustomAd(node: cc.Node): any {
        // return {
        //     show: () => {
        //         return new Promise((resolve, reject) => {
        //             reject('没有这个接口')
        //         })
        //     },
        //     onError: (cb) => {
        //         cb && cb('没有这个接口');
        //     }
        // };
        if (cc.sys.platform != cc.sys.WECHAT_GAME) return;
        if (!wx.createCustomAd) {
            return {
                show: () => {
                    return new Promise((resolve, reject) => {
                        reject('没有这个接口')
                    })
                },
                onError: (cb) => {
                    cb && cb('没有这个接口');
                }
            };
        }
        const interval = MpsdkUtil.getUmsConfig('CustomAdRefresh') || 30;
        const rect = node.getBoundingBoxToWorld();
        const wxRect = WeixinAPI.cocosUI2WxUi(rect.center, rect);
        const pcad = wx.createCustomAd({
            adUnitId: customAdUnit2,
            adIntervals: interval,
            style: {
                left: wxRect.left,
                top: wxRect.top
            }
        });
        // pcad.onError(function (err) {
        //     console.error('create single custom ad error', err);
        // });
        console.log('created sc ad: ', pcad);
        return pcad;
    },

    canInsert: true,
    blockInsert() {
        this.canInsert = false;
    },
    unblockInsert() {
        this.canInsert = true;
    },
    playBannerAfterUnblock: false,
    canBanner: true,
    blockBanner() {
        this.canBanner = false;
        this.hideBanner();
    },
    unblockBanner() {
        this.canBanner = true;
        if (this.playBannerAfterUnblock) {
            this.playBanner();
        }
    }
}