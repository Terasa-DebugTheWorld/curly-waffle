import md5 = require('./md5');
export default class Md5Helper {
    public static do(content):string {
        return md5(content.toString())
    }
}