import { Ad_topon } from "./Ad_topon";
import { NativeCall } from "./NativeCall";
import { Ad_Ohayoo } from "./Ad_ohayoo";
import { ClientEvent } from "../common/ClientEvent";

const topon = Ad_Ohayoo;
export const Ad_toponAdapter = {
    _video: ['948627620'],//['949288143'],
    _fullScreen: [],
    _banner: [],
    _splash: ['887845013'],
    _nativeExpress: [],
    _insert: ['949253557'],//['949253557'],
    init() {
        topon.ad = this.ad;
        topon.init();
        setTimeout(() => {
            topon.preload({
                video: this._video,
                banner: this._banner,
                insert: this._insert,
                nativeEx: this._nativeExpress,
                fullScreen: this._fullScreen
            })
        }, 4000)
    },
    playBanner(ext) {
        topon.playBanner("");
    },
    closeBanner() {
        topon.closeBanner("");
    },
    hideBanner() {
        topon.closeBanner("");
    },
    autoBanner(time = 80) {

    },
    stopAutoBanner() {

    },
    loadVideo(slotId) {
        if (!slotId) return;
        topon.loadVideo(slotId);
    },
    defaultSlot: '',
    playVideo(callback, key, slotId?) {
        if (topon.isLoadedVideo(slotId)) {
            topon.playVideo(callback, slotId);
            return true;
        }
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            ClientEvent.dispatch('toast', '视频准备失败，请稍后再试!')
        }
        return false;
    },
    playInsert(callback, cnt) {
        topon.playInsert(callback, this._insert[0], cnt);
    },
    playFullScreen(callback) {
        topon.playFullScreen(callback);
    },
    playNativeExpress() {
        topon.playNativeExpress();
    },
    closeNativeExpress() {
        topon.closeNativeExpress();
    }
}