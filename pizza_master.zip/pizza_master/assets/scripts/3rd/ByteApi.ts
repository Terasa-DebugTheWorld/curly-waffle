export const ByteApi=new class{
    
    public checkTouch(data: { changedTouches: { screenX: number, screenY: number }[] }, node: cc.Node): boolean {
        const wp = node.convertToWorldSpaceAR(cc.v3());
        const bb = node.getBoundingBox();
        const rect = this.parseRect(wp, bb);
        return data.changedTouches.some(t => rect.contains(cc.v2(t.screenX, t.screenY)))
    }
    public parseRect(wp: cc.Vec2 | cc.Vec3, rect: cc.Rect): cc.Rect {
        let vs = cc.view.getVisibleSize();
        let spRect = rect;
        let system = tt.getSystemInfoSync();
        let scalex = system.windowWidth / 720;
        let scaley = system.windowHeight / vs.height;
        let showWidth = spRect.width * scalex;
        let showHeight = spRect.height * scaley;
        let left = wp.x * scalex - (showWidth) / 2;
        let top = system.windowHeight - wp.y * scaley - (showHeight) / 2;
        let ret = cc.rect(left, top, showWidth, showHeight);
        return ret;
    }
}