import { Analysis_Umeng } from "./Analysis_Umeng";
import { dadian } from "./dadian";
import { Platform } from "./Platform";

var service = null;
var config = null;

if (Platform.ios) {
    // service = Analysis_Umeng;
}

const ILLEGAL_PARAM_NAMES = ['id', 'ts', 'du', '$stfl', '$!deeplink', '$!link'];
const checkParam = function (p: string) {
    if (ILLEGAL_PARAM_NAMES.includes(p)) {
        cc.error(`参数名${p}与预定保留字冲突！`);
    }
};
let dadianNumToZh = (num) => {
    if (cc.sys.isNative) return "";
    for (let k in dadian) {
        if (dadian[k].number == num) {
            return dadian[k].zh;
        }
    }
    return '翻译失败'
}

export const Analysis = {
    _record: null,
    init() {
        if (service) service.init(config);
    },
    event(e, parm?) {
        if (!e) return;
        cc.log('打点:', e, dadianNumToZh(e), parm);
        if (service) service.event(e + "", parm);
        Analysis_Umeng.event(e + '', parm);
    },
    eventOnce(e, parm?) {
        if (!this._getRecord(e)) {
            this.event(e, parm);
            this._setRecord(e);
        }
    },
    _getRecord(key) {
        if (!this._record) {
            this._record = cc.sys.localStorage.getItem('_eventRecord') || JSON.stringify({});
            this._record = JSON.parse(this._record);
        }
        return this._record[key];
    },
    _setRecord(key) {
        this._record[key] = 1;
        cc.sys.localStorage.setItem('_eventRecord', JSON.stringify(this._record));
    },
    eventValue(e, parm, dt) {
        if (service) service.eventValue(e, parm, dt);
    }
}