import UserData from "../userdata/UserData";
import { Ad } from "./Ad";
type VideoShareOpts = {
    title?: string,
    desc?: string,
    videoPath?: string,
    topics?: string[],
    hashtag_list?: string[],
    videoTitle?: string,
    succ?: Function,
    fail?: Function,
}

const BYTEDANCE_APPS = {
    'Toutiao': '今日头条',
    'Douyin': '抖音（国内版)',
    'news_article_lite': '今日头条（极速版)',
    'live_stream': '火山小视频',
    'XiGua': '西瓜',
    'PPX': '皮皮虾',
    'novelapp': '番茄小说',
}
type BytedanceAppNames = keyof typeof BYTEDANCE_APPS

const NEED_SHARE_MENU = true;                   //右上角分享按钮
const BANNER_UNITS = ['4qpmi4jg0pt3l1jfbj'];    //BANNER的广告位，字符串数组
const VIDEO_UNIT = '270fcc5hcm6kmnj4ld';        //视频广告位
const INSERT_UNIT = '24c29i32c4agia390r';       //插屏广告位
const SHARE_ID_NORMAL = '1018d47dj6bad1912c';   //普通分享id

export const ad_byte = new class {
    public init() {
        // this.createVideo();
        if (this.isBytedance && NEED_SHARE_MENU) {
            tt.showShareMenu();
        }
        this.ad = Ad;
    }
    private get isBytedance(): boolean {
        return cc.sys.BYTEDANCE_GAME == cc.sys.platform;
    }

    //banner
    setBannerTop(y: number) {
        this.bannerTop = y;
    }
    getBannerCenterY(): number {
        const ba = this.bannerAd as wx.BannerAd;
        const h = ba ? this.bannerAd.style.realHeight : 300;
        const top = this.bannerTop == undefined ? h : this.bannerTop;
        return top - h / 2;
    }
    bannerTop: number
    private bannerAd = null
    private bannerCount = 0 //播放计数
    public get isBannerPlaying(): boolean {
        return this.bannerCount > 0;
    }
    public playBanner() {
        if (!this.isBytedance) return;
        if (++this.bannerCount <= 0) return;
        if (this.bannerAd) {
            this.bannerAd.show().then(() => {
                if (this.bannerCount <= 0) {
                    this.bannerAd.hide();
                }
            });
            return;
        }
        this.createBanner(this.playBanner.bind(this));
    }
    public hideBanner() {
        if (!this.isBytedance) return;
        --this.bannerCount;
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    }
    private isBannerLoading = false
    private createBanner(cb?: Function) {
        if (!this.isBytedance) return;
        if (this.isBannerLoading) return;
        this.isBannerLoading = true;
        const systemInfo = tt.getSystemInfoSync();
        const saveArea = systemInfo.safeArea;
        const w = saveArea.width, h = w / 2.8;
        const top = this.bannerTop == undefined ? saveArea.bottom - h : this.world2ByteSpace(cc.v3(0, this.bannerTop)).y;

        console.log('try create banner')
        //@ts-ignore
        this.bannerAd = tt.createBannerAd({
            adUnitId: BANNER_UNITS[0],
            style: {
                left: saveArea.left + saveArea.width / 2 - w / 2,
                top: top,
                width: w,
            }
        });
        const onLoad = () => {
            console.log('create banner succ');
            this.isBannerLoading = false;
            if (cb) {
                cb();
            }
        }
        const onErr = (err) => {
            console.log('create banner err:', err);
            this.bannerAd.offError(onErr);
            this.bannerAd.offLoad(onLoad);
            this.bannerAd.destroy();
            this.bannerAd = null;
            this.isBannerLoading = false;
            setTimeout(() => {
                this.createBanner(cb);
            }, 1500);
        };
        this.bannerAd.onError(onErr);
        this.bannerAd.onLoad(onLoad);
    }

    world2ByteSpace(wp: cc.Vec3): cc.Vec3 {
        const system = tt.getSystemInfoSync();
        const area = system.safeArea;
        const w = area.width, h = area.height;
        const vs = cc.view.getVisibleSize();
        const sx = w / 720;
        const sy = h / vs.height;
        return cc.v3(wp.x * sx, system.screenHeight - wp.y * sy);
    }

    __VideoCall(res) {
        // 用户点击了【关闭广告】按钮
        // 小于 2.1.0 的基础库版本，res 是一个 undefined
        var self = this;
        console.log('video res: ', res);
        if (res && res.isEnded || res === undefined) {
            // 正常播放结束，可以下发游戏奖励
            console.log('video end succ');
            try {
                //mpsdk.Report.reportVideoTimeEvent();
            } catch (error) {

            }
            if (self.vc) self.vc(self.ad.CODE.ON_CLOSE);
            if (self.vc) self.vc(self.ad.CODE.ON_AWARD_SUCC);
            UserData.incr('videoCount');
        } else {
            // 播放中途退出，不下发游戏奖励
            if (self.vc) self.vc(self.ad.CODE.ON_CLOSE);
            if (self.vc) self.vc(self.ad.CODE.ON_AWARD_FAIL, 'not complete');
        }
        self.vc = null;
    }
    private vc
    private vlock
    private vonc
    private ad

    playVideo(callback) {
        //播放视频
        //callback(onCode,result) onCode对应ad.CODE,result是额外信息
        // if (videoUnit.length == 0) return;
        var self = this;
        if (self.vlock && (Date.now() - self.vlock < 5000)) return;
        tt.showToast({ title: '加载中' });

        self.vc = callback;
        self.vlock = Date.now();

        let vu = VIDEO_UNIT;
        if (UserData.get('videoCount') == 0) {

        }
        console.log('视频id:', vu);

        let videoAd = tt.createRewardedVideoAd({
            adUnitId: vu
        });

        videoAd.onError((err) => {
            console.log('play video error', err);
            if (this.vc) this.vc(this.ad.CODE.ON_ERROR, '');
            this.vc = null;
            this.vlock = null;
        });

        videoAd.load().then(() => {
            videoAd.show().then(() => {
                if (self.vc) self.vc(self.ad.CODE.ON_SHOW);
            })
        }).catch(err => {
            console.log(err.errMsg);
            // if (self.vc) self.vc(self.ad.CODE.ON_ERROR, err);
            self.vc = null;
            self.vlock = null;
        })
        if (!self.vonc) {
            videoAd.onClose(res => {
                self.vlock = null;
                self.__VideoCall(res)
            })
            self.vonc = true;
        }
        return videoAd;
    }
    /*
    //video
    private vlock = 0
    private videoCallback = null
    public isVideoPlaying = false
    public playVideo(callback) {
        //callback(onCode,result) onCode对应ad.CODE,result是额外信息
        if (!this.isBytedance) {
            callback(Ad.CODE.ON_CLOSE);
            callback(Ad.CODE.ON_AWARD_SUCC);
            return;
        }

        if (VIDEO_UNIT.length == 0) return;
        if (this.vlock && Date.now() - this.vlock < 5000) return;

        //视频未创建或加载失败，重新创建，并立即播放
        if (!this.videoAd) {
            this.createVideo(this.playVideo.bind(this, callback));
            return;
        }
        this.vlock = Date.now();
        this.videoCallback = callback;

        //@ts-ignore
        tt.showToast({ title: '加载中' });
        this.videoAd.show().then(() => {
            if (callback) {
                callback(Ad.CODE.ON_SHOW);
            }
            this.isVideoPlaying = true;
            if (this.insertAd) {
                this.insertAd.destroy();
                this.insertAd = null;
            }
            console.log('video show')
        });
    }
    private videoAd = null;
    _listenVideoFlag = false;
    _preloadCb = null;
    _onVideoLoaded() {
        console.log('video load succ');
        this._preloadCb && this._preloadCb();
        this._preloadCb = null;
    }
    _onVideoError({ errMsg, errCode }) {
        console.log('create video err,msg:', errMsg, '\ncode:', errCode);
        this.vlock = 0;
        if (this.videoAd.destroy) this.videoAd.destroy();
        if (this.isVideoPlaying) this.isVideoPlaying = false;
        this.videoAd = null;
    }
    _onVideoClose(res) {
        const callback = this.videoCallback;
        // 小于 2.1.0 的基础库版本，res 是一个 undefined
        if (res == undefined || res && res.isEnded) {
            // 正常播放结束，可以下发游戏奖励
            if (callback) {
                callback(Ad.CODE.ON_CLOSE);
                callback(Ad.CODE.ON_AWARD_SUCC);
            }
            UserData.incr('videoCount');
        } else {
            // 播放中途退出，不下发游戏奖励
            //@ts-ignore
            tt.showToast({ title: '未看完' });
            if (callback) {
                callback(Ad.CODE.ON_CLOSE);
                callback(Ad.CODE.ON_AWARD_FAIL, 'not complete');
            }
        }
        this.isVideoPlaying = false;

        //若每次播完重新创建则打开，官方文档推荐只创建一次重复播放
        // this.videoAd = null;
        // this.createVideo();
    }
    private createVideo(cb?: Function) {
        if (!this.isBytedance) return;

        let vu = VIDEO_UNIT;
        if (UserData.get('videoCount') == 0) {
            //首次视频可能用另一个广告位
        }
        console.log('视频id:', vu);

        //创建视频广告
        //@ts-ignore
        this.videoAd = tt.createRewardedVideoAd({
            adUnitId: vu
        });
        this._preloadCb = cb;
        console.log('load video:', this.videoAd)
        this.videoAd.load().then(() => {
            console.log("then loaded");
            this._onVideoLoaded();
        }, (err) => {
            console.log('video load err,msg:', err.errMsg, '\ncode:', err.errCode);
            this.videoAd = null;
        });

        if (this._listenVideoFlag) return
        this._listenVideoFlag = true;
        //监听加载失败/成功
        this.videoAd.onError(({ errMsg, errCode }) => {
            this._onVideoError({ errMsg, errCode });
        });
        this.videoAd.onLoad(() => {
            console.log("on loaded");
            this._onVideoLoaded();
        });
        //监听视频开始/关闭
        this.videoAd.onClose((res) => {
            this._onVideoClose(res);
        });
    }

    */
    //insert
    private insertAd = null
    public playInsert(errorCallBack) {
        if (!this.isBytedance) return;
        if (this.insertAd || this.isVideoPlaying) return;

        if (this.insertAd) {
            this.insertAd.destroy();
        }
        //@ts-ignore
        if (tt.createInterstitialAd) {
            //@ts-ignore
            this.insertAd = tt.createInterstitialAd({
                adUnitId: INSERT_UNIT
            });
        }
        // 在适合的场景显示插屏广告
        this.insertAd.onClose(() => {
            this.insertAd.destroy();
            this.insertAd = null;
        });
        this.insertAd.onError((errMsg, errCode) => {
            console.error(errMsg, errCode);
            errorCallBack && errorCallBack();
            this.insertAd = null;
        });
        this.insertAd.show().then(() => {
            if (this.isVideoPlaying) {
                this.insertAd.destroy();
                this.insertAd = null;
            }
        }).catch((err) => {
            console.error(err);
            this.insertAd = null;
        });
    }

    public videoShare(options: VideoShareOpts) {
        tt.shareAppMessage({
            channel: 'video',
            templateId: SHARE_ID_NORMAL,
            title: options.title || '视频分享',
            desc: options.desc || '',
            query: '',
            extra: {
                videoPath: options.videoPath,
                videoTopics: options.topics || [''],
                hashtag_list: options.hashtag_list || [''],
                video_title: options.desc || '',
                videoTag: options.videoTitle || '',
            },
            success() {
                console.log('分享视频成功');
                const succ = options.succ;
                succ && succ();
            },
            fail(e) {
                console.log('分享视频失败', e);
                const fail = options.fail;
                fail && fail();
                // self._videoPath = null;
            },
            complete(e) {
                console.log('分享视频完成', e);
            }
        })
    }

    public isAppName(name: BytedanceAppNames): boolean {
        return this.getAppName() == name;
    }
    public getAppName(): BytedanceAppNames {
        if (!this.isBytedance) return 'Douyin';
        return tt.getSystemInfoSync().appName;
    }
}
ad_byte.init();