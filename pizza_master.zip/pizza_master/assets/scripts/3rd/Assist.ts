export const Assist = {
    randInt: function (min, max) {
        //[min,max)
        return Math.floor(Math.random() * (max - min)) + min;
    },
    arrRemoveByValue(arr, val) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                arr.splice(i, 1);
                break;
            }
        }
    },
    judgeRandom(percent,max=100){
        //判断一个随机值是否成功
        if(percent == 0) return false;
        if(percent == max) return true;
        let r = this.randInt(0,max)
        if(r<=percent){
            return true;
        }
        return false;
    },
    makeDateStr() {
        var d = new Date();
        var gd = d.getDate();
        var day = gd < 10 ? '0' + gd : gd;
        var gm = d.getMonth() + 1;
        var month = gm < 10 ? '0' + gm : gm;
        return '' + d.getFullYear() + month + day;
    }

}