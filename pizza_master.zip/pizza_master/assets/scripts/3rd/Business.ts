import { NativeCall } from './NativeCall';
import { Ad } from "./Ad";
import { Share } from "./Share";
import { ThirdType } from "./ThirdType";
import { ClientEvent } from "../common/ClientEvent";
import { Analysis } from "./Analysis";
import UserData from "../userdata/UserData";
import uiFunc from '../common/uiFunc';
import { AudioHelper } from '../common/AudioHelper';
import { getDadian } from './dadian';

var defend = true;

export const Business = {
    do(type, succ, fail, ext, key) {
        if (type === ThirdType.BUSINESS.NONE) {
            if (succ) succ();
        } else if (type === ThirdType.BUSINESS.SHARE) {
            const succCallBack = () => {
                if (succ) {
                    succ();
                }
            }
            const failCallback = () => {
                if (fail) {
                    fail();
                }
            }

            // Share.share(succCallBack, fail, ext)
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                Share.share(succCallBack, failCallback, ext);
            } else if (cc.sys.isBrowser) {
                cc.log(`分享成功，分享口:${key}`);
                if (succCallBack) succCallBack();
            }
        } else if (type === ThirdType.BUSINESS.VIDEO) {
            ClientEvent.dispatch('adVideo', { key: key, code: ThirdType.AD_CODE.ON_EXCU_PLAY })
            let rlt = Ad.playVideo((code, msg) => {
                ClientEvent.dispatch('adVideo', { key: key, code: code, msg: msg })
                if (code == Ad.CODE.ON_AWARD_SUCC) {//成功
                    if (cc.sys.platform == cc.sys.WECHAT_GAME) {

                    }
                    if (succ) {
                        succ(ThirdType.BUSINESS.VIDEO)
                    }

                    UserData.incr('videoCount');
                    Analysis.event(getDadian('video_success'));
                    if (key) Analysis.event(getDadian('video_success_' + key as any));
                } else if (code == Ad.CODE.ON_AWARD_FAIL) {//失败
                    console.log('播放失败')
                    if (fail) {
                        fail()
                        fail = null;
                    }
                } else if (code == Ad.CODE.ON_SHOW) {
                    cc.game.pause();
                    if (AudioHelper.getBgmSwitch()) {
                        AudioHelper.pauseBgm();
                    }
                    // Analysis.event(getDadian("shipinzhanshi"))
                    Analysis.event(getDadian("video_play"));
                    if (key) Analysis.event(getDadian('video_play_' + key as any));
                } else if (code == Ad.CODE.ON_CLOSE) {
                    cc.game.resume();
                    if (AudioHelper.getBgmSwitch()) {
                        AudioHelper.resumeBgm();
                    }

                } else if (code == Ad.CODE.ON_ERROR) {
                    if (fail) {
                        fail()
                        fail = null;
                    }
                    NativeCall.toast('视频还没准备好！请稍后再试！');
                }
            }, key)
            if (!rlt) {
                NativeCall.toast('视频还没准备好！请稍后再试！');
                if (fail) {
                    fail()
                    fail = null;
                }
                ClientEvent.dispatch('adVideo', { key: key, code: ThirdType.AD_CODE.ON_NOT_READY })
            }
            // if (key) Analysis.event(getDadian(key + "_dj"))
        }
    }
}