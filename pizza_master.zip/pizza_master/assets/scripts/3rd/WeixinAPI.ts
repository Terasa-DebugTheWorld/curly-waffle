import { ClientEvent } from "../common/ClientEvent";

export const WeixinAPI = {
    postMessage(obj) {
        wx.getOpenDataContext().postMessage(obj);
    },

    /**
     * 上报玩家分数。value必须为string。
     */
    setUserCloudStorage(key, value) {
        if (cc.sys.platform != cc.sys.WECHAT_GAME) return;
        let kvDataList = new Array();
        value = String(value);
        kvDataList.push({
            key: key,
            value: value
        });

        wx.setUserCloudStorage({
            KVDataList: kvDataList
        })
        WeixinAPI.postMessage({ event: 'self', myData: value })
    },

    showModal(content = '', confirm, title = '提示') {
        wx.showModal({
            title: title,
            content: content,
            showCancel: false,
            success(res) {
                if (res.confirm) {
                    console.log('用户点击确定')
                    if (confirm) confirm();
                } else if (res.cancel) {
                    console.log('用户点击取消')
                }
            }
        })
    },

    makeFeedbackBtn() {
        // let button = wx.createFeedbackButton({
        //     type: 'text',
        //     text: '意见反馈',
        //     style: {
        //         left: 10,
        //         top: 76,
        //         width: 100,
        //         height: 40,
        //         lineHeight: 40,
        //         backgroundColor: '#FFFFFF',
        //         color: '#000000',
        //         textAlign: 'center',
        //         fontSize: 16,
        //         borderRadius: 100
        //     }
        // })
        // wx.createFeedbackButton({
        //     type: 'image',
        //     image: cc.loader.md5Pipe.transformURL(this.feedBackSp.spriteFrame._textureFilename),
        //     style: {
        //         left: (wp.x * system.windowWidth) / 720 - (showWidth) / 2,
        //         top: system.windowHeight - (wp.y * system.windowHeight) / vs.height - (showHeight) / 2,
        //         width: showWidth,
        //         height: showHeight
        //     }
        // })
    },
    cocosUI2WxUi(wp: cc.Vec2 | cc.Vec3, rect: cc.Rect) {
        let vs = cc.view.getVisibleSize();
        let spRect = rect;
        let system = wx.getSystemInfoSync();
        let scalex = system.windowWidth / 720;
        let scaley = system.windowHeight / vs.height;
        let showWidth = spRect.width * scalex;
        let showHeight = spRect.height * scaley;
        let left = wp.x * scalex - (showWidth) / 2;
        let top = system.windowHeight - wp.y * scaley - (showHeight) / 2;
        let ret = { width: showWidth, height: showHeight, left: left, top: top }
        return ret;
    },
    world2WxSpace(wp: cc.Vec3): cc.Vec3 {
        const system = wx.getSystemInfoSync();
        const vs = cc.view.getVisibleSize();
        const sx = system.windowWidth / 720;
        const sy = system.windowHeight / vs.height;
        return cc.v3(wp.x * sx, system.windowHeight - wp.y * sy);
    }
}
if (cc.sys.platform == cc.sys.WECHAT_GAME) {
    // wx.showShareMenu({
    //     withShareTicket: true,
    // });
    wx.onShow(function callBack(res) {
        ClientEvent.dispatch('wxOnShow', res)
    })

    wx.onHide(function () {
        ClientEvent.dispatch('wxOnHide')
    })
}