import { majiabao } from "../Glb";

export const AD_WX_PARAMS = [
    //花朵消消乐
    {
        Banner: "adunit-76b1b70e36021048",
        Video: "adunit-78e77d8dedecfe19",
        Inter: "adunit-49985df28b34828c",
        SingleGrid: "adunit-06a16e71e7173252",
        SingleGrid2: "adunit-00cd44a9686d8f64",
        VerticalGrid1: "adunit-9332735ce201a4e2",
        VerticalGrid2: "adunit-80ab734346bb0cde",
        GridsPage: "adunit-173f0f701ff468fc",
        GridsRecommend: "adunit-665f197b60c1402c",
    },
][majiabao];