import _s = require("./ATJSSDK");
import _v = require("./ATRewardedVideoJSSDK");
import _i = require("./ATInterstitialJSSDK");
import _b = require("./ATBannerJSSDK");
import { ThirdType } from "../ThirdType";
import { NativeCall } from "../NativeCall";
export const MyToponSDKAdapter = new class {
    placementIds = {
        video: "b61af2163913ef",
        banner: "",
        insert: "",
        splash: "b61af2368f3028"
    }
    _videoCallBack = null;
    _videoStartTime = Date.now() * 2;
    init() {
        // ATJSSDK.setLogDebug(true);
        let appkey = "64c73e945c1026130a43670ab9e65cff"
        let appid = "a61af2123a1fdf"
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            appkey = "64c73e945c1026130a43670ab9e65cff";
            appid = "a61d3c3e1c41e8"
            this.placementIds.video = "b61d3c4179176e"
            this.placementIds.banner = "b61d3d3769c70d"
            this.placementIds.insert = "b61d3d38b4baba"
            this.placementIds.splash = "b61d3c417d5477"
        }
        if (cc.sys.platform == cc.sys.ANDROID) {
            /*
            let toponChannel = NativeCall.getAndroidMeta("toponChannel");
            if (toponChannel) {
                var customMap = {
                    "channel": toponChannel
                };
                //设置自定义的Map信息，可匹配后台配置的广告商顺序的列表（App纬度）（可选配置）
                ATJSSDK.initCustomMap(customMap);
                console.log("设置topon渠道:", toponChannel);
            }
            */
        }

        // 初始化SDK
        ATJSSDK.initSDK(appid, appkey);
        // 激励视频回调
        var rewardedVideoListener = {
            //广告加载成功
            onRewardedVideoAdLoaded: (placementId) => {

            },
            //广告加载失败
            onRewardedVideoAdFailed: (placementId, errorInfo) => {
                setTimeout(() => {
                    this.loadVideo();
                }, 15 * 1000)
                console.log("加载视频失败", JSON.stringify(errorInfo))
            },
            //广告开始播放
            onRewardedVideoAdPlayStart: (placementId, callbackInfo) => {
                this._videoStartTime = Date.now();
                this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_SHOW);
                callbackInfo = JSON.parse(callbackInfo);
                // console.log('视频播放开始',callbackInfo,typeof callbackInfo);
            },
            //广告播放结束
            onRewardedVideoAdPlayEnd: (placementId, callbackInfo) => {
                this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_COMPLETE)
            },
            //广告播放失败
            onRewardedVideoAdPlayFailed: (placementId, errorInfo, callbackInfo) => {
                this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_AWARD_FAIL)
            },
            //广告被关闭
            onRewardedVideoAdClosed: (placementId, callbackInfo) => {
                this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_CLOSE);
                if (Date.now() - this._videoStartTime > 15 * 1000) {
                    setTimeout(() => {
                        this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_AWARD_SUCC);
                    }, 500)
                }
                this._videoStartTime = Date.now() * 2;
                this.loadVideo();
            },
            //广告被点击
            onRewardedVideoAdPlayClicked: (placementId, callbackInfo) => {
                this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_CLICK);
                callbackInfo = JSON.parse(callbackInfo);
            },
            //激励成功，开发者可在此回调中下发奖励，一般先于onRewardedVideoAdClosed回调，服务器激励则不一定
            onReward: (placementId, callbackInfo) => {
                // this._videoCallBack && this._videoCallBack(ThirdType.AD_CODE.ON_AWARD_SUCC)
            }
        }
        ATRewardedVideoJSSDK.setAdListener(rewardedVideoListener);
        //插屏回调
        var interstitialListener = {
            //广告加载成功
            onInterstitialAdLoaded: (placementId) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdLoaded(" + placementId + ")");
            },
            //广告加载失败
            onInterstitialAdLoadFail: (placementId, errorInfo) => {
                setTimeout(() => {
                    this.loadInsert(placementId);
                }, 10 * 1000)
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdLoadFail(" + placementId + ", " + errorInfo + ")");
            },
            //广告展示成功
            onInterstitialAdShow: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdShow(" + placementId + ", " + callbackInfo + ")");
            },
            //广告视频开始播放，部分平台有此回调
            onInterstitialAdStartPlayingVideo: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdStartPlayingVideo(" + placementId + ", " + callbackInfo + ")");
            },
            //广告视频播放结束，部分广告平台有此回调
            onInterstitialAdEndPlayingVideo: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdEndPlayingVideo(" + placementId + ", " + callbackInfo + ")");
            },
            //广告视频播放失败，部分广告平台有此回调
            onInterstitialAdFailedToPlayVideo: (placementId, errorInfo) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdFailedToPlayVideo(" + placementId + ", " + errorInfo + ")");
            },
            //广告展示失败
            onInterstitialAdFailedToShow: (placementId) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdFailedToShow(" + placementId + ")");
            },
            //广告被关闭
            onInterstitialAdClose: (placementId, callbackInfo) => {
                this.loadInsert(placementId);
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdClose(" + placementId + ", " + callbackInfo + ")");
            },
            //广告被点击
            onInterstitialAdClick: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkInterstitialDemo::onInterstitialAdClick(" + placementId + ", " + callbackInfo + ")");
            }
        };
        ATInterstitialJSSDK.setAdListener(interstitialListener);
        //banner回调
        var bannerListener = {
            //广告加载成功
            onBannerAdLoaded: (placementId) => {
                if (this._bannerFlag) ATBannerJSSDK.showAdInPosition(this.placementIds.banner, ATBannerJSSDK.kATBannerAdShowingPositionBottom);
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdLoaded(" + placementId + ")");
            },
            //广告加载失败
            onBannerAdLoadFail: (placementId, errorInfo) => {
                setTimeout(() => {
                    this.loadBanner();
                }, 10 * 1000)
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdLoadFail(" + placementId + ", " + errorInfo + ")");
            },
            //广告展示成功
            onBannerAdShow: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdShow(" + placementId + ", " + callbackInfo + ")");
            },
            //广告被点击
            onBannerAdClick: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdClick(" + placementId + ", " + callbackInfo + ")");
            },
            //广告自动刷新成功
            onBannerAdAutoRefresh: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdAutoRefresh(" + placementId + ", " + callbackInfo + ")");
            },
            //广告自动刷新失败
            onBannerAdAutoRefreshFail: (placementId, errorInfo) => {
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdAutoRefreshFail(" + placementId + ", " + errorInfo + ")");
            },
            //广告关闭按钮被点击
            onBannerAdCloseButtonTapped: (placementId, callbackInfo) => {
                ATJSSDK.printLog("AnyThinkBannerDemo::onBannerAdCloseButtonTapped(" + placementId + ", " + callbackInfo + ")");
                this.loadBanner();
            }
        };
        ATBannerJSSDK.setAdListener(bannerListener);
        this.preload();
    }

    preload() {
        //加载第一个视频
        this.loadVideo();
        if (this.placementIds.insert) this.loadInsert();
        if (this.placementIds.banner) this.loadBanner();
    }

    loadVideo() {
        var setting = {};
        //如果需要通过开发者的服务器进行奖励的下发（部分广告平台支持服务器激励），则需要传递下面两个key
        //ATRewardedVideoJSSDK.userIdKey必传，用于标识每个用户;ATRewardedVideoJSSDK.userDataKey为可选参数，传入后将透传到开发者的服务器
        setting[ATRewardedVideoJSSDK.userIdKey] = "test_user_id";
        setting[ATRewardedVideoJSSDK.userDataKey] = "test_user_data";
        ATRewardedVideoJSSDK.loadRewardedVideo(this.placementIds.video, setting);
    }
    playVideo(callback, ext) {
        if (!ATRewardedVideoJSSDK.hasAdReady(this.placementIds.video)) {
            return false;
        }
        this._videoCallBack = callback;
        ATRewardedVideoJSSDK.showAd(this.placementIds.video);
        return true;
    }
    loadBanner() {
        //v5.6.8新增
        var setting = {};
        let height = 150;
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            height = 50;
        }
        setting[ATBannerJSSDK.kATBannerAdLoadingExtraBannerAdSizeStruct] = ATBannerJSSDK.createLoadAdSize(cc.view.getFrameSize().width, height);
        //只针对Admob的自适应banner
        setting[ATBannerJSSDK.kATBannerAdAdaptiveWidth] = cc.view.getFrameSize().width;
        setting[ATBannerJSSDK.kATBannerAdAdaptiveOrientation] = ATBannerJSSDK.kATBannerAdAdaptiveOrientationCurrent;
        // setting[ATBannerJSSDK.kATBannerAdAdaptiveOrientation] = ATBannerJSSDK.kATBannerAdAdaptiveOrientationPortrait;
        // setting[ATBannerJSSDK.kATBannerAdAdaptiveOrientation] = ATBannerJSSDK.kATBannerAdAdaptiveOrientationLandscape;

        ATBannerJSSDK.loadBanner(this.placementIds.banner, setting);

    }
    _bannerFlag = false;
    playBanner() {
        this._bannerFlag = true;
        if (ATBannerJSSDK.hasAdReady(this.placementIds.banner)) {
            ATBannerJSSDK.showAdInPosition(this.placementIds.banner, ATBannerJSSDK.kATBannerAdShowingPositionBottom);
        }
    }
    closeBanner() {
        this._bannerFlag = false;
        ATBannerJSSDK.removeAd(this.placementIds.banner);
        this.loadBanner();
    }
    loadInsert(id?) {
        if (id && id != this.placementIds.insert) return;
        //v5.6.8新增，只针对Sigmob平台，Sigmob的激励视频广告源当做插屏使用
        var setting = {};
        setting[ATInterstitialJSSDK.UseRewardedVideoAsInterstitial] = false;
        //setting[ATInterstitialJSSDK.UseRewardedVideoAsInterstitial] = true;
        ATInterstitialJSSDK.loadInterstitial(this.placementIds.insert, setting);
    }
    playInsert() {
        if (!ATInterstitialJSSDK.hasAdReady(this.placementIds.insert)) {
            return false;
        }
        ATInterstitialJSSDK.showAd(this.placementIds.insert);
    }
    playSplash() {
        if (!cc.sys.isNative) return;
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/toponAd/TopOnSplashActivity", "play", "(Ljava/lang/String;)V", this.placementIds.splash);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("ATSplashAdWrapper", "playWithPlacementID:", this.placementIds.splash);
        }
    }
}