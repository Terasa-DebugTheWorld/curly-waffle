import { Util } from "../utils/Util";

export const Ad_bud = new class {
    slotid = {
        video: "948627620",
        insert: "949253557"
    }
    ad
    init() {
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("BUDad", "init");
        } else if (cc.sys.platform == cc.sys.ANDROID) {

        }
    }

    preload() {
        this.loadVideo(this.slotid.video);
        this.loadInsert(this.slotid.insert);
    }

    //--banner
    loadBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("BUDad", "load:", "");
        }
    }

    playBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("BUDad", "playBanner:", "");
        }
    }

    isLoadedBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else {

        }
    }

    closeBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "close", "(Ljava/lang/String;)V", slotID);
        } else {
            // jsb.reflection.callStaticMethod("BUDad", "close:", "");
        }
    }

    bannerCall(onCode, result) {

    }

    //--video
    loadVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    }

    isLoadedVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return this._videoFlag//jsb.reflection.callStaticMethod("BUDad", "isVideoLoaded:", slotID);
        }
        return true;
    }

    vc
    _videoRewardFlag = false;
    _videoShowTime = 0;
    _videoFlag = false;
    playVideo(callback, slotID) {
        this.vc = callback;
        this._videoRewardFlag = false;
        if(!this._videoFlag) return false;
        this._videoFlag = false;
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }
        return true;
    }


    _videoReward() {
        if (this.vc) {
            setTimeout(() => {
                if (this.vc) {
                    this.vc(this.ad.CODE.ON_AWARD_SUCC);
                    this.vc = null;
                }
            }, 100)
        }
    }

    videoCall(onCode, result) {
        if (onCode == this.ad.CODE.ON_AWARD_SUCC) {
            this._videoRewardFlag = true;
            // this._videoReward();
        } else if (onCode == this.ad.CODE.ON_SHOW) {
            if (this.vc) this.vc(onCode, result);
            this._videoShowTime = Date.now();
        } else if (onCode == this.ad.CODE.ON_CLOSE) {
            if (this._videoRewardFlag || (Date.now() - this._videoShowTime > 10000)) {
                this._videoRewardFlag = false;
                this._videoShowTime = 9597990206708;
                this._videoReward();
            }
            if (this.vc) this.vc(onCode, result);
            this.loadVideo(this.slotid.video)
        } else if (onCode == this.ad.CODE.ON_ERROR) {
            Util.timeoutTask('video', () => {
                this.loadVideo(this.slotid.video)
            }, 20 * 1000)
        } else if (onCode == this.ad.CODE.ON_READY) {
            this._videoFlag = true;
        } else if (onCode == this.ad.CODE.ON_REQUEST) {

        } else {
            if (this.vc) this.vc(onCode, result);
        }
    }

    //---INSERT---START
    loadInsert(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("OhayooInsert", "load:", slotID);
            jsb.reflection.callStaticMethod("BUDad", "loadInsert:", slotID);
        }
    }

    isLoadedInsert(slotID = "") {
        if (cc.sys.platform == cc.sys.ANDROID) {
            // return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return jsb.reflection.callStaticMethod("OhayooInsert", "isLoaded:", slotID);
        }
        return true;
    }

    _insertCb
    playInsert(callback, slotID = "", cnt) {
        this._insertCb = callback;
        if (cc.sys.platform == cc.sys.ANDROID) {
            // jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "play", "(Ljava/lang/String;I)V", slotID, cnt);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("OhayooInsert", "play:", slotID);
            jsb.reflection.callStaticMethod("BUDad", "playInsert:", slotID);
        }
    }

    insertCall(onCode, result) {
        this._insertCb && this._insertCb(onCode, result);
        if (onCode == this.ad.CODE.ON_CLOSE) {
            this._insertCb = null;
            this.loadInsert(this.slotid.insert)
        } else if (onCode == this.ad.CODE.ON_ERROR) {
            Util.timeoutTask('insert', () => {
                this.loadInsert(this.slotid.insert)
            }, 30 * 1000)
        }
    }
    //---INSERT---END
}

window["__BudCall"] = {
    adCall(onCode, ptype, result) {
        console.log('__BudCall:', ptype, onCode, result);
        if (ptype == 'banner') {
            Ad_bud.bannerCall(onCode, result);
        } else if (ptype == 'video') {
            Ad_bud.videoCall(onCode, result);
        } else if (ptype == 'insert') {
            Ad_bud.insertCall(onCode, result);
        } else if (ptype == 'fullscreen') {
            // Ad_bud.fullScreenCall(onCode, result);
        } else if (ptype == 'nativeExpress') {
            // Ad_bud.nativeExpressCall(onCode, result);
        }
    }
}