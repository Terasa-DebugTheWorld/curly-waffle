import { Ad_toponAdapter } from './Ad_toponAdapter';
import { Util } from "../utils/Util";

var _Android_PACKAGE = "org/cocos2dx/javascript/toponAd/";

export const Ad_Ohayoo = {
    ad: null,
    init() {
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("BUDad", "init");
        } else if (cc.sys.platform == cc.sys.ANDROID) {

        }
    },

    preload(data) {
        if (data.banner) {
            data.banner.forEach(k => {
                this.loadBanner(k);
            })
        }
        if (data.video) {
            data.video.forEach(k => {
                this.loadVideo(k);
            })
        }

        if (data.fullScreen) {
            data.fullScreen.forEach(k => {
                this.loadFullScreen(k);
            })
        }

        setTimeout(() => {
            if (data.insert) {
                data.insert.forEach(k => {
                    this.loadInsert(k);
                })
            }
        }, 100)

        if (data.nativeEx) {
            data.nativeEx.forEach(k => {
                this.loadNativeExpress(k);
            })
        }
        this._data = data;
    },
    //---BANNER---START
    loadBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("BUDad", "load:", "");
        }
    },

    playBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("BUDad", "playBanner:", "");
        }
    },

    isLoadedBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else {

        }
    },

    closeBanner(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnBanner", "close", "(Ljava/lang/String;)V", slotID);
        } else {
            jsb.reflection.callStaticMethod("BUDad", "close:", "");
        }
    },

    bannerCall(onCode, result) {

    },
    //---BANNER---END
    //---VIDEO---START
    loadVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedVideo(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return jsb.reflection.callStaticMethod("BUDad", "isVideoLoaded:", slotID);
        }
        return true;
    },

    playVideo(callback, slotID) {
        this.vc = callback;
        this._videoRewardFlag = false;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnVideo", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }

    },

    _videoReward() {
        if (this.vc) {
            setTimeout(() => {
                if (this.vc) {
                    this.vc(this.ad.CODE.ON_AWARD_SUCC);
                    this.vc = null;
                }
            }, 100)
        }
    },

    videoCall(onCode, result) {
        this.vlock = null;
        if (onCode == this.ad.CODE.ON_AWARD_SUCC) {
            this._videoRewardFlag = true;
            // this._videoReward();
        } else if (onCode == this.ad.CODE.ON_SHOW) {
            if (this.vc) this.vc(onCode, result);
            this._videoShowTime = Date.now();
        } else if (onCode == this.ad.CODE.ON_CLOSE) {
            if (this._videoRewardFlag /* || (Date.now() - this._videoShowTime > 5000) */) {
                this._videoRewardFlag = false;
                this._videoShowTime = 9597990206708;
                this._videoReward();
            }
            if (this.vc) this.vc(onCode, result);
        } else if (onCode == this.ad.CODE.ON_ERROR) {
            Util.timeoutTask('video', () => {
                this.loadVideo(Ad_toponAdapter._video[0])
            }, 20 * 1000)
        } else if (onCode == this.ad.CODE.ON_READY) {

        } else if (onCode == this.ad.CODE.ON_REQUEST) {

        } else {
            if (this.vc) this.vc(onCode, result);
        }
    },
    //---VIDEO---END
    //---INSERT---START
    loadInsert(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("OhayooInsert", "load:", slotID);
            jsb.reflection.callStaticMethod("BUDad", "loadInsert:", slotID);
        }
    },

    isLoadedInsert(slotID = "") {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return jsb.reflection.callStaticMethod("OhayooInsert", "isLoaded:", slotID);
        }
    },

    playInsert(callback, slotID = "", cnt) {
        this._insertCb = callback;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnInsert", "play", "(Ljava/lang/String;I)V", slotID, cnt);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            // jsb.reflection.callStaticMethod("OhayooInsert", "play:", slotID);
            jsb.reflection.callStaticMethod("BUDad", "playInsert:", slotID);
        }
    },

    insertCall(onCode, result) {
        this._insertCb && this._insertCb(onCode, result);
        if (onCode == this.ad.CODE.ON_CLOSE) {
            this._insertCb = null;
        } else if (onCode == this.ad.CODE.ON_ERROR) {
            Util.timeoutTask('insert', () => {
                this.loadInsert('')
            }, 40 * 1000)
        }
    },
    //---INSERT---END
    //---FULLSCREEN---START
    loadFullScreen(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("OhayooFullScreen", "load:", slotID);
        }
    },

    isLoadedFullScreen(slotID = "") {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return jsb.reflection.callStaticMethod("OhayooFullScreen", "isLoaded:", slotID);
        }
    },

    playFullScreen(callback, slotID = "") {
        this._fullScreenCb = callback;
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnFullScreen", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("OhayooFullScreen", "play:", slotID);
        }

    },

    fullScreenCall(onCode, result) {
        this._fullScreenCb && this._fullScreenCb(onCode, result);
        if (onCode == this.ad.CODE.ON_CLOSE) {
            //if (this._fullScreenCb) this._fullScreenCb(onCode, result);
            this._fullScreenCb = null;
        } else if (onCode == this.ad.CODE.ON_ERROR) {
            Util.timeoutTask('fullscreen', () => {
                this.loadFullScreen('')
            }, 40 * 1000)
        }
    },
    //---FULLSCREEN---END
    //---NATIVE_EXPRESS---START
    loadNativeExpress(slotID) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "load", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "loadVideo:", slotID);
        }
    },

    isLoadedNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "isLoaded", "(Ljava/lang/String;)Z", slotID);
        }
    },

    playNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "play", "(Ljava/lang/String;)V", slotID);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            var ret = jsb.reflection.callStaticMethod("BUDad", "playVideo:", slotID);
        }

    },

    closeNativeExpress(slotID = '') {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod(_Android_PACKAGE + "TopOnNative", "close", "(Ljava/lang/String;)V", slotID);
        }
    },

    nativeExpressCall(onCode, result) {
        if (onCode == this.ad.CODE.ON_CLOSE) {

        }
    },
    //---NATIVE_EXPRESS---END
}

window["__Ohayoo"] = {
    adCall(onCode, ptype, result) {
        console.log('__Ohayoo:', ptype, onCode, result);
        if (ptype == 'banner') {
            Ad_Ohayoo.bannerCall(onCode, result);
        } else if (ptype == 'video') {
            Ad_Ohayoo.videoCall(onCode, result);
        } else if (ptype == 'insert') {
            Ad_Ohayoo.insertCall(onCode, result);
        } else if (ptype == 'fullscreen') {
            Ad_Ohayoo.fullScreenCall(onCode, result);
        } else if (ptype == 'nativeExpress') {
            Ad_Ohayoo.nativeExpressCall(onCode, result);
        }
    }
}