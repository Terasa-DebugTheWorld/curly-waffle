export const Platform = new class {
    public get isByte(): boolean {
        return cc.sys.platform == cc.sys.BYTEDANCE_GAME;
    }
    public get isWx(): boolean {
        return cc.sys.platform == cc.sys.WECHAT_GAME;
    }
    public get isWeb(): boolean {
        return cc.sys.platform == cc.sys.MOBILE_BROWSER;
    }
    public get ios(): boolean {
        return cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE;
    }
    public get android(): boolean {
        return cc.sys.platform == cc.sys.ANDROID;
    }
}