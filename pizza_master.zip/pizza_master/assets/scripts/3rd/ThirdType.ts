export const ThirdType = {
    BUSINESS: {
        NONE: 0,
        SHARE: 1,
        VIDEO: 2,
        FAKE_VIDEO: 3,
    },
    AD_CODE: {
        ON_EXCU_PLAY: 'ad_excu',
        ON_AWARD_SUCC: 'ad_award_succ',
        ON_AWARD_FAIL: 'ad_award_fail',
        ON_SHOW: 'ad_show',
        // ON_SHOW_FAIL:'show_fail',
        ON_COMPLETE: 'ad_complete',
        ON_CLICK: 'ad_click',
        ON_CLOSE: 'ad_close',
        ON_ERROR: 'ad_error',
        ON_READY: 'ad_ready',
        ON_NOT_READY: 'ad_not_ready',
        ON_REQUEST: 'ad_requset',
        ON_CLOSE_GAME: 'ad_close_game'//部分平台可以关闭游戏
    }
}