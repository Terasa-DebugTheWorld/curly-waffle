import { CommercialCode } from './../static/CommercialCode';
import { Glb } from './../Glb';
import { Business } from "./Business";
import { ThirdType } from "./ThirdType";
import { Assist } from "./Assist";
import { HttpServer } from "./HttpServer";
import { Ad } from './Ad';
import uiFunc from '../common/uiFunc';
import { Analysis } from './Analysis';
import UserData from '../userdata/UserData';

var __KEY_VIDEO_CNT = 'temp_video_cnt'
var VIDEO_CNT_RECORD_KEY = 'video_cnt';

export const BusinessManager = {
    init() {
        Ad.init();
    },
    do(succ, fail, key) {
        let info = this.getType(key);
        let btype = info.type;
        let ext = {};
        Business.do(btype, (actualType) => {
            if (actualType == ThirdType.BUSINESS.VIDEO) {
                UserData.incr(VIDEO_CNT_RECORD_KEY);
                // UserData.incr('dailyVideo');
                // MpsdkUtil.heavyExportDoneVideo();
            }
            if (succ) succ(btype);
        }, fail, ext, key)
    },
    getType(key) {
        return { type: ThirdType.BUSINESS.VIDEO }
    }
};