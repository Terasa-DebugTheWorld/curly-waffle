import { Glb } from './../Glb';
export const NativeCall = {
    openUrl(url) {
        if (!url || (typeof url != 'string') || url.length == 0) return;
        cc.log('open url:', url);
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "openUrl", "(Ljava/lang/String;)V", url);
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("Utils", "openUrl:", url);
        }
    },
    getNativeVersion() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            let info = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getVersion", "()Ljava/lang/String;");
            return info;
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            let info = jsb.reflection.callStaticMethod("Utils", "getInfoVersion");
            return info;
        }
        return Glb.version;
    },
    getSystmLanguage() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            let language = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getSystmLanguage", "()Ljava/lang/String;");
            return language;
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            let language = jsb.reflection.callStaticMethod("Utils", "getSystmLanguage");
            return language
        }
    },
    getSystemInfo() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            let info = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getSystemInfo", "()Ljava/lang/String;");
            return info;
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            let info = jsb.reflection.callStaticMethod("Utils", "getSystemInfo");
            return info;
        }
        return "";
    },
    getIMIE() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            let info = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getIMEI", "(Z)Ljava/lang/String;", true);
            return info;
        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {

        }
        return "";
    },
    iosStoreReview() {
        if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            jsb.reflection.callStaticMethod("Utils", "storeReview");
        }
    },
    getChannel() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "getChannel", "()Ljava/lang/String;");
        }
        return 'taptap'
    },
    getIDFA() {
        if (cc.sys.platform == cc.sys.ANDROID) {

        } else if (cc.sys.platform == cc.sys.IPAD || cc.sys.platform == cc.sys.IPHONE) {
            return jsb.reflection.callStaticMethod("Utils", "getIdfa");
        }
        return "";
    },
    getPackageName() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getPackageName", "()Ljava/lang/String;");
        }
        return "not.native";
    },
    downloadApk(url, apkName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "downloadAPK", "(Ljava/lang/String;Ljava/lang/String;)V", url, apkName);
        }
    },
    checkApkExist(apkName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "checkApkExist", "(Ljava/lang/String;)Z", apkName);
        }
    },
    installAPK(apkName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "installAPK", "(Ljava/lang/String;)V", apkName);
        }
    },
    checkPackInfo(packageName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "checkPackInfo", "(Ljava/lang/String;)Z", packageName);
        }
        {
            return false;
        }
    },
    openPackage(packageName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "openPackage", "(Ljava/lang/String;)Z", packageName);
        }
    },
    queryProgress(packageName) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/DownloadApk", "queryProgress", "(Ljava/lang/String;)F", packageName);
        }
    },

    toast(str) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "toast", "(Ljava/lang/String;)V", str);
        } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
           return wx.showToast({ title: str });
        }
        console.log(str);
    },

    copyText(str) {
        if (cc.sys.platform == cc.sys.ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "copyText", "(Ljava/lang/String;)V", str);
        }
    },

    getGameId() {
        if (cc.sys.platform == cc.sys.ANDROID) {
            return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/Utils", "getGameId", "()Ljava/lang/String;");
        } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            return Glb.gameId;
        }
        return Glb.gameId;
    },

    getGamePath() {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            return Glb.gamePath;
        }
        return Glb.DEFAULT_GAMEPATH;
    }
}
