import EventListener from "../common/EventListener"
enum ByteMiniRecordEvent {
    Start = 0,
    Pause,
    Resume,
    Stop,
    Error,
    InterruptionBegin,
    InterruptionEnd,
}
cc.Enum(ByteMiniRecordEvent);
let isByteMiniGame = cc.sys.BYTEDANCE_GAME == cc.sys.platform;
export const ByteMiniRecorder = new class {
    private recorder = null
    private listener = new EventListener()
    public eventType = ByteMiniRecordEvent
    constructor() {
        if (!isByteMiniGame) {
            for (let i in this) {
                if (this[i] instanceof Function) {
                    //@ts-ignore
                    this[i] = () => { };
                }
            }
            return;
        }

        this.recorder = tt.getGameRecorderManager();
        for (let i in ByteMiniRecordEvent) {
            this.recorder['on' + i](this.dispatch.bind(this, ByteMiniRecordEvent[i]));
        }
    }
    private dispatch(key: ByteMiniRecordEvent, data?: any) {
        if (!isByteMiniGame) return;
        this.listener.dispatch(key, data);
        switch (key) {
            case ByteMiniRecordEvent.Error:
                console.log('record err:', data);
                break;
            case ByteMiniRecordEvent.Stop:
                console.log('record end,path:', data.videoPath);
                this.videoPath = data.videoPath;
                break;
        }
    }
    public videoPath = ''

    public on(event: ByteMiniRecordEvent, handler: Function, target: any) {
        this.listener.on(event, handler, target, false);
    }
    public off(event: ByteMiniRecordEvent, handler: Function, target: any) {
        this.listener.off(event, handler, target);
    }
    public once(event: ByteMiniRecordEvent, handler: Function, target: any) {
        this.listener.on(event, handler, target, true);
    }

    //录屏开始
    public start(time: number = 15, locTop = 0, locLeft = 0, frameRate = 30) {
        this.recorder.stop();
        this.recorder.start({ duration: time, locTop: locTop, locLeft: locLeft, frameRate: frameRate });
    }
    public recordClip(timeRange = [3, 3]) {
        this.recorder.recordClip({
            timeRange: timeRange,
            success: (index: number) => {
                console.log('record clip succ,index:', index);
            },
            fali: (err) => {
                console.log('record clip err:', err);
            }
        });
    }
    public pause() {
        this.recorder.pause();
    }
    public resume() {
        this.recorder.resume();
    }

    //返回视频存放路径，或失败信息
    public stop(): Promise<string> {
        return new Promise((resl, reje) => {
            const handler = (cb: Function, arg: any) => {
                cb(arg);
                this.listener.clear(this);
            }
            this.on(ByteMiniRecordEvent.Stop, data => handler(resl, data.videoPath), this);
            this.on(ByteMiniRecordEvent.Error, err => handler(reje, err.errMsg), this);
            this.recorder.stop();
        });
    }
}