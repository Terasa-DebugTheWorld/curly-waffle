import { Glb } from './../Glb';
import { Http } from "./Http";
import { Assist } from "./Assist";
import { Util } from '../utils/Util';

var curl = "";

export const HttpServer = {
    reqConfig(succ, fail) {
        // Http.request(curl, (resp) => {
        //     //成功
        //     let oresp = JSON.parse(resp);
        //     this._config = oresp.default;
        //     let version = Glb.version;
        //     if (oresp[version]) {
        //         for (let k in oresp[version]) {
        //             this._config[k] = oresp[version][k];
        //         }
        //     }
        //     console.log('config:',resp);
        //     if (succ) succ(this._config);
        // }, () => {
        //     setTimeout(() => {
        //         this.reqConfig(succ, fail)
        //     }, 1000)
        // });
        succ(this.getConfig());
    },
    getConfig() {
        return this._config || {
            "auditVer": "0",
            "shareSuccTime": 2500,
            "bannerTime": 60,
            "announcement": 'xxx',
            "insertDelay": 0.2,
            "maxVideoCount": 1,
            "perProgress": 0.05,
            "stopProgress": 0.9,
            "bannerDelayTime": 0.05,
            "perReduce": 0.12,
            "insertMinDelay": 0.4,
            "insertMaxDelay": 1,
            "fullScreenCoolTime": 120,
            "gradeRedpacketVideo": false,
            "clickBoxAfterUpgrade": false,
            "canPlayInsert": false,
        };
    },
    getInsertDelay() {
        return Util.getRandom(this.getConfig().insertMinDelay * 10, this.getConfig().insertMaxDelay * 10) / 10;
    },
    getMaxVideoCount() {
        return this.getConfig().maxVideoCount;
    },
    getPerProgress() {
        return this.getConfig().perProgress;
    },
    getStopProgress() {
        return this.getConfig().stopProgress;
    },
    getBannerDelayTime() {
        return this.getConfig().bannerDelayTime;
    },
    getPerReduce() {
        return this.getConfig().perReduce;
    },
    getGradeRedpacketVideo() {
        return this.getConfig().gradeRedpacketVideo;
    },
    getFullScreenCoolTime() {
        return this.getConfig().fullScreenCoolTime;
    },
    getClickBoxAfterUpgrade() {
        return this.getConfig().clickBoxAfterUpgrade;
    },
    getCanPlayInsert() {
        return this.getConfig().canPlayInsert;
    },
    getFullScreenCd() {
        return this.getConfig().fullScreenCd;
    },
    getEsAdLimit() {
        return this.getConfig().esAdLimit;
    },
    getNoInsertTime() {
        return this.getConfig().noInsertTime;
    },
    getShare() {
        if (this.getConfig().share == undefined) {
            return this.catptureShare();
        }
        let r = Assist.randInt(0, this.getConfig().share.length);
        // if(glb.version === this.getConfig().auditVer) return this.catptureShare();
        let info = this.getConfig().share[r];
        if (!info.imageUrl || info.imageUrl.length == 0) {
            info.imageUrl = this.catptureShare().imageUrl;
        }
        return info
    },
    catptureShare() {
        let r = Assist.randInt(0, this.getConfig().shareCapture.length);
        let info = { title: "", content: "", imageUrl: "" };
        let vs = cc.view.getVisibleSize();
        var width = cc.winSize.width;
        var height = cc.winSize.height;
        info.imageUrl = cc.game.canvas.toTempFilePathSync({
            // x:15,
            // y:10+vs.height-1280,
            // width:cc.winSize.width,
            // height:576,
            // destWidth:500,
            // destHeight:400
            x: 0,
            y: 0,
            width: width,
            height: height,
            destWidth: width,
            destHeight: height,
        })
        return info
    }
};
