import { Analysis } from "../../3rd/Analysis";
import { getDadian } from "../../3rd/dadian";
import { ClientEvent } from "../../common/ClientEvent";
import DataFunc from "../../common/DataFunc";
import { EventType } from "../../static/EventType";
import UserData from "../../userdata/UserData";
import { LogicBase } from "../LogicBase";
import { SliverLogic } from "./SliverLogic";

export type DtoRecipe = {
    id: number,
    name: string,
    sliverId: number[],
    price: number,
    showAble: boolean
}

type DtoRecipeData = {
    unlockedRecipes: number[]
    newRecipes: number[]
    rewarded: number[]
}

const RECORD_KEY = 'recipe';
/**食谱 */
export const RecipeLogic = new class extends LogicBase {
    name = 'recipe'

    private _recipes: { [key: string]: DtoRecipe } = {};
    public get Recipes(): { [key: string]: DtoRecipe } {
        return this._recipes;
    }

    public get ShowableRecipes(): DtoRecipe[] {
        let ts = this;
        let showableRecipes: DtoRecipe[] = [];
        for (const id in ts._recipes) {
            const recipe: DtoRecipe = ts._recipes[id];
            if (recipe.showAble) showableRecipes.push(recipe);
        }
        return showableRecipes;
    }

    private _recipeData: DtoRecipeData = null;

    protected init(): void {
        let ts = this;
        ts._recipes = DataFunc.getConfig('book');
        ts._recipeData = UserData.get(RECORD_KEY);
    }

    public getRecipeById(id: number): DtoRecipe {
        let ts = this;
        if (id < 0) return null;
        let recipe: DtoRecipe = ts._recipes[id];
        if (!recipe) cc.warn(`没有id为${id}的食谱!`);
        return recipe;
    }

    public getRecipeByName(name: string): DtoRecipe {
        let ts = this;
        if (!name) {
            cc.error(`食谱名不能为空!`);
            return null;
        }
        for (const id in ts._recipes) {
            const recipe: DtoRecipe = ts._recipes[id];
            if (recipe.name === name) return recipe;
        }
        cc.warn(`没有名为${name}的食谱!`);
        return null;
    }

    /**食谱是否能展示 */
    public isRecipeShowable(id: number): boolean {
        let ts = this;
        return ts._recipes[id].showAble;
    }

    /**食谱是否已解锁 */
    public isUnlockedRecipe(id: number): boolean {
        let ts = this;
        return ts._recipeData.unlockedRecipes.includes(id);
    }

    /**是否是新食谱 */
    public isNewRecipe(id: number): boolean {
        let ts = this;
        return ts._recipeData.newRecipes.includes(id);
    }

    /**解锁食谱 */
    public unlockRecipe(id: number, save: boolean = true): void {
        let ts = this;
        if (ts.isUnlockedRecipe(id)) {
            cc.error(`id为${id}的食谱已解锁,不能重复解锁!`);
            return;
        }
        if (!ts.getRecipeById(id)) {
            cc.error(`不存在id为${id}的食谱,解锁失败!`);
            return;
        }
        ts._recipeData.unlockedRecipes.push(id);
        ts._recipeData.newRecipes.push(id);
        save && UserData.save(RECORD_KEY);
        ClientEvent.dispatch(EventType.UPDATE_RECIPE_DOT);
        Analysis.event(getDadian("unlock_bing_" + Math.ceil(id / 3) as any));
    }

    public unlockAllRecipe(): void {
        let ts = this;
        for (const id in ts._recipes) {
            const recipe: DtoRecipe = ts._recipes[id];
            ts.unlockRecipe(recipe.id, false);
        }
        UserData.save(RECORD_KEY);
    }

    unNewRecipe(id: number): void {
        let ts = this;
        if (!ts.isNewRecipe(id)) return;
        let idx: number = ts._recipeData.newRecipes.indexOf(id);
        ts._recipeData.newRecipes.splice(idx, 1);
        UserData.save(RECORD_KEY);
    }

    isRecipeCanCook(id: number): boolean {
        if (!id) debugger;
        const r = this.getRecipeById(id);
        return r.sliverId.every(SliverLogic.isSliverUnlocked.bind(SliverLogic));
    }
    getCanCooks(): DtoRecipe[] {
        const arr: DtoRecipe[] = [];
        for (let i in this._recipes) {
            const r = this._recipes[i];
            const slivers = r.sliverId;
            if (slivers.every(s => SliverLogic.isSliverUnlocked(s))) {
                arr.push(r);
            }
        }
        return arr;
    }

    getUnlockRecipeCnt(): number {
        return this._recipeData.unlockedRecipes.length;
    }
    hasReward(id: number): boolean {
        if (!this._recipeData.rewarded) this._recipeData.rewarded = [];
        return !this._recipeData.rewarded.includes(id);
    }
    gotReward(id: number) {
        this._recipeData.rewarded.push(id);
        UserData.save(RECORD_KEY);
        ClientEvent.dispatch(EventType.UPDATE_RECIPE_DOT);
    }
    getRewardedCnt(): number {
        if (!this._recipeData.rewarded) {
            this._recipeData.rewarded = [];
            UserData.save(RECORD_KEY);
        }
        return this._recipeData.rewarded.length;
    }
}
window['RecipeLogic'] = RecipeLogic;