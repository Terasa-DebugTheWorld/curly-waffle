import { ClientEvent } from "../../common/ClientEvent";
import DataFunc from "../../common/DataFunc";
import { EventType } from "../../static/EventType";
import UserData from "../../userdata/UserData";
import { LogicBase } from "../LogicBase";

const { ccclass, property } = cc._decorator;

export type DecConfig = {
    id: number
    name: string
    tag: number
    type: number
    icon: string
    scene: string
    gold: number
    diamond: number
    video: number
}
type DecData = {
    unlock: number
    using: number[]
}

const RECORD_KEY = 'decorate';
export const DecorateLogic = new class extends LogicBase {
    name = RECORD_KEY
    private configs: Dictionary<DecConfig>
    private types: number[][] = []
    private data: DecData
    public init() {
        this.data = UserData.get(RECORD_KEY);
        this.configs = DataFunc.getConfig('decorate');
        const isNew = this.data.using.length == 0;
        for (let i in this.configs) {
            const cfg = this.configs[i];
            if (!this.types[cfg.type]) {
                this.types[cfg.type] = [];
            }
            this.types[cfg.type].push(cfg.type);
            if (!isNew || cfg.gold || cfg.diamond || cfg.video) continue;
            this.unlock(cfg.id);
        }
    }
    private saveData() {
        UserData.save(RECORD_KEY);
    }

    public getConfigs(): Dictionary<DecConfig> {
        return this.configs;
    }
    public getConfig(id: number): DecConfig {
        return this.configs[id];
    }
    public isUnlock(id: number): boolean {
        return !!(this.data.unlock & 1 << id);
    }
    public getTypes(): number[][] {
        return this.types;
    }
    public getType(type: number): number[] {
        return this.types[type];
    }
    public getUsing(type: number): number {
        return this.data.using[type];
    }
    public unlock(id: number) {
        this.data.unlock |= 1 << id;
        this.use(this.getConfig(id).type, id);
    }
    public use(type: number, id: number) {
        this.data.using[type] = id;
        this.saveData();
        ClientEvent.dispatch(EventType.CHANGE_DECORATION, type);
    }
}