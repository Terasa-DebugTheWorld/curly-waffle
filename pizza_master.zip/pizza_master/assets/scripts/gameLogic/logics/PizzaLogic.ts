import { ClientEvent } from "../../common/ClientEvent";
import DataFunc from "../../common/DataFunc";
import { EventType } from "../../static/EventType";
import UserData from "../../userdata/UserData";
import { LogicBase } from "../LogicBase";

type PizzaData = {
    gold: number
    day: number
    diamond: number
}
const RECORD_KEY = 'pizza';
export const PizzaLogic = new class extends LogicBase {
    name = 'pizza'

    private data: PizzaData
    private tempGold = 0

    protected init(): void {
        this.data = UserData.get(RECORD_KEY);
        this.tempGold = 0;
        if (UserData.isNew) this.addGold(DataFunc.getBaseConfig('DEFAULT_GOLD'));
    }
    private saveData() {
        UserData.save(RECORD_KEY);
    }

    public reset() {
        this.data.day = 0;
        this.tempGold = this.data.gold = 0;
        ClientEvent.dispatch(EventType.UPDATE_GOLD, this.tempGold);
        this.saveData();
    }

    public getDay(): number {
        return this.data.day;
    }
    public getGold(): number {
        return this.getTempGold();
    }
    public endToday() {
        this.data.day++;
        this.saveGold();
    }

    public getTempGold(): number {
        return Math.round(this.tempGold * 100 + this.data.gold * 100) / 100;
    }
    public addGold(num: number, isTemp = false) {
        this.add(num, isTemp);
        ClientEvent.dispatch(EventType.UPDATE_GOLD, this.getTempGold());
    }
    public useGold(num: number): boolean {
        if (num <= 0) return;
        if (num > this.getTempGold()) return false;
        this.sub(num);
        ClientEvent.dispatch(EventType.UPDATE_GOLD, this.getTempGold());
        return true;
    }
    public useGoldCredit(num: number) {
        this.sub(num, true);
        ClientEvent.dispatch(EventType.UPDATE_GOLD, this.getTempGold());
        return true;
    }
    public saveGold() {
        this.data.gold += this.tempGold;
        this.tempGold = 0;
        this.saveData();
    }

    private sub(n: number, isTemp = false) {
        this.add(-n, isTemp);
    }
    private add(n: number, isTemp = false) {
        if (isNaN(n)) return;
        if (isTemp) {
            this.tempGold = Math.round(this.tempGold * 100 + n * 100) / 100;
        } else {
            this.data.gold = Math.round(this.data.gold * 100 + n * 100) / 100;
            this.saveData();
        }
    }

    public addDiamond(n: number) {
        if (isNaN(n)) return;
        if (n <= 0) return;
        this.data.diamond += n;
        this.saveData();
        ClientEvent.dispatch(EventType.UPDATE_DIAMOND, this.data.diamond);
    }
    public useDiamond(n: number): boolean {
        if (isNaN(n)) return;
        if (this.data.diamond < n) return false;
        this.data.diamond -= n;
        this.saveData();
        ClientEvent.dispatch(EventType.UPDATE_DIAMOND, this.data.diamond);
        return true;
    }
    public getDiamond(): number {
        return this.data.diamond;
    }
}