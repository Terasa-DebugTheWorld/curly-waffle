import { WxSubpackageLoader } from "../../3rd/WxSubpackageLoader";
import DataFunc from "../../common/DataFunc";
import { SliverType, PutType } from "../../static/GameEnum";
import UserData from "../../userdata/UserData";
import { LogicBase } from "../LogicBase";

export type DtoSliver = {
    id: number,
    name: string,
    class: SliverType,
    put: PutType,
    bookShow: string,
    shopShow: string,
    makeShow: string,
    pizzaShow: string,
    unlockGold: number,
    unlockDiamond: number,
    cost: number,
    tipPER: number
    refund: number
}

type DtoSliverData = {
    unlockedSlivers: number[]
    rewarded: number[]
}

export type DtoSliverType = {
    id: number,
    name: string,
    icon: string
}

const RECORD_KEY = 'sliver';
/**调料 */
export const SliverLogic = new class extends LogicBase {
    name = 'sliver'

    private _sliver: { [key: string]: DtoSliver } = {};
    public get Sliver(): { [key: string]: DtoSliver } {
        return this._sliver;
    }

    private _sliverType: { [key: string]: DtoSliverType } = {};
    public get SliverType(): { [key: string]: DtoSliverType } {
        return this._sliverType;
    }

    private _sliverData: DtoSliverData = null;

    private _sliverSf: { [key: string]: cc.SpriteFrame } = {};
    public get SliverSf(): { [key: string]: cc.SpriteFrame } {
        return this._sliverSf;
    }

    private _sliverTypeSf: { [key: string]: cc.SpriteFrame } = {};
    public get SliverTypeSf(): { [key: string]: cc.SpriteFrame } {
        return this._sliverTypeSf;
    }

    protected init(): void {
        let ts = this;
        ts._sliver = DataFunc.getConfig('sliver');
        ts._sliverType = DataFunc.getConfig('sliverType');
        ts._sliverData = UserData.get(RECORD_KEY);
        for (const id in ts._sliver) {
            const sliver: DtoSliver = ts._sliver[id];
            if (sliver.hasOwnProperty("unlockGold") && sliver.unlockGold <= 0) {
                ts.unlockSliver(id);
            }
        }
        if (!ts._sliverData.rewarded) ts._sliverData.rewarded = [];
        console.log(ts._sliver);
    }

    getSliverById(id: number | string): DtoSliver {
        let ts = this;
        if (id < 0) return null;
        let sliver: DtoSliver = ts._sliver[id];
        if (!sliver) cc.error(`没有id为${id}的调料!`);
        return sliver;
    }

    getSliverNameById(id: number | string): string {
        let ts = this;
        if (id < 0) return null;
        let sliver: DtoSliver = ts._sliver[id];
        if (!sliver) cc.error(`没有id为${id}的调料!`);
        return sliver.name;
    }

    getSliverByName(name: string): DtoSliver {
        let ts = this;
        if (!name) {
            cc.error(`调料不能为空`);
            return null;
        }
        for (const id in ts._sliver) {
            const sliver: DtoSliver = ts._sliver[id];
            if (sliver.name === name) return sliver;
        }
        cc.error(`没有名为${name}的调料`);
        return null;
    }

    getSliversByType(type: SliverType): DtoSliver[] {
        let ts = this;
        let arr: DtoSliver[] = [];
        for (const id in ts._sliver) {
            const sliver: DtoSliver = ts._sliver[id];
            if (sliver.class === type) arr.push(sliver);
        }
        return arr;
    }

    getSliversByPut(putType: PutType): DtoSliver[] {
        let ts = this;
        let arr: DtoSliver[] = [];
        for (const id in ts._sliver) {
            const sliver: DtoSliver = ts._sliver[id];
            if (sliver.put === putType) arr.push(sliver);
        }
        return arr;
    }

    /**配料是否已解锁 */
    public isSliverUnlocked(id: number): boolean {
        let ts = this;
        return ts._sliverData.unlockedSlivers.includes(id);
    }
    public getUnlockedSlivers(): number[] {
        return this._sliverData.unlockedSlivers;
    }

    /**解锁配料 */
    unlockSliver(id: number | string, save = true): void {
        let ts = this;
        id = Number(id);
        if (ts.isSliverUnlocked(id)) {
            cc.warn(`id为${id}的配料已解锁,不能重复解锁!`);
            return;
        }
        if (!ts.getSliverById(id)) {
            cc.error(`不存在id为${id}的配料,解锁失败!`);
            return;
        }
        ts._sliverData.unlockedSlivers.push(id);
        save && UserData.save(RECORD_KEY);
    }

    unlockAllSliver(): void {
        let ts = this;
        for (const id in ts._sliver) {
            const sliver: DtoSliver = ts._sliver[id];
            ts.unlockSliver(sliver.id, false);
        }
        UserData.save(RECORD_KEY);
    }

    getSliverType(type: SliverType): DtoSliverType {
        let ts = this;
        let sliverType: DtoSliverType = ts._sliverType[type];
        return sliverType;
    }

    getSliverTypeIcon(type: SliverType): string {
        let ts = this;
        let sliverType: DtoSliverType = ts._sliverType[type];
        return sliverType.icon;
    }

    loadSliverTypeSf(): void {
        let ts = this;
        for (const id in SliverLogic.SliverType) {
            const sliverType: DtoSliverType = SliverLogic.SliverType[id];
            if (ts._sliverTypeSf[id]) continue;
            WxSubpackageLoader.loadSpriteFrame('more', `uiFoodAtlas/${sliverType.icon}`).then((sf) => {
                ts._sliverTypeSf[id] = sf;
            });
        }
    }

    loadSliverSf(): void {
        let ts = this;
        for (const id in SliverLogic.Sliver) {
            const sliver: DtoSliver = SliverLogic.Sliver[id];
            if (ts._sliverSf[id]) continue;
            WxSubpackageLoader.loadSpriteFrame('more', `uiFoodAtlas/${sliver.bookShow}`).then((sf) => {
                ts._sliverSf[id] = sf;
            });
        }
    }

}

window['SliverLogic'] = SliverLogic;