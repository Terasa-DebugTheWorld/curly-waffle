import DataFunc from "../../common/DataFunc";
import { OrderRecordType } from "../../static/GameEnum";
import { Util } from "../../utils/Util";
import { LogicBase } from "../LogicBase";
import { PizzaLogic } from "./PizzaLogic";
import { RecipeLogic } from "./RecipeLogic";

export type DtoOrder = {
    id: number,
    sliverId: number[],
    bookId1: number,
    bookId2: number,
    talk1: string,
    talk2: string,
    talk3: string,
    finish1: string,
    finishiTip: number,
    finishi2: string,
    finishi3: string,
    finishi4: string,
    finishi5: string,
    finishi5Tip: number,
    finishiRefund: number
}
type ShitConfig = { id: number, day: number, cakes: string, chance: number }

export type DtoOrderRecord = {
    target: OrderRecordType,
    content: string
}

export const OrderLogic = new class extends LogicBase {

    private _orders: { [key: string]: DtoOrder } = {};
    public get Orders(): { [key: string]: DtoOrder } {
        return this._orders;
    }

    protected init(): void {
        let ts = this;
        ts._orders = DataFunc.getConfig('orders');
    }

    getOrderById(id: number): DtoOrder {
        let ts = this;
        if (id <= 0) return null;
        let order: DtoOrder = ts._orders[id];
        if (!order) cc.warn(`没有id为${id}的订单`);
        return order;
    }

    randOrderUnlocked(): DtoOrder {
        const arr: DtoOrder[] = [];
        for (let i in this._orders) {
            if (i == '1') continue;
            const o = this._orders[i];
            if (RecipeLogic.isRecipeCanCook(o.bookId1)) {
                if (!o.bookId2 || RecipeLogic.isRecipeCanCook(o.bookId2)) {
                    arr.push(o);
                }
            }
        }
        if (arr.length == 0) debugger
        return Util.getRandomValueInArray(arr);
    }

    private lastDay = 0
    newOrderRule(): { data: DtoOrder, isLock: boolean } {
        const day = PizzaLogic.getDay() + 1;
        if (day == this.lastDay) return { data: this.randOrderUnlocked(), isLock: false };
        const cfgs = Object.values(DataFunc.getConfig('orderShit') as Dictionary<ShitConfig>);
        const idx = cfgs.findIndex(cfg => cfg.day > day);
        if (idx == 0) return { isLock: false, data: this.randOrderUnlocked() };
        const c = idx < 0 ? cfgs.pop() : cfgs[idx - 1];
        const cakes = c.cakes.split(',');
        const locks = cakes.filter(cake => {
            const id = Number(cake);
            return !RecipeLogic.isRecipeCanCook(id);
        });
        if (locks.length > 0 && Math.random() * 100 < c.chance) {
            this.lastDay = day;
            const cakeId = Util.getRandomValueInArray(locks);
            for (let i in this.Orders) {
                if (this.Orders[i].bookId1 + '' == cakeId) {
                    return { isLock: true, data: this.Orders[i] };
                }
            }
        } else {
            return { isLock: false, data: this.randOrderUnlocked() };
        }
    }
}
window['OrderLogic'] = OrderLogic;