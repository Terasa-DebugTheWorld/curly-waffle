import { LogicBase } from "../LogicBase";

export type DtoSale = {
    sale: number,//销售额(客人下单的钱)
    tip: number,//小费
    rent: number,//租金
    refund: number,//退款
    sliver: number,//材料总成本
    profit: number,//利润=上面之和
    sliverInfo: { [key: string]: number }//材料消耗详细
}

export const SaleLogic = new class extends LogicBase {
    name = 'sale'

    private _saleData: DtoSale = null;
    public get SaleData(): DtoSale {
        return this._saleData;
    }

    protected init(): void {
        let ts = this;
        this.reset();
    }

    reset(): void {
        let ts = this;
        ts._saleData = {
            sale: 0,
            tip: 0,
            rent: 0,
            refund: 0,
            sliver: 0,
            profit: 0,
            sliverInfo: {}
        }
    }


    /**增加销售额 */
    addSale(v: number): void {
        let ts = this;
        if (typeof v !== 'number') return;
        if (!ts._saleData) return;
        ts._saleData.sale = ts.add(ts._saleData.sale, v);
        ts._saleData.profit = ts.add(ts._saleData.profit, v);
    }

    /**增加小费 */
    addTip(v: number): void {
        let ts = this;
        if (typeof v !== 'number') return;
        if (!ts._saleData) return;
        ts._saleData.tip = ts.add(ts._saleData.tip, v);
        ts._saleData.profit = ts.add(ts._saleData.profit, v);
    }

    /**增加租金 */
    addRent(v: number): void {
        let ts = this;
        if (typeof v !== 'number') return;
        if (!ts._saleData) return;
        ts._saleData.rent = ts.add(ts._saleData.rent, -v);
        ts._saleData.profit = ts.add(ts._saleData.profit, -v);
    }

    /**增加退款 */
    addRefund(v: number): void {
        let ts = this;
        if (typeof v !== 'number') return;
        if (!ts._saleData) return;
        ts._saleData.refund += v;
        ts._saleData.profit += v;
    }

    /**增加材料消耗 */
    addUseSliver(sliverId: number, cost: number): void {
        let ts = this;
        if (typeof sliverId !== 'number') return;
        if (typeof cost !== 'number') return;
        if (!ts._saleData) return;
        if (ts._saleData.sliverInfo.hasOwnProperty(sliverId)) {
            ts._saleData.sliverInfo[sliverId] = ts.add(ts._saleData.sliverInfo[sliverId], -cost);
        } else {
            ts._saleData.sliverInfo[sliverId] = cost;
        }
        ts._saleData.sliver = ts.add(ts._saleData.sliver, -cost);
        ts._saleData.profit = ts.add(ts._saleData.profit, -cost);
    }

    private add(a: number, b: number): number {
        return Math.round(a * 100 + b * 100) / 100;
    }
}
window['SaleLogic'] = SaleLogic;