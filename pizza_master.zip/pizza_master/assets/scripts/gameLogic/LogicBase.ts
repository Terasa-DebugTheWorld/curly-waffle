/**
 * @example 初始化无顺序要求：export const xxLogic = new class extends LogicBase { name = xx }
 * @example 初始化有顺序要求：class xx extends LogicBase { name = xx } 
 *                          export const xxLogic = new xx(order);
 */
export class LogicBase {
    public static LOGIC_LIST: LogicBase[] = []
    public static INIT_ALL() {
        LogicBase.LOGIC_LIST.forEach(l => l.init());
    }
    public static UPDATE_ALL(dt: number) {
        LogicBase.LOGIC_LIST.forEach(l => l.update(dt));
    }
    public static BACK_ALL(offlineTime: number) {
        LogicBase.LOGIC_LIST.forEach(l => l.onBackToGame(offlineTime));
    }

    constructor(order?: number) {
        if (order == undefined) order = LogicBase.LOGIC_LIST.length - 1;
        LogicBase.LOGIC_LIST.splice(order, 0, this);
    }
    public name: string
    protected init() { }
    protected update(dt: number) { }
    protected onBackToGame(offlineTime: number) { }
}