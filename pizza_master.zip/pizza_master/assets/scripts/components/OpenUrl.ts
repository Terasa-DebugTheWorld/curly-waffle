import { NativeCall } from "../3rd/NativeCall";
import { Util } from "../utils/Util";

const { ccclass, property } = cc._decorator;

@ccclass
export default class OpenUrl extends cc.Component {
    @property()
    url = ""

    onLoad() {
        Util.addClickEvent(this.getComponent(cc.Button), this.node, "OpenUrl", "open")
    }

    open() {
        NativeCall.openUrl(this.url);
    }

}
