import { Util } from "../utils/Util";

const DIR = cc.Enum({
    UP: 1,
    DOWN: 2,
    LEFT: 3,
    RIGHT: 4
})

const { ccclass, property } = cc._decorator;

@ccclass
export default class MoveOutIn extends cc.Component {
    @property({ type: DIR })
    dir = DIR.DOWN
    @property()
    time = 0.2;
    @property()
    len = 300;

    _orgPos: cc.Vec2 = null;
    onLoad() {
        this._orgPos = this.node.getPosition();
    }

    async moveOut() {
        await Util.waitOneUpdate(this);
        let px = this.len;
        let time = this.time;
        let offset = cc.v3(0, 0, 0);
        switch (this.dir) {
            case DIR.DOWN:
                offset.y = -px;
                break;
            case DIR.UP:
                offset.y = px;
                break;
            case DIR.RIGHT:
                offset.x = px;
                break;
            case DIR.LEFT:
                offset.x = -px;
                break;
            default:
                break;
        }
        cc.tween(this.node).by(time, { position: offset }).start();
        await Util.delay(time);
    }

    async moveIn() {
        this.scheduleOnce(() => {
            cc.tween(this.node).to(0.2, { position: cc.v3(this._orgPos.x, this._orgPos.y) }).start();
        })
    }
}
