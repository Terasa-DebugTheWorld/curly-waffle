const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('Common/按钮防连点')
export class BtnSafe extends cc.Component {

    @property({ tooltip: "按钮保护时间，指定间隔内只能点击一次." })
    safeTime: number = 1

    _dt: 0
    _button
    clickEvents
    start() {
        let button = this.getComponent(cc.Button);
        if (!button) {
            return;
        }

        this._button = button;
        this.clickEvents = button.clickEvents;
        this.node.on('click', this.protect, this);
    }

    _protect: boolean = false
    protect() {
        if (this._protect) return;
        this._protect = true;
        this._dt = 0;
        this._button.clickEvents = [];
    }

    unProtect() {
        this._protect = false;
        if (this._button && this.clickEvents) {
            this._button.clickEvents = this.clickEvents;
        }
    }

    onEnable() {
        this.unProtect();
    }

    update(dt) {
        if (this._protect) {
            this._dt += dt;
            if (this._dt >= this.safeTime) {
                this._dt = 0;
                this.unProtect();
            }
        }
    }
};
