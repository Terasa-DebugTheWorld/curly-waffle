const { ccclass, property, menu } = cc._decorator;

@ccclass
export class RollNumberLabel extends cc.Component {
    @property(cc.Label)
    label: cc.Label = null

    protected resetInEditor(): void {
        this.label = this.getComponent(cc.Label);
    }

    private format: string
    private reg: RegExp | string
    private dec = 0
    public setFormat(format: string, reg: RegExp | string, dec = 0) {
        this.format = format;
        this.reg = reg;
        this.dec = dec;
    }

    private _num: number = 0
    public get num(): number {
        return this._num;
    }
    public set num(v: number) {
        this._num = v;
        let str = v.toFixed(this.dec);
        if (this.format && this.reg) {
            str = this.format.replace(this.reg, str);
        }
        this.label.string = str;
    }

    private tw: cc.Tween;
    // private sc: cc.Tween;
    public rollTo(num: number, time: number) {
        if (this.tw) this.tw.stop();
        if (!this.s) this.s = this.node.scale;
        cc.tween(this.node).set({ scale: this.s }).to(0.2, { scale: this.s * 1.2 }).start();
        this.tw = cc.tween(this)
            .to(time, { num: num } as any)
            .call(() => {
                this.tw = null
                cc.tween(this.node).to(0.2, { scale: this.s }).start();
            })
            .start();
    }

    // LIFE-CYCLE CALLBACKS:
    private s: number = 0;
    onLoad() {
        let ts = this;
    }
    // protected onEnable(): void {
    //     this.label.enabled = true;
    // }
    onDisable() {
        if (this.tw) {
            this.tw.stop();
            this.tw = null;
        }
    }
}
