import { AudioSwitchBase } from "./AudioSwitchBase";

const { ccclass, property } = cc._decorator;

@ccclass
export class AudioSwitchWithActive extends AudioSwitchBase {
    @property(cc.Node)
    node_on: cc.Node = null
    @property(cc.Node)
    node_off: cc.Node = null

    updateView() {
        this.node_on.active = this.isOn;
        this.node_off.active = !this.isOn;
    }

    resetInEditor() {
        const eh = new cc.Component.EventHandler();
        eh.target = this.node;
        eh.component = cc.js.getClassName(this);
        eh.handler = 'change';
        const btn = this.addComponent(cc.Button);
        btn.clickEvents.push(eh);
        btn.target = this.node;
        btn.transition = cc.Button.Transition.SCALE;
    }
    // LIFE-CYCLE CALLBACKS:
}
