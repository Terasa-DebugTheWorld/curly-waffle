import { AudioHelper } from "../../common/AudioHelper";

const { ccclass, property } = cc._decorator;

@ccclass
export class AudioSwitchBase extends cc.Component {
    @property
    isEffect = true
    @property
    isBgm = true

    protected static TYPE = {
        EFFECT: 1,
        BGM: 2
    }
    protected get type(): number {
        const e = this.isEffect ? AudioSwitchBase.TYPE.EFFECT : 0;
        const b = this.isBgm ? AudioSwitchBase.TYPE.BGM : 0;
        return e | b;
    }

    // LIFE-CYCLE CALLBACKS:
    start() {
        if (this.type & AudioSwitchBase.TYPE.BGM) {
            this.isOn = AudioHelper.getBgmSwitch();
        } else {
            this.isOn = AudioHelper.getEffectSwitch();
        }
        this.updateView();
    }
    private setSwitch(isOn: boolean) {
        this.isOn = isOn;
        if (this.type & AudioSwitchBase.TYPE.EFFECT) {
            AudioHelper.setEffectSwitch(isOn);
        }
        if (this.type & AudioSwitchBase.TYPE.BGM) {
            AudioHelper.setBgmSwitch(isOn);
        }
        this.updateView();
    }
    private change() {
        this.setSwitch(!this.isOn);
    }
    private setOn() {
        this.setSwitch(true);
    }
    private setOff() {
        this.setSwitch(false);
    }

    //over-ride 
    protected isOn: boolean = false

    //根据this.isOn改变界面显示
    protected updateView() {

    }
}
