import MoveOutIn from "./MoveOutIn";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MoveOutInGroup extends cc.Component {
    @property([MoveOutIn])
    group: MoveOutIn[] = [];

    async moveOut() {
        let all = [];
        this.group.forEach(g => {
            all.push(g.moveOut());
        })
        await Promise.all(all);
    }

    async moveIn() {
        this.group.forEach(g => {
            g.moveIn();
        })
    }
}
