
const { ccclass, property } = cc._decorator;

@ccclass
export default class PicSizeAutoFit extends cc.Component {
    @property(cc.Size)
    fitSize: cc.Size = cc.size(100, 100)

    public static fit(sf: cc.SpriteFrame, targetSize: cc.Size) {
        const picSize: cc.Size = sf.getOriginalSize();
        const picRatio: number = picSize.width / picSize.height;
        let mul: number = 1;
        if (targetSize.width / targetSize.height > picRatio) {
            mul = targetSize.height / picSize.height || 0;
        } else {
            mul = targetSize.width / picSize.width || 0;
        }
        return cc.size(mul * picSize.width, mul * picSize.height)
    }

    _sprite: cc.Sprite = null
    _ratio: number = 1
    onLoad() {
        this._sprite = this.getComponent(cc.Sprite);
        if (!this._sprite) {
            this.enabled = false;
            return;
        }

        this._ratio = this.fitSize.width / this.fitSize.height;
        this.node.once(cc.Node.EventType.SIZE_CHANGED, this.onSizeChanged, this);
    }

    onSizeChanged() {
        const picSize: cc.Size = this.node.getContentSize();
        const picRatio: number = picSize.width / picSize.height;
        let mul: number = 1;
        if (this._ratio > picRatio) {
            mul = this.fitSize.height / picSize.height || 0;
        } else {
            mul = this.fitSize.width / picSize.width || 0;
        }

        this._sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.node.width *= mul;
        this.node.height *= mul;
    }

    resetInEditor() {
        this._sprite = this.getComponent(cc.Sprite);
        if (!this._sprite) {
            this.enabled = false;
            return;
        }

        this._ratio = this.fitSize.width / this.fitSize.height;
        this.onSizeChanged();
    }
}
