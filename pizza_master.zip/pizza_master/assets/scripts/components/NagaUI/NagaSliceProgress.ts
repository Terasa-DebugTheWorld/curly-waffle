const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('NagaUI/九宫格进度条')
export class NagaSliceProgress extends cc.Component {
    @property
    set bgLength(v: number) {
        this.node.width = v;
    }
    get bgLength(): number {
        return this.node.width;
    }
    @property
    set barLength(v: number) {
        const bar = this.getComponentInChildren(cc.Sprite);
        if (bar) {
            bar.node.width = v;
            bar.node.x = -v + v * bar.node.anchorX;
        }
        if (this.progress) {
            this.progress.totalLength = v;
        }
    }
    get barLength(): number {
        const bar = this.getComponentInChildren(cc.Sprite);
        if (bar) {
            return bar.node.width;
        } else {
            return 0;
        }
    }
    @property
    set isSlice(v: boolean) {
        if (v == this._isSlice) return;
        if (v) {
            this.progress.mode = cc.ProgressBar.Mode.HORIZONTAL;
            this.progress.barSprite.type = cc.Sprite.Type.SLICED;
        } else {
            this.progress.mode = cc.ProgressBar.Mode.FILLED;
            this.progress.barSprite.type = cc.Sprite.Type.FILLED;
            this.progress.barSprite.fillRange = 1;
        }
        this._isSlice = v;
    }
    get isSlice(): boolean {
        return this._isSlice;
    }
    @property
    _isSlice: boolean = true
    @property(cc.ProgressBar)
    progress: cc.ProgressBar = null

    resetInEditor() {
        const bg = this.getComponent(cc.Sprite);
        if (bg) {
            bg.type = cc.Sprite.Type.SLICED;
        }
        const bar = this.getComponentInChildren(cc.Sprite);
        if (bar) {
            bar.type = cc.Sprite.Type.SLICED;
        }
        this.progress = this.getComponent(cc.ProgressBar) || this.addComponent(cc.ProgressBar);
    }

    // LIFE-CYCLE CALLBACKS:
}
