const { ccclass, property, executeInEditMode, menu, requireComponent } = cc._decorator;

@ccclass
@executeInEditMode
@requireComponent(cc.Button)
@menu('NagaUI/NagaSwitchButton')
export default class NagaSwitchButton extends cc.Component {

    private _showIdx: number = 0;
    public get ShowIdx(): number {
        return this._showIdx;
    }
    @property({ type: cc.Integer, step: 1, min: 0 })
    public set ShowIdx(v: number) {
        let ts = this;
        if (ts._showIdx === v) return;
        let len:number = ts.node.children.length;
        if(len <= 0) return;
        ts._showIdx = v % len;
        ts.node.children.forEach((n: cc.Node, index: number) => {
            n.active = index === ts._showIdx;
        });
    }

    protected onEnable(): void {
        let ts = this;
    }

    resetInEditor() {
        const button = this.node.getComponent(cc.Button);
        button.transition = cc.Button.Transition.SCALE;
        button.target = this.node;
        
        const handler = new cc.Component.EventHandler();
        handler.target = this.node;
        handler.component = 'NagaSwitchButton';
        handler.handler = 'onSwitch';
        button.clickEvents.push(handler);
    }

    onSwitch():void{
        let ts = this;
        ts.ShowIdx++;
    }

}
