const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('NagaUI/AutoFillWidget')
export default class AutoFillWidget extends cc.Component {

    @property
    fillLeft: boolean = true;

    @property
    fillRigth: boolean = true;

    @property
    fillTop: boolean = true;

    @property
    fillBottom: boolean = true;

    resetInEditor() {
        const widget = this.getComponent(cc.Widget) || this.addComponent(cc.Widget);
        if (this.fillLeft) {
            widget.isAlignLeft = true;
            widget.left = 0;
        }
        if (this.fillRigth) {
            widget.isAlignRight = true;
            widget.right = 0;
        }
        if (this.fillTop) {
            widget.isAlignTop = true;
            widget.top = 0;
        }
        if (this.fillBottom) {
            widget.isAlignBottom = true;
            widget.bottom = 0;
        }
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start() {

    // }

    // update (dt) {}
}
