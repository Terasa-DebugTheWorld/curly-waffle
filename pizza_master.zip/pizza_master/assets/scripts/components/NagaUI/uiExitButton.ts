import uiPanel from "../../common/uiPanel";
import { BtnSafe } from '../BtnSafe';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('NagaUI/uiExitButton')
export default class NewClass extends cc.Component {

    resetInEditor() {
        const button = this.node.getComponent(cc.Button) || this.node.addComponent(cc.Button);
        button.transition = cc.Button.Transition.SCALE;
        button.target = this.node;

        const handler = new cc.Component.EventHandler();
        handler.target = this.node.parent;
        handler.component = cc.js.getClassName(this.node.parent.getComponent(uiPanel));
        handler.handler = 'quit';
        button.clickEvents.push(handler);

        this.getComponent(BtnSafe) || this.addComponent(BtnSafe);
    }

}
