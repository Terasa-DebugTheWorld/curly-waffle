import uiFunc from "../../common/uiFunc";
import { BtnSafe } from '../BtnSafe';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('NagaUI/uiEntryButton')
export default class uiEntryButton extends cc.Component {
    @property
    uiName: string = ''
    @property
    force: boolean = false
    @property
    single: boolean = true
    @property
    notOpenYet: boolean = false
    @property({ visible: function () { return this.notOpenYet; } })
    toast: string = ''

    resetInEditor() {
        const button = this.node.getComponent(cc.Button) || this.node.addComponent(cc.Button);
        button.transition = cc.Button.Transition.SCALE;
        button.target = this.node;
        button.addComponent(BtnSafe);
    }

    onLoad() {
        if (this.uiName) this.node.on('click', () => {
            if (this.notOpenYet) {
                // UIHelper.instance.toast(this.toast);
            } else {
                uiFunc.open(cc.js.getClassByName(this.uiName), null, { force: this.force });
            }
        }, this);
    }
}
