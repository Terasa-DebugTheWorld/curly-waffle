const { ccclass, property, menu, executeInEditMode } = cc._decorator;
const FPS = 1 / 20; //未设置playOnFocus时，fps的实际效果是1/10
@ccclass
@executeInEditMode
@menu('NagaUI/NagaLabel')
export default class NagaLabel extends cc.Component {

    @property({
        tooltip: '根据字体大小来自动设置行高'
    })
    autoSetHeight = true;

    @property({
        tooltip: '行高比字体size大多少',
        visible: function () {
            return this.autoSetHeight;
        }
    })
    fontHeightAdd = 5;

    _label: cc.Label = null;
    resetInEditor() {
        const label = this.getComponent(cc.Label) || this.addComponent(cc.Label);
        label.fontFamily = 'PingFangSC-Medium';
        label.horizontalAlign = label.verticalAlign = 1;
        this._label = label;
    }

    _isOn = false;
    onFocusInEditor() {
        this._isOn = true;
    }

    onLostFocusInEditor() {
        this._isOn = false;
    }

    resizeLineHeight() {
        this._label.lineHeight = this._label.fontSize + this.fontHeightAdd;
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        if (!this._label) this._label = this.getComponent(cc.Label);
    }

    // start() {

    // }

    _lastFontSize = 30;
    _ldt = 0;
    update(dt) {
        if (!CC_EDITOR) this.update = (dt) => { };
        if (!this._isOn) return;
        this._ldt += dt;
        if (this._ldt < FPS) return;
        this._ldt = 0;

        if (!this.autoSetHeight) return;
        if (this._lastFontSize == this._label.fontSize) return;
        this._lastFontSize = this._label.fontSize;
        this.resizeLineHeight();
    }
}
