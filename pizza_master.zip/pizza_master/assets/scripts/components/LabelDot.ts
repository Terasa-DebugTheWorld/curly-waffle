
const { ccclass, property } = cc._decorator;
@ccclass
export default class LableDot extends cc.Component {
    @property()
    interval = 0.5
    @property()
    dotCount = 4

    _updateTime = 0;
    _count = 0;
    _label = null;
    pause = false;
    start() {
        this._updateTime = 0;
        this._count = 0;
        this._label = this.getComponent(cc.Label);
        if (this._label) {
            this._label.srcString = this._label.string;
        }
    }

    reset() {
        if (this._label) {
            this._label.string = this._label.srcString;
            this._count = 0;
        }
    }

    update(dt) {
        if (this.pause) return;
        this._updateTime += dt;
        if (this._updateTime < this.interval) return;
        this._updateTime = 0;
        this._count++;
        if (this._count > 4) this._count = 0;
        if (this._label) {
            this._label.string = this._label.srcString + (new Array(this._count).fill('.')).join("");
        }
    }
}
