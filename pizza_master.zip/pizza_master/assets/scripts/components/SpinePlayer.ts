//使用这个播放骨骼动画后，不能再对该骨骼动画setCompleteListener，否则会失效
export const SpinePlayer = new class {
    public play(spine: sp.Skeleton, trackIndex: number = 0, animationName: string = 'daiji', loop: boolean = false): Promise<void> {

        return new Promise((resolve, reject) => {
            let isEnd = false;
            spine.setCompleteListener(() => {
                if (!isEnd) {
                    resolve();
                    isEnd = true;
                }
            });
            spine.setAnimation(trackIndex, animationName, loop);
        });
    }
    public waitEvent(spine: sp.Skeleton, trackIndex: number = 0, animationName: string = 'daiji'): Promise<void> {

        return new Promise((resolve, reject) => {
            let isEnd = false;
            spine.setEventListener(() => {
                if (!isEnd) {
                    resolve();
                    isEnd = true;
                }
            });
            spine.setAnimation(trackIndex, animationName, false);
        });
    }

    public cancelPlay(spine: sp.Skeleton) {
        spine.setCompleteListener(null);
    }
    public cancelEvent(spine: sp.Skeleton) {
        spine.setEventListener(null);
    }
}