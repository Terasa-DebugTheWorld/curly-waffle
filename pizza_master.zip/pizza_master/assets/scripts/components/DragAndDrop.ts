import EventListener from '../common/EventListener';

type DADType = 'start' | 'drag' | 'drop'
type DADListener = (data: { current: cc.Vec3, start: cc.Vec3, comp: DragAndDrop }) => void
const { ccclass, property, menu } = cc._decorator;
@ccclass
export class DragAndDrop extends cc.Component {
    @property(cc.Node)
    touchNode: cc.Node = null
    // @property
    // moveSpeed:number=50
    @property(cc.Rect)
    movableRect: cc.Rect = cc.rect(-360, -640, 720, 1280)

    resetInEditor() {
        this.touchNode = this.node;
    }

    public static eventType: DADType = 'start'

    private listener = new EventListener()
    public on(type: DADType, handler: DADListener, target: any) {
        this.listener.on(type, handler, target);
    }
    public once(type: DADType, handler: DADListener, target: any) {
        this.listener.on(type, handler, target, true);
    }
    public off(type: DADType, handler: DADListener, target: any) {
        this.listener.off(type, handler, target);
    }
    public targetOff(target: any) {
        this.listener.clear(target);
    }
    private isOn: boolean = true
    public turnOff() {
        this.isOn = false;
    }
    public turnOn() {
        this.isOn = true;
    }

    private offset: cc.Vec3 = cc.v3()
    private startPos: cc.Vec3 = cc.v3()
    private touchStart(event: cc.Touch) {
        if (this.isAutoMoving || !this.isOn) return;
        this.offset = this.node.convertToNodeSpaceAR(cc.v3(event.getLocation()));
        this.startPos = this.node.position;
        this.listener.dispatch('start', null);
    }
    private touchMove(event: cc.Touch) {
        if (this.isAutoMoving || !this.isOn) return;
        const pos = this.convertTouch(event);
        this.node.x = Math.min(this.movableRect.xMax, Math.max(this.movableRect.xMin, pos.x));
        this.node.y = Math.min(this.movableRect.yMax, Math.max(this.movableRect.yMin, pos.y));
        this.listener.dispatch('drag', { current: this.node.position, start: this.startPos, comp: this });
    }
    private touchEnd(event: cc.Touch) {
        if (this.isAutoMoving || !this.isOn) return;
        const pos = this.convertTouch(event);
        this.listener.dispatch('drop', { current: pos, start: this.startPos, comp: this });
    }
    private convertTouch(touch: cc.Touch): cc.Vec3 {
        const wp = touch.getLocation();
        const pos = this.node.parent.convertToNodeSpaceAR(cc.v3(wp)).sub(this.offset);
        return pos;
    }
    public relistenTouch() {
        this.touchNode.on(cc.Node.EventType.TOUCH_START, this.touchStart, this);
        this.touchNode.on(cc.Node.EventType.TOUCH_MOVE, this.touchMove, this);
        this.touchNode.on(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
        this.touchNode.on(cc.Node.EventType.TOUCH_CANCEL, this.touchEnd, this);
    }

    //auto
    private isAutoMoving: boolean = false
    private moveTime: number = 0
    private orig: cc.Vec3
    private dest: cc.Vec3
    private needEvent: boolean = false
    private resolve: () => void
    public moveTo(t: number, pos: cc.Vec3, needEvent: boolean = false): Promise<void> {
        this.isAutoMoving = true;
        this.moveTime = t;
        this.dest = pos;
        this.orig = this.node.position;
        this.needEvent = needEvent;
        return new Promise(res => {
            this.resolve = res;
        });
    }
    public stopAutoMove() {
        this.isAutoMoving = false;
        this.moveTime = 0;
    }

    // LIFE-CYCLE CALLBACKS:
    onEnable() {
        if (this.touchNode) {
            this.relistenTouch();
        }
    }
    protected onDisable(): void {
        if (this.touchNode) {
            this.touchNode.targetOff(this);
        }
    }
    private udCnt: number = 0
    private itv: number = 1
    private ldt: number = 0
    update(dt: number) {
        if (this.isAutoMoving) {
            this.ldt += dt;
            if (this.ldt < this.moveTime) {
                this.node.position = cc.Vec3.lerp(cc.v3(), this.orig, this.dest, this.ldt / this.moveTime);
            } else {
                this.ldt = 0;
                this.node.position = this.dest;
                this.isAutoMoving = false;
                if (this.resolve) {
                    this.resolve();
                    this.resolve = null;
                }
            }
            if (this.needEvent /* && ++this.udCnt > this.itv */) {
                // this.udCnt = 0;
                this.listener.dispatch('drag', { current: this.node.position, start: this.startPos, comp: this });
            }
        }
    }
}
