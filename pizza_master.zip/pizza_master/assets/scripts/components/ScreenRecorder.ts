import { ByteMiniRecorder } from "../3rd/ByteMiniRecorder";

const { ccclass, property } = cc._decorator;

@ccclass
export class ScreenRecorder extends cc.Component {

    // LIFE-CYCLE CALLBACKS:
    public static ins: ScreenRecorder
    protected onLoad(): void {
        ScreenRecorder.ins = this;
        ByteMiniRecorder.on(ByteMiniRecorder.eventType.Stop, this.onRecordStop, this);
    }

    public videoPath = ''
    private onRecordStop({ videoPath }) {
        this.videoPath = videoPath;
    }
}
