import uiFunc from "../common/uiFunc";
import { Util } from "../utils/Util";

const {ccclass, property} = cc._decorator;

@ccclass
export default class OpenUI extends cc.Component {
    @property()
    uiName = ""

    onLoad(){
        Util.addClickEvent(this.getComponent(cc.Button),this.node,"OpenUI","open")
    }

    open(){
        uiFunc.open(this.uiName);
    }
}
