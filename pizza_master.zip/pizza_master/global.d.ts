type enumKey = string | number
type valueof<T> = T[keyof T]
type Dictionary<V> = { [key: string]: V }